//
//  ProductListCVVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

final class ProductsImageVC: BaseVC {
    
    //MARK:- Properties
    var viewModel: ProductImagesVM?
    lazy var datasource = ProductImagesListDatasource()
    var delegate: SelectItemDelegate?
    
    var productList: [ProductItem] = []
    
    //MARK:- IBOutlet
    @IBOutlet weak var uicProductsImage: UICollectionView!
    
    override func configureView() {
        super.configureView()
        setCollectionView()
        setupDelegate()
    }
    
    override func bindView() {
        super.bindView()
        viewModel = ProductImagesVM(datasource: datasource)
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self else { return }
            self.productList = $0
            self.uicProductsImage.reloadData()
        }
        
        
        viewModel?.multipleSelectionItem.bind { [weak self] in
            guard let self = self,
                  let item = $0 else { return }
            self.delegate?.selectItem(item: item)
        }
        
        
        viewModel?.singleSelectionItem.bind { [weak self] in
            guard let self = self,
                  let item = $0 else { return }
            self.delegate?.singleSelectItem(item: item)
        }
    }
    
    
    //MARK:- IBAction
}

extension ProductsImageVC {
    
    func setupDelegate() {
        uicProductsImage.dataSource = datasource
        uicProductsImage.delegate = self
    }
    
    
    func setCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 5
        layout.minimumInteritemSpacing = 5
        uicProductsImage.collectionViewLayout = layout
    }
    
}

extension ProductsImageVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        viewModel?.selectItem(item: productList[indexPath.item])
    }
}

extension ProductsImageVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let noOfCellsInRow = 4
        
        let flowLayout = collectionViewLayout as! UICollectionViewFlowLayout
        
        let totalSpace = flowLayout.sectionInset.left
            + flowLayout.sectionInset.right
            + (flowLayout.minimumInteritemSpacing * CGFloat(noOfCellsInRow - 1))
        
        let size = Int((collectionView.bounds.width - totalSpace) / CGFloat(noOfCellsInRow))
        
        return CGSize(width: size, height: size)
    }
}


extension ProductsImageVC: ProductCatalogDelegate {
    func loadData<T>(productList: [T]) {
        viewModel?.loadData(productList: productList as! [ProductItem])
    }
    
    func updateImagesMultipleSelection(isOn: Bool) {
        viewModel?.setMultipleSelection(isOn: isOn)
    }
    
    func updateProductListSelection(items: [ProductItem]) {
        viewModel?.updateView(items: items)
    }
}


class ProductImagesListDatasource: GenericDataSource<ProductItem>, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCatelogCell", for: indexPath) as? ProductCatalogCVCell else {
            return UICollectionViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
}
