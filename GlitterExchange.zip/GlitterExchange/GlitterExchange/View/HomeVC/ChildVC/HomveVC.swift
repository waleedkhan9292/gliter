//
//  HomveVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 11/10/2020.
//

import UIKit

class HomveVC: BaseVC {
    
    //MARK:- Properties
    lazy var viewModel: HomeVM? = {
        return HomeVM()
    }()
    
    var delegate: HomeControllerDelegate?
    
    //MARK:- IBOutlet
    @IBOutlet weak var uvHolidayImageFrontView: UIView!
    @IBOutlet weak var ivHolidayImage: UIImageView!
    
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
    }
    
    override func bindView() {
        super.bindView()
        viewModel?.image.bind { [weak self] in
            guard let self = self,
                  let image = $0 else {
                return
            }
            self.animate(with: image)
        }
        
    }
    
    //MARK:- IBAction
    
    @IBAction func btnGoToPet(_ sender: UIButton) {
        delegate?.goToPet?()
    }
    
    @IBAction func btnOnHolidayTap(_ sender: UIButton) {
        delegate?.goToHoliday?()
    }
    @IBAction func btnOnDigitalMarketingTap(_ sender: UIButton) {
        delegate?.goToDigitalMarketing?()
    }
    @IBAction func btnRetailDisplayTap(_ sender: UIButton) {
        delegate?.goToRetailDisplay?()
    }
    @IBAction func btnOnCustomTap(_ sender: UIButton) {
        delegate?.goToCustom?()
    }
    @IBAction func btnPhotographyTap(_ sender: UIButton) {
        delegate?.goToPhotograpy?()
    }
    @IBAction func btnVideoTap(_ sender: UIButton) {
        delegate?.goToVideo?()
    }
    @IBAction func btnWebsiteAssistanceTap(_ sender: UIButton) {
        delegate?.goToWebsiteAssistance?()
    }
    
}

extension HomveVC {

    func animate(with imageName: String) {
        
        let image = UIImage(named: imageName)
        UIView.animate(withDuration: 1.5, delay: 0.0, options: .transitionCrossDissolve, animations: {
            self.uvHolidayImageFrontView.alpha = 0.3
            self.ivHolidayImage.alpha = 0.05
            
        }) { finished in
            self.ivHolidayImage.image = image
            UIView.animate(withDuration: 2.5, delay: 0.5, options: .transitionCrossDissolve, animations: {
                self.uvHolidayImageFrontView.alpha = 0.0
                self.ivHolidayImage.alpha = 1.0
            }) { finished in
            }
        }
    }
}

