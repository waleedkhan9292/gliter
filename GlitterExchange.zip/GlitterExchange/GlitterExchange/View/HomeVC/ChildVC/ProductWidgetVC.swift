//
//  ProductWidgetVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 24/10/2020.
//

import UIKit
import MaterialComponents
import BarcodeScanner

class ProductWidgetVC: BaseVC {
    
    let datasource = ProductWidgetListDatasource()
    var viewModel: ProductWidgetVM?
    var pageList: [ProductPage] = []
    
    var delegate: ProductWidgetDelegate?
    
    @IBOutlet weak var tvHtml: UITextView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPageLabel: UILabel!
    
    @IBOutlet weak var uvPageList: UIView!
    @IBOutlet weak var uvWithoutCard: UIView!
    @IBOutlet weak var uvWithCard: UIView!
    @IBOutlet weak var uvPageLabeCard: MDCCard!
    
    @IBOutlet weak var uitPageList: UITableView!

    
    override func configureView() {
        super.configureView()
        uvPageList.isHidden = true
    }
    
    override func bindView() {
        super.bindView()
        
        viewModel = ProductWidgetVM(datasource: datasource)
        
        uitPageList.dataSource = datasource
        uitPageList.delegate = self
        
        viewModel?.pageTitle.bind { [weak self] in
            guard let self = self else { return }
            self.lblPageLabel.text = $0
        }
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self else { return }
            self.pageList = $0
            self.uitPageList.reloadData()
        }
    }
    
    @IBAction func btnShowPageList(_ sender: UIButton) {
        uvPageList.isHidden = false
    }
    
    @IBAction func btnHidePageList(_ sender: UIButton) {
        uvPageList.isHidden = true
    }
    
    @IBAction func gotoSearchWithPage(_ sender: UIButton) {
        delegate?.gotoSearchProductScreen()
    }
    
    @IBAction func btnQRCodeWithPage(_ sender: UIButton) {
        delegate?.openBarCodeScaner(delegateTo: self)
    }
    
    @IBAction func btnQRCodeWithoutPage(_ sender: UIButton) {
        delegate?.openBarCodeScaner(delegateTo:self)
    }
    
    @IBAction func btnGotoSearchProduct(_ sender: UIButton) {
        delegate?.gotoSearchProductScreen()
    }
}

extension ProductWidgetVC: ProductCatalogDelegate {
    func loadData<T>(productList: [T]) {
        if productList.count < 2 {
            uvWithCard.isHidden = true
            uvWithoutCard.isHidden = false
        }
        else {
            uvWithCard.isHidden = false
            uvWithoutCard.isHidden = true
        }
        viewModel?.loadData(productList: productList as! [ProductPage])
    }
    
    func setWidget(with catalog: Catalog?) {
        lblTitle.text = catalog?.pageNavigatorLabel
        tvHtml.attributedText = catalog?.widgetHTML?.htmlToAttributedString
    }
    
    func setLabel(with text: String) {
        viewModel?.setPageTitle(with: text)
    }
}

extension ProductWidgetVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        uvPageList.isHidden = true
        viewModel?.setPageTitle(with: pageList[indexPath.row].pageLabel ?? "")
        delegate?.setPageInProductCatalog(with: pageList[indexPath.row])
    }
}


class ProductWidgetListDatasource: GenericDataSource<ProductPage>, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: PageLableCell.identifier(),for: indexPath) as? PageLableCell else {
            return UITableViewCell()
        }
        cell.pageLabel = data.value[indexPath.row]
        return cell
    }
}

// MARK: - BarcodeScannerErrorDelegate
extension ProductWidgetVC: BarcodeScannerErrorDelegate {
    func scanner(_ controller: BarcodeScannerViewController, didReceiveError error: Error) {
        delegate?.barCodeScanFail(message:"Unable to read barcode or not supported")
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            controller.reset(animated: true)
        }
    }
}

// MARK: - BarcodeScannerCodeDelegate
extension ProductWidgetVC: BarcodeScannerCodeDelegate {
    func scanner(_ controller: BarcodeScannerViewController, didCaptureCode code: String, type: String) {
        delegate?.barCodeScanSuccess(barCode: code)
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            controller.dismiss(animated: true, completion: nil)
        }
//        controller.dismiss(animated: true, completion: nil)
    }
}

// MARK: - BarcodeScannerDismissalDelegate
extension ProductWidgetVC: BarcodeScannerDismissalDelegate {
    func scannerDidDismiss(_ controller: BarcodeScannerViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
}
