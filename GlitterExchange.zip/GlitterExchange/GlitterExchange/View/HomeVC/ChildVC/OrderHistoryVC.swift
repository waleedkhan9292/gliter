//
//  OrderHistoryVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

class OrderHistoryVC: BaseVC {
    
    //MARK:- Properties
    weak var delegate: OrderHistoryDelegate?
    
    lazy var dataSource = OrderHistoryListDatasource()
    
    var viewModel: OrderHistoryVM?
    var itemList: [ProductHistoryItems] = []
    var orderId: Int?
    
    //MARK:- IBOutlet
    @IBOutlet weak var uitOrderHistory: UITableView!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupDelegate()
        viewModel?.loadData()
    }
    
    override func bindView() {
        super.bindView()
        viewModel = OrderHistoryVM(datasource: dataSource)
        
        uitOrderHistory.dataSource = dataSource
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.orderDetailForCart.bind { [weak self] in
            guard let self = self,
                  let productInfo = $0 else { return }
            switch CustomerTypeModel.shared.type {
            case .dropShip:
                if let vc: DoorshipCartDetailVC = self.instantiate(of: .main, with: .doorshipCartDetailVC) {
                    CartItem.shared.cartProduct.value = productInfo
                    vc.delegate = self
                    self.present(vc, animated: true)
                }
            case .wholeSale:
                if let vc: WholesaleCartDetailVC = self.instantiate(of: .main, with: .wholesaleCartDetailVC) {
                    CartItem.shared.cartProduct.value = productInfo
                    vc.delegate = self
                    self.present(vc, animated: true)
                }
            default:
                print("default")
            }
        }
        
        viewModel?.onSuccess.bind {
            guard let message = $0 else { return }
            showSuccessAlert(message: message)
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.addorderToCartVM.bind { [weak self] in
            guard let self = self,
                  let _ = $0
            else { return }
            if let vc: AddOrderToCartDialogVC = self.instantiate(of: .main, with: .addOrderToCartDialogVC) {
                vc.delegate = self
                //            vc.viewModel = changePasswordVM
                self.present(vc, animated: true)
            }
        }
        
        viewModel?.productDetail.bind { [weak self] in
            guard let self = self,
                  let productDetail = $0 else { return }
            if let vc: DownloadOrderPopup = self.instantiate(of: .main, with: .downloadOrderDialogVC) {
                vc.viewModel = DownloadOrderPopupVM(productItems: productDetail)
                self.present(vc, animated: true)
            }
        }
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self
            else {
                return
            }
            
            self.itemList = $0
            self.uitOrderHistory.reloadData()
        }
    }
    
    //MARK:- IBAction
    @IBAction func btnMoreOption(_ sender: UIButton) {
        let point = sender.convert(CGPoint.zero, to: uitOrderHistory)
        
        guard let indexPath = uitOrderHistory.indexPathForRow(at: point)
        else { return }
        
        let view  = UIAlertController(title: nil,
                                      message: nil,
                                      preferredStyle: .actionSheet)
        
        let lookbook = UIAlertAction(title: "Order/Lookbook",
                                     style: .default) { (action) in
            self.lookbookOrder(indexPath: indexPath)
        }
        let duplicate = UIAlertAction(title: "Duplicate",
                                      style: .default) { (action) in
            self.duplicateOrder(indexPath: indexPath)
        }
        let continueOrder = UIAlertAction(title: "Continue",
                                          style: .default) { (action) in
            self.continueOrder(indexPath: indexPath)
        }
        let delete = UIAlertAction(title: "Delete",
                                   style: .default) { (action) in
            self.deleteOrder(indexPath: indexPath)
        }
        
        lookbook.setValue(UIImage(named: "order"), forKey: "image")
        duplicate.setValue(UIImage(named: "duplicate"), forKey: "image")
        continueOrder.setValue(UIImage(named: "continue"), forKey: "image")
        delete.setValue(UIImage(named: "trash"), forKey: "image")
        
        lookbook.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
        duplicate.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
        continueOrder.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
        delete.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
        
        view.addAction(lookbook)
        view.addAction(duplicate)
        view.addAction(continueOrder)
        view.addAction(delete)
        
        if let popoverController = view.popoverPresentationController {
            popoverController.sourceView = uitOrderHistory
            popoverController.sourceRect = CGRect(x: point.x + 35, y: point.y + 17.3, width: 0, height: 0)
            popoverController.permittedArrowDirections = .left
        }
        view.view.tintColor = UIColor().subTitleColor
        view.view.backgroundColor = UIColor.white
        self.present(view, animated: true, completion: nil)
        
    }
}

extension OrderHistoryVC {
    private func setupDelegate() {
        uitOrderHistory.delegate = self
    }
    
    private func lookbookOrder(indexPath: IndexPath) {
        guard let id = itemList[indexPath.row].id else { return }
        viewModel?.loadOrderDetail(orderId: id)
    }
    
    private func duplicateOrder(indexPath: IndexPath) {
        viewModel?.duplicateOrder(index: indexPath.row)
    }
    
    private func continueOrder(indexPath: IndexPath) {
        
        guard let id = itemList[indexPath.row].id else { return }
        orderId = id
        viewModel?.continueOrder()
    }
    
    private func deleteOrder(indexPath: IndexPath) {
        viewModel?.deleteOrder(index: indexPath.row)
    }
}

extension OrderHistoryVC: AddOrderToCardDelegate {
    func shouldAddOrderToCart() {
        guard let orderId = self.orderId else {
            return
        }
        viewModel?.loadOrderDetailForCart(orderId: orderId)
    }
}

extension OrderHistoryVC: CartDetailProtocol {
    func showHistoryController() {
        delegate?.gotoOrderHistoryController()
    }
}


extension OrderHistoryVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let delegate = delegate,
              let orderId = itemList[indexPath.row].id
        else { return }
        
        delegate.goToDetailScreen?(with: orderId)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row % 2 == 0 {
            cell.backgroundColor = UIColor().lighGreyBackground
        }
        else {
            cell.backgroundColor = .clear
        }
        
        if indexPath.row == itemList.count - 1 {
            viewModel?.loadData()
        }
    }
}

