//
//  SelectedItemsVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 26/10/2020.
//

import UIKit

final class SelectedItemsVC: BaseVC {
    
    //MARK:- Properties
    var datasource = ProductSelectionListDatasource()
    var delegate: SelectItemDelegate?
    
    var viewModel: SelectedItemsVM?
    var productItem: [ProductItem] = []
    
    //MARK:- IBOutlet
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var lblItemCount: UILabel!
    
    @IBOutlet weak var uitItemSelection: UITableView!
    
    @IBOutlet weak var btnAddOrder: UIButton!
    
    @IBOutlet weak var uvCreateLookBook: UIView!
    @IBOutlet weak var uvSelectMultipleItems: UIView!
    
    @IBOutlet weak var SwitchMultipleSelection: UISwitch!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupBorderView()
        setupSwitch()
    }
    
    override func bindView() {
        super.bindView()
        viewModel = SelectedItemsVM(datasource: datasource)
        uitItemSelection.dataSource = datasource
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self else { return }
            self.lblItemCount.text = "\($0.count)"
            self.delegate?.updateAllList(item: $0)
            self.productItem = $0
            self.uitItemSelection.reloadData()
        }
        
        viewModel?.openFile.bind { [weak self] in
            guard let self = self,
                  let url = $0 else { return }
            self.openFileAlert(url: url)
        }
        
        viewModel?.showReplaceOrderPopup.bind { [weak self] in
            guard let self = self,
                  let shouldShow = $0 else  { return}
            if shouldShow {
                self.showReplacePopup()
            }
            
        }
    }
    
    //MARK:- IBAction
    @IBAction func btnCreateLookBook(_ sender: UIButton) {
        viewModel?.downloadFile()
    }
    
    @IBAction func btnAddOrder(_ sender: UIButton) {
        viewModel?.addProductToCart(productList: productItem)
        delegate?.addToCart(item: productItem)
    }
    
    @IBAction func btnHideView(_ sender: UIButton) {
        delegate?.hideView()
    }
}

extension SelectedItemsVC {
    private func setupBorderView() {
        btnAddOrder.roundedCorner(radius: 20)
        uvCreateLookBook.roundedCorner(radius: 20)
        uvSelectMultipleItems.roundedCorner(radius: 20)
        
        uvCreateLookBook.setBorder(with: 1.0, and: UIColor().primaryColor)
        uvSelectMultipleItems.setBorder(with: 1.0, and: UIColor().primaryColor)
    }
    
    private func showReplacePopup() {
        let alert = UIAlertController(title: "File Already Exists", message: "File already exist. Do you want to replace?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Replace", style: .default, handler: { _ in
            self.viewModel?.replaceFile()
        }))
        
        alert.addAction(UIAlertAction(title: "Open Previous File", style: .default, handler: { _ in
            self.viewModel?.openSavedFile()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    
    private func openFileAlert(url: URL) {
        let alert = UIAlertController(title: "Open File",
                                      message: "Do you want to open this file?",
                                      preferredStyle: .alert)
        
        alert
            .addAction(UIAlertAction(title: "Open",
                                     style: .default,
                                     handler: { _ in
                                        UIApplication.shared.open(url)
                                     }))
        
        alert
            .addAction(UIAlertAction(title: "Cancel",
                                     style: .cancel,
                                     handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    
    
    private func setupSwitch() {
        SwitchMultipleSelection.setOn(false, animated: false)
        SwitchMultipleSelection.addTarget(self, action: #selector(didTapSwitch), for:UIControl.Event.valueChanged)
    }
    
    @objc private func didTapSwitch(state: UISwitch) {
        if state.isOn {
            lblState.text = "ON"
        }
        else {
            lblState.text = "OFF"
        }
        delegate?.updateMultipleSelection(isOn: state.isOn)
    }
}

extension SelectedItemsVC: SelectItemDelegate {
    func selectItem(item: ProductItem) {
        viewModel?.updateData(item:item)
    }
    
    func singleSelectItem(item: ProductItem) {
        viewModel?.updateDataForSingleSelection(item: item)
    }
}

class ProductSelectionListDatasource: GenericDataSource<ProductItem>, UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ItemSelectionCell.identifier(),for: indexPath) as? ItemSelectionCell else {
            return UITableViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
}
