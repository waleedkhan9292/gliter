//
//  CartTotalCountVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

final class CartTotalCountVC: BaseVC {
    
    //MARK:- Properties
    weak var delegate: UpdateCartItemDelegate?
    
    //MARK:- IBOutlet
    @IBOutlet weak var uvCartItems: UIView!
    @IBOutlet weak var uvSelectedCartItems: UIView!
    
    @IBOutlet weak var lblCartItems: UILabel!
    @IBOutlet weak var lblSelectedCartItems: UILabel!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupRoundedCornerView()
    }
    
    override func bindView() {
        super.bindView()
    }
    
    //MARK:- IBAction
    @IBAction func btnShowCartView(_ sender: UIButton) {
        delegate?.showCartView?()
    }
    
    @IBAction func btnShowSelectionView(_ sender: UIButton) {
        delegate?.showSelectionView?()
    }

}

extension CartTotalCountVC {
    
    //MARK:- Methods
    func setupRoundedCornerView() {
        uvCartItems.roundedCorner(radius: 25)
        uvSelectedCartItems.roundedCorner(radius: 25)
        uvCartItems.setBorder(with: 1.0, and: UIColor().primaryColor)
        uvSelectedCartItems.setBorder(with: 1.0, and: UIColor().primaryColor)
    }
    
}

extension CartTotalCountVC: ProductCatalogDelegate {
    func loadData<T>(productList: [T]) {
        print("asdf")
    }
    
    
    func updateProductListSelection(items: [ProductItem]) {
        lblSelectedCartItems.text = "\(items.count)"
    }
}
