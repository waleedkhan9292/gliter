//
//  CustomVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 12/10/2020.
//

import UIKit
import WebKit

final class CustomVC: UIViewController {
    
    @IBOutlet weak var wvCustom: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
            guard let filePath = Bundle.main.path(forResource: "custom", ofType: "html")
            else {
                // File Error
                print ("File reading error")
                return
            }
            
            let contents =  try String(contentsOfFile: filePath, encoding: .utf8)
            let baseUrl = URL(fileURLWithPath: filePath)
            wvCustom.loadHTMLString(contents as String, baseURL: baseUrl)
        }
        catch {
            print ("File HTML error")
        }
    }
    
}
