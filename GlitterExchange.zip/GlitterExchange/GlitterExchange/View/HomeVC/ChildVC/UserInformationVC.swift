//
//  UserInformationVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 05/10/2020.
//

import UIKit
import MaterialComponents

class UserInformationVC: BaseVC {
    
    //MARK:- IBOutlet
    @IBOutlet weak var tfFullName: UITextField!
    @IBOutlet weak var tfCompanyName: UITextField!
    @IBOutlet weak var tfStreet: UITextField!
    @IBOutlet weak var tfCity: UITextField!
    @IBOutlet weak var tfAddressLane2: UITextField!
    @IBOutlet weak var tfState: UITextField!
    @IBOutlet weak var tfZipCode: UITextField!
    @IBOutlet weak var tfCountry: UITextField!
    
    @IBOutlet weak var btnChangePassword: UIButton!
    @IBOutlet weak var btnSave: UIButton!
    
    
    //MARK:- Properties
    var viewModel: UserInformationVM? = {
        return UserInformationVM()
    }()
    
    var tfArray: [UITextField : String] = [:]
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        setupTextField()
        setupRoundedCorner()
        viewModel?.getMyProfile()
    }
    
    override func bindView() {
        super.bindView()
        
        viewModel?.error.bind {
            guard let error = $0
            else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.isLoading.bind {
            guard let isLoading = $0 else { return }
            isLoading ? showLoader(): hideLoader()
        }
        
        viewModel?.onSuccess.bind {
            guard let message = $0 else { return }
            showSuccessAlert(message: message)
        }
        
        viewModel?.updateProfile.bind { [weak self] in
            guard let self = self,
                  let profile = $0
            else { return }
            
            self.setupTextField(profile: profile)
        }
        
        viewModel?.changePasswordVM.bind { [weak self] in
            guard let self = self,
                  let changePasswordVM = $0 else { return }
            if let vc: ChangePasswordDialogVC = self.instantiate(of: .main, with: .changePasswordDialogVC) {
                vc.viewModel = changePasswordVM
                self.present(vc, animated: true)
            }
        }
    }
    
    //MARK:- IBAction
    @IBAction func btnChangePassword(_ sender: UIButton) {
        viewModel?.gotoChangePassword()
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
        viewModel?.updateUserProfile()
    }
    
}

extension UserInformationVC {
    
    //MARK:- Methods
    
    private func setupTextField() {
        tfArray = [
            tfFullName : "Full Name*",
            tfCompanyName : "CompanyName*",
            tfStreet : "Street/Apt*",
            tfCity : "City*",
            tfAddressLane2 : "AddressLane2",
            tfState : "State*",
            tfZipCode : "ZipCode*",
            tfCountry : "Country*"
        ]
        
        tfArray.forEach { textField in
            textField.key.text = ""
            textField.key.attributedPlaceholder = NSAttributedString(string: textField.value, attributes: [NSAttributedString.Key.foregroundColor: UIColor().titleColor])
//            textField.key.label.text = textField.value
//            textField.key.setupTextField()
            textField.key.addPaddingToTextField()
            textField.key.setBorder(with: 1.0, and: UIColor().titleColor)
            textField.key.textColor = UIColor().titleDarkGrey
            textField.key.delegate = self
        }
    }
    
    private func setupRoundedCorner() {
        btnSave.roundedCorner(radius: btnSave.frame.height/2)
        btnChangePassword.roundedCorner(radius: btnChangePassword.frame.height/2)
    }
    
    private func setupTextField(profile: Profile) {
        tfFullName.text = profile.name
        tfCompanyName.text = profile.companyName
        tfStreet.text = profile.street
        tfCity.text = profile.city
        tfAddressLane2.text = profile.address
        tfState.text = profile.state
        tfZipCode.text = profile.zIPCode
        tfCountry.text  = profile.country
    }
}



extension UserInformationVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel?.updateUserProfile()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfFullName:
            self.viewModel?.fullName = textAfterUpdate
        case tfCompanyName:
            self.viewModel?.companyName = textAfterUpdate
        case tfZipCode:
            self.viewModel?.zipCode = textAfterUpdate
        case tfCity:
            self.viewModel?.city = textAfterUpdate
        case tfState:
            self.viewModel?.state = textAfterUpdate
        case tfCountry:
            self.viewModel?.country = textAfterUpdate
        case tfAddressLane2:
            self.viewModel?.fullName = textAfterUpdate
        case tfStreet:
            self.viewModel?.companyName = textAfterUpdate
        default:
            break
            
            }
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case tfFullName:
            self.viewModel?.fullName = ""
        case tfCompanyName:
            self.viewModel?.companyName = ""
        case tfZipCode:
            self.viewModel?.zipCode = ""
        case tfCity:
            self.viewModel?.city = ""
        case tfState:
            self.viewModel?.state = ""
        case tfCountry:
            self.viewModel?.country = ""
        case tfAddressLane2:
            self.viewModel?.fullName = ""
        case tfStreet:
            self.viewModel?.companyName = ""
        default:
            break
        }
        return true
    }
}

