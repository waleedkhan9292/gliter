//
//  OrderHistoryDetailVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 10/10/2020.
//

import UIKit

final class OrderHistoryDetailVC: BaseVC {
    
    //MARK:- Properties
    
    var viewModel: OrderHistoryDetailVM?
    var orderId: Int?
    weak var delegate: OrderHistoryDetailDelegate?
    
    lazy var dataSource = OrderHistoryDetailListDatasource()
    
    var productInfo: ProductHistoryItems?
    
    //MARK:- IBOutlet
    @IBOutlet weak var uvDoorshipView: UIView!
    
    @IBOutlet weak var lblOrderPO: UILabel!
    @IBOutlet weak var lblOrderDate: UILabel!
    @IBOutlet weak var lblGrandPrice: UILabel!
    @IBOutlet weak var lblOrderTitle: UILabel!
    @IBOutlet weak var lblBillAddress: UILabel!
    @IBOutlet weak var lblShipAddress: UILabel!
    @IBOutlet weak var lblOrderStatus: UILabel!
    @IBOutlet weak var lblOrderSubTitile: UILabel!
    @IBOutlet weak var lblDoorshipPrice: UILabel!
    
    @IBOutlet weak var btnDeleteOrder: UIButton!
    @IBOutlet weak var btnDownloadOrder: UIButton!
    @IBOutlet weak var btnContinueOrder: UIButton!
    @IBOutlet weak var btnDuplicateOrder: UIButton!
    
    @IBOutlet weak var uitItems: UITableView!
    
    @IBOutlet weak var constraintDoorshipViewHeight: NSLayoutConstraint!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        hideDropShipView()
        setupDelegate()
        setupRoundedCorner()
    }
    
    
    override func bindView() {
        super.bindView()
        
        viewModel = OrderHistoryDetailVM(datasource: dataSource)
        
        uitItems.dataSource = dataSource
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.onSuccess.bind {
            guard let message = $0 else { return }
            showSuccessAlert(message: message)
        }
        
        viewModel?.setTitle.bind { [weak self] in
            guard let self = self,
                  let title = $0
            else { return }
            self.lblOrderSubTitile.text = title
            self.lblOrderTitle.text = "Order History > \(title)"
        }
        
        viewModel?.status.bind { [weak self] in
            guard let self = self,
                  let status = $0
            else { return }
            self.lblOrderStatus.text = status
        }
        
        
        viewModel?.billAddress.bind { [weak self] in
            guard let self = self,
                  let billAddress = $0
            else { return }
            self.lblBillAddress.text = billAddress
        }
        
        viewModel?.shipAddress.bind { [weak self] in
            guard let self = self,
                  let shipAddress = $0
            else { return }
            self.lblShipAddress.text = shipAddress
        }
        
        viewModel?.setTotalPrice.bind { [weak self] in
            guard let self = self,
                  let totalPrice = $0
            else { return }
            self.lblGrandPrice.text = "$\(totalPrice)"
        }
        
        viewModel?.orderDate.bind { [weak self] in
            guard let self = self,
                  let date = $0
            else { return }
            self.lblOrderDate.text = "Order Date \(date)"
        }
        
        viewModel?.poNumber.bind { [weak self] in
            guard let self = self,
                  let poNumber = $0
            else { return }
            self.lblOrderPO.text = "PO #: \(poNumber)"
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0
            else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.addorderToCartVM.bind { [weak self] in
            guard let self = self,
                  let addOrderToCart = $0,
                  let productInfo = self.productInfo else { return }
            if addOrderToCart {
                if let vc: AddOrderToCartDialogVC = self.instantiate(of: .main, with: .addOrderToCartDialogVC) {
                    vc.delegate = self
                    self.present(vc, animated: true)
                }
            }
        }
        
        viewModel?.dropshipFee.bind { [weak self] in
            guard let self = self,
                  let fee = $0
            else { return }
            self.showDropShipView(with: fee)
        }
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self else { return }
            _ = $0
            self.uitItems.reloadData()
        }
        
        viewModel?.shouldGoToBackScreen.bind { [weak self] in
            guard let self = self,
                  let shouldGoBack = $0
            else {  return }
            if shouldGoBack {
                self.delegate?.goToHistoryScreen?()
            }
        }
        
        viewModel?.productInfo.bind { [weak self] in
            guard let self = self,
                  let productInfo = $0
            else { return }
            self.productInfo = productInfo
        }
    }
    
    //MARK:- IBAction
    @IBAction func btnContinueOrder(_ sender: UIButton) {
        viewModel?.continueOrder()
    }
    
    @IBAction func btnDuplicateOrder(_ sender: Any) {
        viewModel?.duplicateOrder()
    }
    
    @IBAction func btnDownloadOrder(_ sender: UIButton) {
        guard let productInfo = productInfo else {
            return
        }
        if let vc: DownloadOrderPopup = instantiate(of: .main, with: .downloadOrderDialogVC) {
            vc.viewModel = DownloadOrderPopupVM(productItems: productInfo)
            self.present(vc, animated: true)
        }
    }
    
    @IBAction func btnDeleteOrder(_ sender: UIButton) {
        viewModel?.deleteOrder()
    }
    
    @IBAction func btnGobackScreen(_ sender: UIButton) {
        viewModel?.gotoBackScreen()
    }
}

extension OrderHistoryDetailVC {
    
    private func setupDelegate() {
        uitItems.delegate = self
    }
    
    private func hideDropShipView() {
        lblDoorshipPrice.text = ""
        constraintDoorshipViewHeight.constant = 0
        uvDoorshipView.isHidden = true
    }
    
    private func showDropShipView(with fee: String) {
        lblDoorshipPrice.text = fee
        constraintDoorshipViewHeight.constant = 50
        uvDoorshipView.isHidden = false
    }
    
    private func setupRoundedCorner() {
        btnDeleteOrder.roundedCorner(radius: 20)
        btnDownloadOrder.roundedCorner(radius: 20)
        btnContinueOrder.roundedCorner(radius: 20)
        btnDuplicateOrder.roundedCorner(radius: 20)
        
        btnDeleteOrder.setBorder(with: 1, and: UIColor().secondaryColor)
        btnDownloadOrder.setBorder(with: 1, and: UIColor().primaryColor)
        btnContinueOrder.setBorder(with: 1, and: UIColor().primaryColor)
        btnDuplicateOrder.setBorder(with: 1, and: UIColor().primaryColor)
    }
}

extension OrderHistoryDetailVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row % 2 == 0 {
            cell.backgroundColor = UIColor().lighGreyBackground
        }
        else {
            cell.backgroundColor = .clear
        }
    }
}

extension OrderHistoryDetailVC: AddOrderToCardDelegate {
    func shouldAddOrderToCart() {
        
        switch CustomerTypeModel.shared.type {
        case .dropShip:
            if let vc: DoorshipCartDetailVC = instantiate(of: .main, with: .doorshipCartDetailVC) {
                CartItem.shared.cartProduct.value = productInfo
                vc.delegate = self
                self.present(vc, animated: true)
            }
        case .wholeSale:
            if let vc: WholesaleCartDetailVC = instantiate(of: .main, with: .wholesaleCartDetailVC) {
                CartItem.shared.cartProduct.value = productInfo
                vc.delegate = self
                self.present(vc, animated: true)
            }
        default:
            print("default")
        }
    }
}

class OrderHistoryDetailListDatasource: GenericDataSource<Item>, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: OrderHistoryProductDetailCell.identifier(),for: indexPath) as? OrderHistoryProductDetailCell else {
            return UITableViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
}

extension OrderHistoryDetailVC: TabDelegate {
    func setOrderId(with orderId:Int) {
        viewModel?.loadData(orderId: orderId)
    }
}

extension OrderHistoryDetailVC: CartDetailProtocol {
    func showHistoryController() {
        self.delegate?.goToHistoryScreen?()
    }
}

