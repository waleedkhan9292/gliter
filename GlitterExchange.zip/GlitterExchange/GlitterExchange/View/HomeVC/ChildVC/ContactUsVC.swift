//
//  ContactUsVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 05/10/2020.
//

import UIKit
import MaterialComponents

class ContactUsVC: BaseVC {
    
    @IBOutlet weak var tfSubject: UITextField!
    
    @IBOutlet weak var tvMessage: UITextView!
    
    @IBOutlet weak var btnSendMessage: UIButton!
    
    
    //MARK:- Properties
    private lazy var viewModel: ContactUsVM? = {
        return ContactUsVM()
    }()
    
    //MARK:- Functions
    
    override func configureView() {
        super.configureView()
        setupDelegate()
//        tfSubject.label.text = "Subject*"
//        tfSubject.setupTextField()
        setupTextField()
        tvMessage.setBorder(with: 1.0, and: UIColor.black)
        setupTextViewPlaceHolder()
        roundedCorner()
    }
    
    override func bindView() {
        super.bindView()
        viewModel?.error.bind {
            guard let error = $0
            else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.isLoading.bind {
            guard let isLoading = $0 else { return }
            isLoading ? showLoader(): hideLoader()
        }
        
        viewModel?.onSuccess.bind {
            guard let message = $0 else { return }
            showSuccessAlert(message: message)
            self.tfSubject.text = ""
            self.setupTextViewPlaceHolder()
            self.tfSubject.resignFirstResponder()
            self.tvMessage.resignFirstResponder()
        }
    }
    
    //MARK:- IBAction
    @IBAction func btnSendMessage(_ sender: UIButton) {
        viewModel?.contactUs()
    }
    
    
}


extension ContactUsVC {
    private func setupDelegate() {
        tvMessage.delegate = self
        tfSubject.delegate = self
    }
    
    private func setupTextField() {
        
        tfSubject.setBorder(with: 1.0, and: UIColor().titleColor)
        tfSubject.attributedPlaceholder = NSAttributedString(string: "Subject*", attributes: [NSAttributedString.Key.foregroundColor: UIColor().titleColor])
        tfSubject.addPaddingToTextField()
        tfSubject.textColor = UIColor().titleDarkGrey
    }
    
    private func setupTextViewPlaceHolder() {
        tvMessage.text = "Message*"
        tvMessage.textColor =  UIColor().titleColor
        tvMessage.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        tvMessage.setBorder(with: 1.0, and: UIColor().titleColor)
    }
    
    private func roundedCorner() {
        btnSendMessage.roundedCorner(radius: btnSendMessage.frame.height/2)
    }
    
}

extension ContactUsVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel?.contactUs()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfSubject:
            self.viewModel?.subject = textAfterUpdate
        default:
            break
        }
        
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case tfSubject:
            self.viewModel?.subject = ""
        default:
            break
        }
        return true
    }
}
extension ContactUsVC: UITextViewDelegate {
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor().titleDarkGrey
        }
    }
    
    func textViewDidChange(_ textView: UITextView) {
        viewModel?.message = textView.text
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Message*"
            textView.textColor = UIColor().subTitleColor
        }
    }
    
}
