//
//  ProductsNameVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

class ProductsNameVC: BaseVC {
    
    //MARK:- IBOutlet Properties
    @IBOutlet weak var uitProductsName: UITableView!
    
    //MARK:- Properties
    var viewModel: ProductNameVM?
    
    var dataSource = ProductOrderListDatasource()
    
    var delegate: SelectItemDelegate?
    
    var productList: [ProductItem] = []
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        setupDelegate()
    }
    
    override func bindView() {
        super.bindView()
        viewModel = ProductNameVM(datasource: dataSource)
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self else { return }
            self.productList = $0
            self.uitProductsName.reloadData()
        }
        
        viewModel?.multipleSelectionItem.bind { [weak self] in
            guard let self = self,
                  let item = $0 else { return }
            self.delegate?.selectItem(item: item)
        }
        
        
        viewModel?.singleSelectionItem.bind { [weak self] in
            guard let self = self,
                  let item = $0 else { return }
            self.delegate?.singleSelectItem(item: item)
        }
    }
    
    //MARK:- IBAction
}

extension ProductsNameVC {
    
    //MARK:- Methods
    func setupDelegate() {
        uitProductsName.dataSource = dataSource
        uitProductsName.delegate = self
    }
    
}

extension ProductsNameVC: ProductCatalogDelegate {
    func loadData<T>(productList: [T]) {
        viewModel?.loadData(productList: productList as! [ProductItem])
    }
    
    func updateImagesMultipleSelection(isOn: Bool) {
        viewModel?.setMultipleSelection(isOn: isOn)
    }
    
    func updateProductListSelection(items: [ProductItem]) {
        viewModel?.updateView(items: items)
    }
}

extension ProductsNameVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewModel?.selectItem(item: productList[indexPath.row])
    }
}

class ProductOrderListDatasource: GenericDataSource<ProductItem>, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: PetCatalogCell.identifier(),for: indexPath) as? PetCatalogCell else {
            return UITableViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
}

