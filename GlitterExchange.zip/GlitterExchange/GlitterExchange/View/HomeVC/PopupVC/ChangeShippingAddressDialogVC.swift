//
//  ChangeShippingAddressDialogVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 17/11/2020.
//

import UIKit
import MaterialComponents

final class ChangeShippingAddressDialogVC:  BaseVC {
    
    // MARK: - Properties
    var tfArray: [MDCUnderlinedTextField : String] = [:]
    lazy var viewModel: ChangeShippingAddressDialogVM? = {
        return ChangeShippingAddressDialogVM()
    }()
    var delegate: ChangeShippingAddressDelegate?
    
    // MARK: - IBOutlet
    @IBOutlet weak var tfCompanyName: MDCUnderlinedTextField!
    @IBOutlet weak var tfCustomerName: MDCUnderlinedTextField!
    @IBOutlet weak var tfAddressLine1: MDCUnderlinedTextField!
    @IBOutlet weak var tfAddressLine2: MDCUnderlinedTextField!
    @IBOutlet weak var tfCity: MDCUnderlinedTextField!
    @IBOutlet weak var tfState: MDCUnderlinedTextField!
    @IBOutlet weak var tfCountry: MDCUnderlinedTextField!
    @IBOutlet weak var tfZipCode: MDCUnderlinedTextField!
    
    @IBOutlet weak var btnSave: UIButton!
    
    @IBOutlet weak var uvContentView: UIView!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupTextField()
        setupRoundedCorner()
        viewModel?.loadData()
    }
    
    override func bindView() {
        super.bindView()
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.onSucess.bind { [weak self] in
            guard let self = self,
                  let message = $0 else { return }
            showSuccessAlert(message: message)
            self.delegate?.updateViewForShiping()
            self.dismiss(animated: true)
        }
        
        viewModel?.tfCompanyName.bind { [weak self] in
            guard let self = self else { return }
            self.tfCompanyName.text = $0
        }
        viewModel?.tfCustomerName.bind { [weak self] in
            guard let self = self else { return }
            self.tfCustomerName.text = $0
        }
        viewModel?.tfAddressName1.bind { [weak self] in
            guard let self = self else { return }
            self.tfAddressLine1.text = $0
        }
        viewModel?.tfAddressName2.bind { [weak self] in
            guard let self = self else { return }
            self.tfAddressLine2.text = $0
        }
        viewModel?.tfCity.bind { [weak self] in
            guard let self = self else { return }
            self.tfCity.text = $0
        }
        viewModel?.tfState.bind { [weak self] in
            guard let self = self else { return }
            self.tfState.text = $0
        }
        viewModel?.tfCountry.bind { [weak self] in
            guard let self = self else { return }
            self.tfCountry.text = $0
        }
        viewModel?.tfZipCode.bind { [weak self] in
            guard let self = self else { return }
            self.tfZipCode.text = $0
        }
        
    }
    
    // MARK: - IBAction
    @IBAction func btnDismissController(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
        viewModel?.changeShipingAddress()
    }
    
}

extension ChangeShippingAddressDialogVC {
    
    // MARK: - Methods
    func setupTextField() {
        
        tfArray = [
            tfCompanyName : "Company Name",
            tfCustomerName : "Customer Name*",
            tfAddressLine1 : "Address Line1 *",
            tfAddressLine2 : "Address Line2",
            tfCity : "City *",
            tfState : "State *",
            tfCountry : "Country *",
            tfZipCode : "Zip Code *",
        ]
        
        tfArray.forEach { textField in
            textField.key.text = ""
            textField.key.label.text = textField.value
            textField.key.setupTextField()
            textField.key.delegate = self
        }
    }
    
    func setupRoundedCorner() {
        btnSave.roundedCorner(radius: 5)
        uvContentView.roundedCorner(radius: 5)
    }
}


extension ChangeShippingAddressDialogVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel?.changeShipingAddress()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfCompanyName:
            self.viewModel?.companyName = textAfterUpdate
        case tfCustomerName:
            self.viewModel?.customerName = textAfterUpdate
        case tfAddressLine1:
            self.viewModel?.addressName1 = textAfterUpdate
        case tfAddressLine2:
            self.viewModel?.addressName2 = textAfterUpdate
        case tfCity:
            self.viewModel?.city = textAfterUpdate
        case tfState:
            self.viewModel?.state = textAfterUpdate
        case tfCountry:
            self.viewModel?.country = textAfterUpdate
        case tfZipCode:
            self.viewModel?.zipCode = textAfterUpdate
        default:
            break
        }
        
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case tfCompanyName:
            self.viewModel?.companyName = ""
        case tfCustomerName:
            self.viewModel?.customerName = ""
        case tfAddressLine1:
            self.viewModel?.addressName1 = ""
        case tfAddressLine2:
            self.viewModel?.addressName2 = ""
        case tfCity:
            self.viewModel?.city = ""
        case tfState:
            self.viewModel?.state = ""
        case tfCountry:
            self.viewModel?.country = ""
        case tfZipCode:
            self.viewModel?.zipCode = ""
        default:
            break
        }
        
        return true
    }
}


