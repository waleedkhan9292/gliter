//
//  ChangePasswordDialogVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 12/10/2020.
//

import UIKit
import MaterialComponents

final class ChangePasswordDialogVC:  BaseVC {
    
    // MARK: - Properties
    var tfArray: [MDCUnderlinedTextField : String] = [:]
    var viewModel: ChangePasswordDialogVM?
    
    // MARK: - IBOutlet
    @IBOutlet weak var tfNewPassword: MDCUnderlinedTextField!
    @IBOutlet weak var tfCurrentPassword: MDCUnderlinedTextField!
    @IBOutlet weak var tfConfirmPassword: MDCUnderlinedTextField!
    
    @IBOutlet weak var btnSave: UIButton!
    
    @IBOutlet weak var uvContentView: UIView!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupTextField()
        setupRoundedCorner()
    }
    
    override func bindView() {
        super.bindView()
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.onSucess.bind { [weak self] in
            guard let self = self,
                  let message = $0 else { return }
            showSuccessAlert(message: message)
            self.dismiss(animated: true)
        }

    }
    
    // MARK: - IBAction
    @IBAction func btnDismissController(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
        viewModel?.changePassword()
    }

}

extension ChangePasswordDialogVC {
    
    // MARK: - Methods
    func setupTextField() {
        
        tfArray = [
            tfCurrentPassword : "Current Password*",
            tfNewPassword : "New Password*",
            tfConfirmPassword : "Confirm Password*"
        ]
        
        tfArray.forEach { textField in
            textField.key.text = ""
            textField.key.label.text = textField.value
            textField.key.setupTextField()
            textField.key.delegate = self
        }
    }
    
    func setupRoundedCorner() {
        btnSave.roundedCorner(radius: 5)
        uvContentView.roundedCorner(radius: 5)
    }
}


extension ChangePasswordDialogVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel?.changePassword()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfConfirmPassword:
            self.viewModel?.confirmPassword = textAfterUpdate
        case tfCurrentPassword:
            self.viewModel?.currentPassword = textAfterUpdate
        case tfNewPassword:
            self.viewModel?.newPassword = textAfterUpdate
        default:
            break
        }
        
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case tfConfirmPassword:
            self.viewModel?.confirmPassword = ""
        case tfCurrentPassword:
            self.viewModel?.currentPassword = ""
        case tfNewPassword:
            self.viewModel?.newPassword = ""
        default:
            break
        }
        return true
    }
}

