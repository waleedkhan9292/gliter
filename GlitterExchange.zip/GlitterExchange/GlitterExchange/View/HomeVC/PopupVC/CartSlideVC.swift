//
//  CartSlideVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 11/10/2020.
//

import UIKit

final class CartSlideVC: BaseVC {
    
    //MARK:- Properties
    var delegate: CartProtocol?
    var viewModel: CartSlideVM?
    var dataSource = CartListDatasource()
    var productList: [Item]!
    var isControllerDissmissed = true
//    private var apiClient: ApiClientProtocol
    
    //MARK:- IBOutlet
    @IBOutlet weak var uvContentView: UIView!
    
    @IBOutlet weak var btnProceedNext: UIButton!
    @IBOutlet weak var btnPrintOrEmailOrder: UIButton!
    @IBOutlet weak var btnGotoDiffrentCategory: UIButton!
    
    @IBOutlet weak var lblCartItemsCount: UILabel!
    @IBOutlet weak var uvCartNumberOfItems: UIView!
    
    @IBOutlet weak var uitPorductItems: UITableView!
    
    //MARK:- Constructor
//    init(apiClient: ApiClientProtocol) {
//        self.apiClient = apiClient
//        super.init(nibName: nil, bundle: nil)
//    }
    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        setupRoundedCorner()
        viewModel?.loadData()
    }
    
    override func bindView() {
        super.bindView()
        viewModel = CartSlideVM(datasource: dataSource)
        
        uitPorductItems.dataSource = dataSource
        
        
        viewModel?.isLoading.bind {
            guard let isLoading = $0 else { return }
            isLoading ? showLoader(): hideLoader()
        }
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self else { return }
            self.productList = $0
        
            self.uitPorductItems.reloadData()
        }
        
        viewModel?.updateQuantityLabel.bind { [weak self] in
            guard let self = self else { return }
            self.lblCartItemsCount.text = $0
        }
        viewModel?.downloadOrderPopupVM.bind { [weak self] in
            guard let self = self,
                  let downloadOrderPopupVM = $0 else { return }
            if let vc: DownloadOrderPopup = self.instantiate(of: .main, with: .downloadOrderDialogVC) {
                vc.viewModel = downloadOrderPopupVM
                self.present(vc, animated: true)
            }
        }
        
        viewModel?.shouldProceedNext.bind { [weak self] in
            guard let self = self,
                  let shouldProceed = $0 else { return }
            if shouldProceed {
                self.dismiss(animated: true, completion: {
                    self.delegate?.gotoCartDetailController()
                })
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        swipeRightToLeft(view: uvContentView)
        isControllerDissmissed = false
    }
    
    //MARK:- IBAction
    @IBAction func btnBack(_ sender: UIButton) {
        swipeLeftToRight(view: uvContentView)
    }
    
    @IBAction func btnGotoDiffrentCategory(_ sender: UIButton) {
        self.dismiss(animated: true, completion: {
            self.delegate?.gotoHomeControllerFromCart()
        })
    }
    
    @IBAction func btnPrintOrEmailOrder(_ sender: UIButton) {
        viewModel?.gotoDownloadPopup()
    }
    
    @IBAction func btnProceedNext(_ sender: UIButton) {
        viewModel?.createOrder()
    }
    
    @IBAction func btnSubtractQuantity(_ sender: UIButton) {
        let point = sender.convert(CGPoint.zero, to: uitPorductItems)
        
        guard let indexPath = uitPorductItems.indexPathForRow(at: point)
        else { return }
        viewModel?.updateQuantity(of: productList[indexPath.row], with: -1)
    }
    
    @IBAction func btnAddQuantity(_ sender: UIButton) {
        let point = sender.convert(CGPoint.zero, to: uitPorductItems)
        
        guard let indexPath = uitPorductItems.indexPathForRow(at: point)
        else { return }
        viewModel?.updateQuantity(of: productList[indexPath.row], with: 1)
    }
    
}
extension CartSlideVC {
    
    //MARK:- Methods
    func setupRoundedCorner() {
        btnProceedNext.roundedCorner(radius: 20)
        uvCartNumberOfItems.roundTopCorner(radius: 20)
        btnPrintOrEmailOrder.roundedCorner(radius: 20)
        btnGotoDiffrentCategory.roundedCorner(radius: 20)
        
        btnProceedNext.setBorder(with: 1.0, and: UIColor().primaryColor)
        uvCartNumberOfItems.setBorder(with: 1.0, and: UIColor().lighGreyBackground)
        btnPrintOrEmailOrder.setBorder(with: 1.0, and: UIColor().primaryColor)
        btnGotoDiffrentCategory.setBorder(with: 1.0, and: UIColor().primaryColor)
        
    }
    
    func swipeRightToLeft(view: UIView) {
        let screenRect = UIScreen.main.bounds
        UIView.animate(
            withDuration: 0.5,
            delay: 0.0,
            options: .curveEaseOut,
            animations: {
                view.frame = CGRect(
                    x:screenRect.size.width - view.frame.size.width,
                    y:view.frame.origin.y,
                    width:view.frame.size.width,
                    height:view.frame.size.height)
            })
    }
    
    func swipeLeftToRight(view: UIView) {
        let screenRect = UIScreen.main.bounds
        UIView.animate(
            withDuration: 0.5,
            delay: 0.0,
            options: .curveEaseIn,
            animations: {
                view.frame = CGRect(
                    x:screenRect.size.width + view.frame.size.width,
                    y:view.frame.origin.y,
                    width:view.frame.size.width,
                    height:view.frame.size.height)
            }) { finished in
            self.isControllerDissmissed = true
            self.dismiss(animated: true)
        }
    }
}

class CartListDatasource: GenericDataSource<Item>, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CartItemCell.identifier(),for: indexPath) as? CartItemCell else {
            return UITableViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
}
