//
//  AddOrderToCartDialogVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 20/10/2020.
//

import UIKit
protocol AddOrderToCardDelegate {
    func shouldAddOrderToCart()
}

final class AddOrderToCartDialogVC: BaseVC {
    
    // MARK: - Properties
    var delegate: AddOrderToCardDelegate?
    
    // MARK: - IBOutlet
    @IBOutlet weak var uvNoButtonView: UIView!
    @IBOutlet weak var uvYesButtonView: UIView!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupRoundedCorner()
    }
    
    override func bindView() {
        super.bindView()
    }
    
    // MARK: - IBAction
    @IBAction func btnNo(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func btnYes(_ sender: UIButton) {
        dismiss(animated: true, completion: {
            self.delegate?.shouldAddOrderToCart()
        })
    }

}

extension AddOrderToCartDialogVC {
    
    // MARK: - Methods
    func setupRoundedCorner() {
        uvNoButtonView.roundedCorner(radius: 22)
        uvYesButtonView.roundedCorner(radius: 22)
        uvNoButtonView.setBorder(with: 1.0, and: UIColor().primaryColor)
        uvYesButtonView.setBorder(with: 1.0, and: UIColor().primaryColor)
    }
}
