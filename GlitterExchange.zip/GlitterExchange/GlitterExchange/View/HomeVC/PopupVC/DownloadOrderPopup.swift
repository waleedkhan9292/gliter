//
//  DownloadOrderPopup.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 28/10/2020.
//

import UIKit

final class DownloadOrderPopup: BaseVC {
    
    // MARK: - Properties
    var viewModel: DownloadOrderPopupVM?
    
    // MARK: - IBOutlet
    @IBOutlet weak var tfEmailAddress: UITextField!
    
    @IBOutlet weak var uvHidePriceCheckmark: UIView!
    @IBOutlet weak var uvHidePrice: UIView!
    @IBOutlet weak var uvPrintBackground: UIView!
    @IBOutlet weak var uvLookbookBackground: UIView!
    @IBOutlet weak var uvExcelBackground: UIView!
    
    @IBOutlet weak var btnHidePrice: UIButton!
    @IBOutlet weak var btnSendEmail: UIButton!
    @IBOutlet weak var btnDownlowadFile: UIButton!
    @IBOutlet weak var btnCreateLookbook: UIButton!
    @IBOutlet weak var btnDownloadExelFile: UIButton!
    @IBOutlet weak var btnPrintOrEmailOrder: UIButton!

    @IBOutlet weak var ivDownloadExcel: UIImageView!
    @IBOutlet weak var ivCatalogItem: UIImageView!
    @IBOutlet weak var ivPrintOrder: UIImageView!
    @IBOutlet weak var ivContenImage: UIImageView!
    
    @IBOutlet weak var lblExcelFile: UILabel!
    @IBOutlet weak var lblCreateLookbook: UILabel!
    @IBOutlet weak var lblPrint: UILabel!
    @IBOutlet weak var lblContentLabel: UILabel!
    @IBOutlet weak var lblContentDetail: UILabel!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        roundedCorner()
        setPlaceHolederColor()
        textFieldDelegate()
    }
    
    override func bindView() {
        super.bindView()
        viewModel?.setType.bind { [weak self] in
            guard let self = self else { return }
            self.setView(type: $0)
        }
        
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.onSuccess.bind {
            guard let message = $0 else { return }
            showSuccessAlert(message: message)
        }
        
        viewModel?.hidePrice.bind { [weak self] in
            guard let self = self else { return }
            self.btnHidePrice.isSelected = $0
        }
        
        viewModel?.openFile.bind { [weak self] in
            guard let self = self,
                  let url = $0 else { return }
            self.openFileAlert(url: url)
        }
        
        viewModel?.showReplaceOrderPopup.bind { [weak self] in
            guard let self = self,
                  let shouldShow = $0 else  { return}
            if shouldShow {
                self.showReplacePopup()
            }
            
        }
        
    }
    
    // MARK: - IBAction
    @IBAction func btnDownloadFile(_ sender: UIButton) {
        viewModel?.downloadFile()
    }
    
    @IBAction func btnPrintOrEmailOrder(_ sender: UIButton) {
        viewModel?.setView(type: .print)
    }
    
    @IBAction func btnCreateLookbook(_ sender: UIButton) {
        viewModel?.setView(type: .createLookbook)
    }
    
    @IBAction func btnDownloadExelFile(_ sender: UIButton) {
        viewModel?.setView(type: .downloadExcelFile)
    }
    
    @IBAction func btnSendEmail(_ sender: UIButton) {
        viewModel?.sendEmail()
    }
    @IBAction func btnHidePrices(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        viewModel?.hidePrice(shouldHide: sender.isSelected)
    }
    
    @IBAction func btnClose(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}

extension DownloadOrderPopup {
    
    func textFieldDelegate() {
        tfEmailAddress.delegate = self
    }
    
    private func setPlaceHolederColor() {
        tfEmailAddress.attributedPlaceholder = NSAttributedString(string: "Enter Email Address", attributes: [NSAttributedString.Key.foregroundColor: UIColor().primaryColor])
    }
    
    private func roundedCorner() {
        btnDownlowadFile.roundedCorner(radius: btnDownlowadFile.frame.height/2)
        uvHidePriceCheckmark.roundedCorner(radius: uvHidePriceCheckmark.frame.height/2)
    }
    
    private func showReplacePopup() {
        let alert = UIAlertController(title: "File Already Exists", message: "File already exist. Do you want to replace?", preferredStyle: .alert)

                alert.addAction(UIAlertAction(title: "Replace", style: .default, handler: { _ in
                    self.viewModel?.replaceFile()
                }))
        
                alert.addAction(UIAlertAction(title: "Open Previous File", style: .default, handler: { _ in
                    self.viewModel?.openSavedFile()
                }))
        
                alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))

                // show the alert
                self.present(alert, animated: true, completion: nil)
    }
    
    private func openFileAlert(url: URL) {
        let alert = UIAlertController(title: "Open File",
                                      message: "Do you want to open this file?",
                                      preferredStyle: .alert)

                alert
                    .addAction(UIAlertAction(title: "Open",
                                             style: .default,
                                             handler: { _ in
                                                UIApplication.shared.open(url)
                                             }))
        
                alert
                    .addAction(UIAlertAction(title: "Cancel",
                                             style: .cancel,
                                             handler: nil))

                // show the alert
                self.present(alert, animated: true, completion: nil)
    }
    
    private func setView(type: OrderSelectionType) {
        ivContenImage.image =  type.contentImage
        
        uvHidePrice.isHidden = type.shouldHidePriceView
        
        lblContentLabel.text =  type.contentTitle
        lblContentDetail.text =  type.contentDetail
        
        btnDownlowadFile.setTitle(type.downloadButtonTitle, for: .normal)
        switch type {
        case .print:
            uvPrintBackground.backgroundColor = UIColor().primaryColor
            uvExcelBackground.backgroundColor = .clear
            uvLookbookBackground.backgroundColor = .clear
            
            lblPrint.textColor = .white
            lblExcelFile.textColor = UIColor().primaryColor
            lblCreateLookbook.textColor = UIColor().primaryColor
            
            ivPrintOrder.image = UIImage(named: "email-order-icon-white")
            ivDownloadExcel.image = UIImage(named: "excel-icon")
            ivCatalogItem.image = UIImage(named: "catalog-icon")
            
        case .createLookbook:
            uvLookbookBackground.backgroundColor = UIColor().primaryColor
            uvExcelBackground.backgroundColor = .clear
            uvPrintBackground.backgroundColor = .clear
            
            lblPrint.textColor = UIColor().primaryColor
            lblExcelFile.textColor = UIColor().primaryColor
            lblCreateLookbook.textColor = .white
            
            ivPrintOrder.image = UIImage(named: "email-order-icon")
            ivCatalogItem.image = UIImage(named: "catalog-icon-white")
            ivDownloadExcel.image = UIImage(named: "excel-icon")
        case .downloadExcelFile:
            uvExcelBackground.backgroundColor = UIColor().primaryColor
            uvPrintBackground.backgroundColor = .clear
            uvLookbookBackground.backgroundColor = .clear
            
            lblPrint.textColor = UIColor().primaryColor
            lblExcelFile.textColor = .white
            lblCreateLookbook.textColor = UIColor().primaryColor
            
            ivPrintOrder.image = UIImage(named: "email-order-icon")
            ivCatalogItem.image = UIImage(named: "catalog-icon")
            ivDownloadExcel.image = UIImage(named: "excel-icon-white")
        }
    }
}

extension DownloadOrderPopup: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel?.sendEmail()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfEmailAddress:
            self.viewModel?.email = textAfterUpdate
        default:
            break
        }
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case tfEmailAddress:
            self.viewModel?.email = ""
        default:
            break
        }
        return true
    }
}
