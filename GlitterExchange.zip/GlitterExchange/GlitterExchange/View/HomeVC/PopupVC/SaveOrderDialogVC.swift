//
//  SaveOrderDialogVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 12/10/2020.
//

import UIKit

final class SaveOrderDialogVC: BaseVC {
    
    // MARK: - Properties
    
    // MARK: - IBOutlet
    @IBOutlet weak var uvButtonView: UIView!
    @IBOutlet weak var btnDismissController: UIButton!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupRoundedCorner()
    }
    
    override func bindView() {
        super.bindView()
    }
    
    // MARK: - IBAction
    @IBAction func btnDismissController(_ sender: UIButton) {
        dismiss(animated: true)
    }

}

extension SaveOrderDialogVC {
    
    // MARK: - Methods
    func setupRoundedCorner() {
        uvButtonView.roundedCorner(radius: 5)
        btnDismissController.roundedCorner(radius: 5)
        uvButtonView.setBorder(with: 1.0, and: UIColor().lighGreyBackground)
    }
}
