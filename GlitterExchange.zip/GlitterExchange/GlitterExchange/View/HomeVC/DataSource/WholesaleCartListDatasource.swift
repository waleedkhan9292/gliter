//
//  WholesaleCartListDatasource.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 16/11/2020.
//

import UIKit

class WholesaleCartListDatasource: GenericDataSource<Item>, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: WholesaleCartDetailCell.identifier(),for: indexPath) as? WholesaleCartDetailCell else {
            return UITableViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
}
