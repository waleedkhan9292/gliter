//
//  CompanyListDatasource.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 15/11/2020.
//

import UIKit

class CompanyListDatasource: GenericDataSource<String>, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CompanyListCell.identifier(), for: indexPath) as? CompanyListCell else {
            return UICollectionViewCell()
        }
        cell.companyName = data.value[indexPath.item]
        return cell
    }

}


