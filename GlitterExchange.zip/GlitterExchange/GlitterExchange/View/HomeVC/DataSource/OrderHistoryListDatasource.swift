//
//  OrderHistoryListDatasource.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 19/11/2020.
//

import UIKit

class OrderHistoryListDatasource: GenericDataSource<ProductHistoryItems>, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: OrderHistoryCell.identifier(),for: indexPath) as? OrderHistoryCell else {
            return UITableViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
}


