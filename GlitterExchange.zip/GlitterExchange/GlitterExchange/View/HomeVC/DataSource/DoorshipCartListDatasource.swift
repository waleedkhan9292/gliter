//
//  DoorshipCartListDatasource.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 15/11/2020.
//

import UIKit

class DoorshipCartListDatasource: GenericDataSource<Item>, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: DoorshipCartDetailCell.identifier(),for: indexPath) as? DoorshipCartDetailCell else {
            return UITableViewCell()
        }
        cell.productItem = data.value[indexPath.row]
        return cell
    }
}
