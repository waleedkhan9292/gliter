//
//  TabVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 04/10/2020.
//

import UIKit

final class TabVC: BaseVC {
    
    //MARK:- Properties
    weak var uiViewContoller: UIViewController?
    weak var viewModel: TabVM?
    var tabDelegate: TabDelegate?
    
    var orderId: Int?
    
    //MARK:- IBOutlet
    @IBOutlet weak var uvContainer: UIView!
    @IBOutlet weak var uvCartItemsCount: UIView!
    
    @IBOutlet weak var lblCartItemCount: UILabel!
    
    // MARK: - Methods
    override func configureView() {
        super.configureView()
        setupRoundedCornerView()
        viewModel?.cartItemCountUpdate()
    }
    
    override func bindView() {
        super.bindView()
        viewModel?.childIdentifier.bind { [ weak self ] in
            guard let self = self,
                  let identifier = $0 else { return }
            self.changeHomeController(identifier: identifier)
        }
        
        viewModel?.orderId.bind { [weak self] in
            guard let self = self,
                  let orderId = $0 else { return }
            
            self.orderId = orderId
        }
        
        viewModel?.productCatalogVM.bind { [weak self ] in
            guard let self = self,
                  let productVM = $0
            else {
                return
            }
    
            self.navigateNextScreen(withIdentifier: .pushPetCatalog, sender: productVM)
        }
        
        viewModel?.productSearchVM.bind { [weak self ] in
            guard let self = self,
                  let productVM = $0
            else {
                return
            }
            self.navigateNextScreen(withIdentifier: .pushSearchProduct, sender: productVM)
        }
        
        viewModel?.cartItemCount.bind { [weak self] in
            guard let self = self else { return }
            self.lblCartItemCount.text = $0
        }
    }
    
    //MARK:- IBAction
    @IBAction func btnHome(_ sender: UIButton) {
        viewModel?.selectTab(.homeChildVC)
    }
    
    @IBAction func btnPet(_ sender: UIButton) {
        viewModel?.setProductContainer(with: .pet)
    }
    
    @IBAction func btnHoliday(_ sender: UIButton) {
        viewModel?.setProductContainer(with: .holiday)
    }
    
    @IBAction func btnCustom(_ sender: UIButton) {
        viewModel?.selectTab(.customChildVC)
    }
    
    @IBAction func btnRetailDisplay(_ sender: UIButton) {
        viewModel?.setProductContainer(with: .retailDisplay)
    }
    
    @IBAction func btnCollegiate(_ sender: UIButton) {
        viewModel?.setProductContainer(with: .collegiate)
    }
    
    @IBAction func btnDigitalMarketing(_ sender: UIButton) {
        viewModel?.setProductContainer(with: .digitalMarketing)
    }
    
    @IBAction func btnOrderHistory(_ sender: UIButton) {
        viewModel?.selectTab(.orderHistoryChildVC)
    }
    @IBAction func btnContactUs(_ sender: UIButton) {
        viewModel?.selectTab(.contactUsChildVC)
    }
    
    @IBAction func btnContactUsTopBar(_ sender: UIButton) {
        viewModel?.selectTab(.contactUsChildVC)
    }
    
    @IBAction func btnShowProfile(_ sender: UIButton) {
        viewModel?.selectTab(.userProfileController)
    }
    
    @IBAction func btnLogout(_ sender: UIButton) {
        viewModel?.clearAllData()
        navigateNextScreen(withIdentifier: .presentModalyLogout, sender: self)
    }
    
    @IBAction func btnSearcProduct(_ sender: UIButton) {
        viewModel?.setSearchProductContainer()
    }
    
    @IBAction func btnShowCartItem(_ sender: UIButton) {
        if let vc: CartSlideVC = instantiate(of: .main, with: .cartSlideVC) {
            vc.delegate = self
            present(vc, animated: true)
        }
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        if uiViewContoller != nil {
            if uiViewContoller!.isKind(of: OrderHistoryDetailVC.self) {
                    viewModel?.selectTab(.orderHistoryChildVC)
                return
            }
        }
        navigationController?.popViewController(animated: true)
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segueIdentifier(for: segue) {
        case .pushPetCatalog:
            if let vc = segue.destination as? PetCatalogVC,
               let vm = sender as? ProductCatalogVM {
                vc.viewModel = vm
                vc.delegate = self
            }
            
        case .pushSearchProduct:
            if let vc = segue.destination as? ProductSearchVC,
               let vm = sender as? ProductSearchVM {
                vc.viewModel = vm
            }
        
        default:
            break
        }
    }
    
}

extension TabVC {
    
    // MARK: - Methods
    func setupRoundedCornerView() {
        uvCartItemsCount.roundedCorner(radius: 25)
        uvCartItemsCount.setBorder(with: 1.0, and: UIColor().titleColor)
    }
    
    func changeHomeController(identifier: ControllerName) {
        
        let viewController = storyboard?.instantiateViewController(withIdentifier: identifier.rawValue)
        
        if uiViewContoller != nil {
            uiViewContoller?.removeChild()
        }
        
        if viewController != nil {
            add(viewController!, to: uvContainer)
            checkController(controller: viewController!)
            uiViewContoller = viewController
            uvContainer.fadeIn()
        }
    }
    
    func checkController(controller: UIViewController) {
        if controller.isKind(of: OrderHistoryVC.self) {
            (controller as! OrderHistoryVC).delegate = self
        }
        else if controller.isKind(of: OrderHistoryDetailVC.self) {
            guard let orderId = self.orderId else { return }
            (controller as! OrderHistoryDetailVC).delegate = self
            tabDelegate = controller as? OrderHistoryDetailVC
            tabDelegate?.setOrderId?(with: orderId)
        }
        else if controller.isKind(of: HomveVC.self) {
            (controller as! HomveVC).delegate = self
        }
        else if controller.isKind(of: UserInformationVC.self) {
//            (controller as! UserInformationVC).viewModel = UserInformationVM(apiClient: ApiClientProtocol)
        }
    }
}

extension TabVC: SegueHandlerType {
    //MARK:- Enum Segue
    enum SegueIdentifier: String {
        case presentModalyLogout = "TabToLoginSegue"
        case pushPetCatalog = "TabToPetCatalogSegue"
        case pushSearchProduct = "TabToSearchProductSegue"
    }
}

extension TabVC: OrderHistoryDelegate {
    func goToDetailScreen(with orderId: Int) {
        viewModel?.setOrderId(orderId)
        DispatchQueue.main.asyncAfter(deadline:.now() + 0.5) {
            self.viewModel?.selectTab(.orderHistoryDetailChildVC)
        }
    }
    
    func gotoOrderHistoryController() {
        goToHistoryScreen()
    }
}

extension TabVC: OrderHistoryDetailDelegate {
    func goToHistoryScreen() {
        self.viewModel?.selectTab(.orderHistoryChildVC)
    }
}

extension TabVC: ProductCatalogProtocol {
    func gotoHisotoryFromProductCatalog() {
        goToHistoryScreen()
    }
    
    func gotoHomeController() {
        viewModel?.selectTab(.homeChildVC)
    }
    
    
    func gotoCustomController() {
        goToCustom()
    }
}

extension TabVC: CartProtocol {
    func gotoCartDetailController() {
        switch CustomerTypeModel.shared.type {
        case .dropShip:
            if let vc: DoorshipCartDetailVC = self.instantiate(of: .main, with: .doorshipCartDetailVC) {
                vc.delegate = self
                self.present(vc, animated: true)
            }
        case .wholeSale:
            if let vc: WholesaleCartDetailVC = self.instantiate(of: .main, with: .wholesaleCartDetailVC) {
                vc.delegate = self
                self.present(vc, animated: true)
            }
        default:
            print("default")
        }
    }
    
    func gotoHomeControllerFromCart() {
        viewModel?.selectTab(.homeChildVC)
    }
}


extension TabVC: CartDetailProtocol {
    func showHistoryController() {
        goToHistoryScreen()
    }
}

extension TabVC: HomeControllerDelegate {
    func goToVideo() {
        viewModel?.selectTab(.marketingChildVC)
    }
    
    func goToPhotograpy() {
        viewModel?.selectTab(.marketingChildVC)
    }
    
    func goToCustom() {
        viewModel?.selectTab(.customChildVC)
    }
    
    func goToWebsiteAssistance() {
        viewModel?.selectTab(.marketingChildVC)
    }
    
    func goToDigitalMarketing() {
        viewModel?.setProductContainer(with: .digitalMarketing)
    }
    
    func goToRetailDisplay() {
        viewModel?.setProductContainer(with: .retailDisplay)
    }
    
    func goToPet() {
        viewModel?.setProductContainer(with: .pet)
    }
    
    func goToHoliday() {
        viewModel?.setProductContainer(with: .holiday)
    }

}


