//
//  ProductSearchVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

final class ProductSearchVC: BaseVC {
    
    //MARK:- IBOutlet Properties
    @IBOutlet weak var tfSearch: UITextField!
    
    @IBOutlet weak var lblPageLabel: UILabel!
    
    @IBOutlet weak var uvContainer: UIView!
    @IBOutlet weak var uvProductTVContainer: UIView!
    @IBOutlet weak var uvProductCVContainer: UIView!
    @IBOutlet weak var uvProductCartContainer: UIView!
    @IBOutlet weak var uvProductSelectionContainer: UIView!
    
    @IBOutlet weak var constraintTrailingSelection: NSLayoutConstraint!
    
    //MARK:- Properties
    var productList: [ProductItem] = []
    var selectedItem: [ProductItem] = []
    
    weak var viewModel: ProductSearchVM?
    weak var productWidgetVCContoller: UIViewController!
    weak var productNameController: UIViewController!
    weak var productImagesController: UIViewController!
    weak var cartTotalCount: UIViewController!
    weak var selectedItemsController: UIViewController!
    
    
    override func configureView() {
        super.configureView()
        setCartItemContainer()
        setupDelegate()
        setPlaceHolederColor()
        hideSelectionContainer()
        showSelectionContainer()
    }
    
    override func bindView() {
        super.bindView()
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.isLoading.bind {
            guard let isLoading = $0 else { return }
            isLoading ? showLoader(): hideLoader()
        }
        
        viewModel?.productList.bind { [weak self] in
            guard let self = self else { return }
            self.productList = $0
            self.setupProductListContainer()
        }
        
        viewModel?.pageLabel.bind { [weak self] in
            guard let self = self else { return }
            self.lblPageLabel.text = $0
        }
//
//        viewModel?.setNumberOfPages.bind { [weak self] in
//            guard let self = self else { return }
//            self.lblNumberOfPages.text = $0
//        }
    }
    
    //MARK:- IBAction
    @IBAction func btnBack(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    @IBAction func btnNext(_ sender: UIButton) {
        viewModel?.nextPage()
    }
    
    @IBAction func btnSearch(_ sender: UIButton) {
        viewModel?.productSearch()
    }
    
    @IBAction func btnPrevious(_ sender: UIButton) {
        viewModel?.previousPage()
    }
}

extension ProductSearchVC {
    
    func setupDelegate() {
        tfSearch.delegate = self
    }
    
    func setPlaceHolederColor() {
        tfSearch.attributedPlaceholder = NSAttributedString(string: "Search Product...", attributes: [NSAttributedString.Key.foregroundColor: UIColor().subTitleColor])
    }
    
    func setupProductListContainer() {
        changeController(identifier: .productsNameChildVC, container: uvProductTVContainer)
        
        changeController(identifier: .productsImageChildVC, container: uvProductCVContainer)
    }
    
    func setCartItemContainer() {
        changeController(identifier: .cartTotalCountChildVC, container: uvProductCartContainer)
    }
    
    func changeSideController(identifier: ControllerName) {
        changeController(identifier: identifier, container: uvContainer)
    }
    
    func showSelectionContainer() {
        changeController(identifier: .selectedItemChildVC, container: uvProductSelectionContainer)
    }
    
    func hideSelectionContainer() {
        uvProductSelectionContainer.isHidden = true
    }
    
    func changeController(identifier: ControllerName, container: UIView) {
        if let viewController = storyboard?.instantiateViewController(withIdentifier: identifier.rawValue) {
            if viewController.isKind(of: CartTotalCountVC.self) {
                if cartTotalCount != nil {
                    cartTotalCount?.removeChild()
                }
                add(viewController, to: container)
                cartTotalCount = viewController
                (viewController as! CartTotalCountVC).delegate = self
            }
            else if viewController.isKind(of: ProductsNameVC.self) {
//                if productNameController != nil {
//                    productNameController?.removeChild()
//                }
//                add(viewController, to: container)
//                let productCatalogDelegate = viewController as? ProductsNameVC
//                productCatalogDelegate?.loadData(productList: productList)
//                productNameController = viewController
                if productNameController != nil {
                    productNameController?.removeChild()
                }
                add(viewController, to: container)
                let productCatalogDelegate: ProductCatalogDelegate = viewController as! ProductCatalogDelegate
                productCatalogDelegate.loadData(productList: productList)
                productCatalogDelegate.updateProductListSelection(items: selectedItem)
                productNameController = viewController
                (viewController as! ProductsNameVC).delegate = self
            }
            else if viewController.isKind(of: ProductsImageVC.self) {
//                if productImagesController != nil {
//                    productImagesController?.removeChild()
//                }
//                add(viewController, to: container)
//                let productCatalogDelegate = viewController as? ProductsImageVC
//                productCatalogDelegate?.loadData(productList: productList)
//                productImagesController = viewController
                if productImagesController != nil {
                    productImagesController?.removeChild()
                }
                add(viewController, to: container)
                let productCatalogDelegate: ProductCatalogDelegate = viewController as! ProductCatalogDelegate
                productCatalogDelegate.loadData(productList: productList)
                productCatalogDelegate.updateProductListSelection(items: selectedItem)
                productImagesController = viewController
                (viewController as! ProductsImageVC).delegate = self
            }
            else if viewController.isKind(of: SelectedItemsVC.self) {
                if selectedItemsController != nil {
                    selectedItemsController.removeChild()
                }
                add(viewController, to: container)
                selectedItemsController = viewController
                (viewController as! SelectedItemsVC).delegate = self
            }
            container.fadeIn()
        }
    }
    
    func swipeRightToLeft(view: UIView) {
        UIView.animate(
            withDuration: 0.5,
            delay: 0.0,
            options: .curveEaseOut,
            animations: {
                self.constraintTrailingSelection.constant = 0
                self.view.layoutIfNeeded()
            })
    }
    
    func swipeLeftToRight(view: UIView) {

        UIView.animate(
            withDuration: 0.5,
            delay: 0.0,
            options: .curveEaseIn,
            animations: {
                self.constraintTrailingSelection.constant = -300
                self.view.layoutIfNeeded()
            }) { finished in
            self.uvProductSelectionContainer.isHidden = true
        }
    }
}

extension ProductSearchVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfSearch:
            self.viewModel?.searchText = textAfterUpdate
        default:
            break
        }
        return true
    }
}

extension ProductSearchVC: UpdateCartItemDelegate {
    func showCartView() {
        if let vc: CartSlideVC = instantiate(of: .main, with: .cartSlideVC) {
            present(vc, animated: true)
        }
    }
    
    func showSelectionView() {
        if uvProductSelectionContainer.isHidden {
            uvProductSelectionContainer.isHidden = false
            swipeRightToLeft(view: uvProductSelectionContainer)
        }
    }
}

extension ProductSearchVC: SelectItemDelegate {
    func updateMultipleSelection(isOn: Bool) {
        let imagesController: ProductCatalogDelegate = productImagesController as! ProductCatalogDelegate
        imagesController.updateImagesMultipleSelection(isOn: isOn)
        
        let nameController: ProductCatalogDelegate = productNameController as! ProductCatalogDelegate
        nameController.updateImagesMultipleSelection(isOn: isOn)
    }
    
    func hideView() {
        self.swipeLeftToRight(view: uvProductSelectionContainer)
    }
    
    func addToCart(item: [ProductItem]) {
        if uvProductSelectionContainer.isHidden {
            self.swipeLeftToRight(view: uvProductSelectionContainer)
        }
        if let vc: CartSlideVC = instantiate(of: .main, with: .cartSlideVC) {
            present(vc, animated: true)
        }
    }
    
    func selectItem(item: ProductItem) {
        let productCatalogDelegate: SelectItemDelegate = selectedItemsController as! SelectItemDelegate
        
        productCatalogDelegate.selectItem(item: item)
        if uvProductSelectionContainer.isHidden {
            uvProductSelectionContainer.isHidden = false
            swipeRightToLeft(view: uvProductSelectionContainer)
        }
    }
    
    func singleSelectItem(item: ProductItem) {
        let productCatalogDelegate: SelectItemDelegate = selectedItemsController as! SelectItemDelegate
        
        productCatalogDelegate.singleSelectItem(item: item)
        if uvProductSelectionContainer.isHidden {
            uvProductSelectionContainer.isHidden = false
            swipeRightToLeft(view: uvProductSelectionContainer)
        }
    }
    
    func updateAllList(item: [ProductItem]) {
        selectedItem = item
        let imagesController:ProductCatalogDelegate = productImagesController as! ProductCatalogDelegate
        imagesController.updateProductListSelection(items: item)
        
        let nameController: ProductCatalogDelegate = productNameController as! ProductCatalogDelegate
        nameController.updateProductListSelection(items: item)
        
        let cartTotalCountController: ProductCatalogDelegate = cartTotalCount as! ProductCatalogDelegate
        cartTotalCountController.updateProductListSelection(items: item)
    }
}
