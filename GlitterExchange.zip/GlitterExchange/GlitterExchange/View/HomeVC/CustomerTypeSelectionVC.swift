//
//  SelectDealerVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 04/10/2020.
//

import UIKit

final class CustomerTypeSelectionVC: BaseVC {
    
    //MARK:- IBOutlet Properties
    @IBOutlet weak var lblUserWelcome: UILabel!
    
    @IBOutlet weak var uvAccount: UIView!
    @IBOutlet weak var uvContact: UIView!
    @IBOutlet weak var uvLogOut: UIView!
    
    @IBOutlet weak var btnHidePrice: UIButton!
    
    //MARK:- Properties
    lazy var viewModel: CustomerTypeSelectionVM? = {
        return CustomerTypeSelectionVM()
    }()
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        updateCheckBox()
        uvAccount.roundedCorner(radius: uvAccount.frame.size.height/2)
        uvContact.roundedCorner(radius: uvContact.frame.size.height/2)
        uvLogOut.roundedCorner(radius: uvLogOut.frame.size.height/2)        
    }
    
    override func bindView() {
        super.bindView()
        
        viewModel?.tabViewModel.bind { [weak self] in
            
            guard let self = self,
                  let controllerName = $0
            else {
                return
            }
            self.navigateNextScreen(withIdentifier: .pushTabBar, sender: controllerName)
        }
        
        viewModel?.markCheckBox.bind { [weak self] in
            guard let self = self,
                  let shouldMarkCheckBox = $0 else {  return  }
            self.btnHidePrice.isSelected = shouldMarkCheckBox
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
    }
    

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segueIdentifier(for: segue) {
        case .pushTabBar:
            if let vc = segue.destination as? TabVC,
               let vm = sender as? TabVM {
                vc.viewModel = vm
            }
        case .pushLogout:
            print("screen")
        }
    }
    
    //MARK:- IBAction Methods
    @IBAction func btnShowProfile(_ sender: UIButton) {
        if CustomerTypeModel.shared.type != nil {
            viewModel?.setTabControllerVM(with: .userProfileController)
        }
    }
    
    @IBAction func btnContactUs(_ sender: UIButton) {
        if CustomerTypeModel.shared.type != nil {
            viewModel?.setTabControllerVM(with: .contactUsChildVC)
        }
    }
    
    @IBAction func btnLogout(_ sender: UIButton) {
        viewModel?.clearAllData() 
        navigateNextScreen(withIdentifier: .pushLogout, sender: self)
    }
    
    @IBAction func btnDropshipOrder(_ sender: UIButton) {
        viewModel?.setCustomer(with: .dropShip)
        viewModel?.setTabControllerVM(with: .homeChildVC)
    }
    
    @IBAction func btnWholesaleOrder(_ sender: UIButton) {
        viewModel?.setCustomer(with: .wholeSale)
        viewModel?.setTabControllerVM(with: .homeChildVC)
    }
    
    @IBAction func btnHidePrices(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        viewModel?.price(shouldHide: sender.isSelected)
    }

}

extension CustomerTypeSelectionVC {
    //MARK:- Methods
    private func updateCheckBox() {
        viewModel?.updateCheckBox()
    }
}

extension CustomerTypeSelectionVC: SegueHandlerType {
    //MARK:- Enum Segue
    enum SegueIdentifier: String {
        case pushTabBar = "CustomerTypeSelectionToTabSegue"
        case pushLogout = "CustomerTypeSelectionToLogoutSegue"
    }
}


