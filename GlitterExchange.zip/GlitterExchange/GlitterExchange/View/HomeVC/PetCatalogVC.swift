//
//  PetCatalogVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit
import MaterialComponents
import BarcodeScanner

final class PetCatalogVC: BaseVC {
    
    //MARK:- Properties
    var delegate: ProductCatalogProtocol?
    weak var viewModel: ProductCatalogVM? 
    weak var productWidgetVCContoller: UIViewController!
    weak var productNameController: UIViewController!
    weak var productImagesController: UIViewController!
    weak var cartTotalCount: UIViewController!
    weak var selectedItemsController: UIViewController!
    
    lazy var productList: [ProductItem] = []
    lazy var pageList: [ProductPage] = []
    var productWidget: Catalog?
    lazy var selectedItem: [ProductItem] = []
    lazy var isMultipleOn = false
    var cartSlideVC: CartSlideVC?
    
    //MARK:- IBOutlet
    @IBOutlet weak var lblPageLabel: UILabel!
    @IBOutlet weak var lblNumberOfPages: UILabel!
    @IBOutlet weak var lblProductTitle: UILabel!
    
    @IBOutlet weak var uvCartItemsContainer: UIView!
    @IBOutlet weak var uvContainer: UIView!
    @IBOutlet weak var uvProductTVContainer: UIView!
    @IBOutlet weak var uvProductCVContainer: UIView!
    @IBOutlet weak var uvProductSelectionContainer: UIView!
    @IBOutlet weak var uvCatalog: MDCCard!
    
    @IBOutlet weak var constraintTrailingSelection: NSLayoutConstraint!
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        setCartItemContainer()
        setCellIdentifier()
        viewModel?.getProductList()
        hideCatalogView()
        hideSelectionContainer()
        showSelectionContainer()
    }
    
    override func bindView() {
        super.bindView()
        viewModel?.success.bind {
            guard let message = $0 else { return }
            showSuccessAlert(message: message)
        }
        
        viewModel?.childIdentifier.bind { [weak self] in
            guard let self = self,
                  let identifier = $0 else { return }
            self.changeSideController(identifier: identifier)
        }
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.newItemFromQR.bind { [weak self] in
            guard let self = self,
                  let item = $0 else { return }
            if self.cartSlideVC?.isControllerDissmissed ?? true {
                self.addToCart(item: [item])
            }
            else {
                self.cartSlideVC?.viewModel?.loadData()
            }
//            if self.isMultipleOn {
//                self.selectItem(item: item)
//            }
//            else {
//                self.singleSelectItem(item: item)
//            }
        }
        
        viewModel?.isLoading.bind {
            guard let isLoading = $0 else { return }
            isLoading ? showLoader(): hideLoader()
        }
        
        viewModel?.productList.bind { [weak self] in
            guard let self = self else { return }
            self.productList = $0
            self.setupProductListContainer()
        }
        
        viewModel?.pageList.bind { [weak self] in
            guard let self = self,
                  let pageList = $0 else { return }
            self.pageList = pageList
            self.viewModel?.changeSideController()
        }
        
        viewModel?.setProductTitle.bind { [weak self] in
            guard let self = self else { return }
            self.lblProductTitle.text = $0
        }
        
        viewModel?.productWidget.bind { [weak self] in
            guard let self = self else { return }
            self.productWidget = $0
        }
        
        viewModel?.pageLabel.bind { [weak self] in
            guard let self = self else { return }
            self.lblPageLabel.text = $0
        }
        
        viewModel?.updatePageLabelInWidget.bind { [weak self] in
            guard let self = self,
                  let text = $0 else { return }
            
            let productCatalogDelegate = self.productWidgetVCContoller as? ProductWidgetVC
            productCatalogDelegate?.setLabel(with: text)
        }
        
        viewModel?.setNumberOfPages.bind { [weak self] in
            guard let self = self else { return }
            self.lblNumberOfPages.text = $0
        }
        
        viewModel?.productSearchVM.bind { [weak self ] in
            guard let self = self,
                  let productVM = $0
            else {
                return
            }
            self.navigateNextScreen(withIdentifier: .pushSearchProduct, sender: productVM)
        }
    }
    
    //MARK:- IBAction
    @IBAction func btnBack(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnShowCatalog(_ sender: UIButton) {
        uvCatalog.isHidden = false
    }
    
    @IBAction func btnHideCatalog(_ sender: UIButton) {
        uvCatalog.isHidden = true
    }
    
    @IBAction func btnGotoPet(_ sender: UIButton) {
        if !uvProductSelectionContainer.isHidden {
            swipeLeftToRight(view: uvProductSelectionContainer)
        }
        uvCatalog.isHidden = true
        viewModel?.setCatalog(with: .pet)
    }
    
    @IBAction func btnGotoHoliday(_ sender: UIButton) {
        if !uvProductSelectionContainer.isHidden {
            swipeLeftToRight(view: uvProductSelectionContainer)
        }
        uvCatalog.isHidden = true
        viewModel?.setCatalog(with: .holiday)
    }
    
    @IBAction func btnGotoCollegiate(_ sender: UIButton) {
        if !uvProductSelectionContainer.isHidden {
            swipeLeftToRight(view: uvProductSelectionContainer)
        }
        uvCatalog.isHidden = true
        viewModel?.setCatalog(with: .collegiate)
    }
    
    @IBAction func btnRetailDisplaly(_ sender: UIButton) {
        
        if !uvProductSelectionContainer.isHidden {
            swipeLeftToRight(view: uvProductSelectionContainer)
        }
        uvCatalog.isHidden = true
        viewModel?.setCatalog(with: .retailDisplay)
    }
    
    @IBAction func btnCustom(_ sender: UIButton) {
        uvCatalog.isHidden = true
        delegate?.gotoCustomController()
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnDigitalMarketing(_ sender: UIButton) {
        
        if !uvProductSelectionContainer.isHidden {
            swipeLeftToRight(view: uvProductSelectionContainer)
        }
        uvCatalog.isHidden = true
        viewModel?.setCatalog(with: .digitalMarketing)
    }
    
    @IBAction func btnNext(_ sender: UIButton) {
        
        if !uvProductSelectionContainer.isHidden {
            swipeLeftToRight(view: uvProductSelectionContainer)
        }
        viewModel?.nextPage() 
    }
    
    
    @IBAction func btnPrevious(_ sender: UIButton) {
        if !uvProductSelectionContainer.isHidden {
            swipeLeftToRight(view: uvProductSelectionContainer)
        }
        viewModel?.previousPage()
    }
    
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segueIdentifier(for: segue) {
        case .pushSearchProduct:
            if let vc = segue.destination as? ProductSearchVC,
               let vm = sender as? ProductSearchVM {
                vc.viewModel = vm
            }
        }
    }
}

extension PetCatalogVC {
    
    //MARK:- Methods
    func setCellIdentifier() {
        //        uitProductsName.register(PetCatalogCell.self, forCellReuseIdentifier: PetCatalogCell.identifier())
        //        uicProductsImage.register(ProductCatalogCVCell.self, forCellWithReuseIdentifier: ProductCatalogCVCell.identifier())
    }
    
    func hideCatalogView() {
        uvCatalog.isHidden = true
    }
    
    func hideProductSelectedContainer() {
        uvProductSelectionContainer.isHidden = true
    }
    
    func setupProductListContainer() {
        changeController(identifier: .productsNameChildVC, container: uvProductTVContainer)
        
        changeController(identifier: .productsImageChildVC, container: uvProductCVContainer)
    }
    
    func setCartItemContainer() {
        changeController(identifier: .cartTotalCountChildVC, container: uvCartItemsContainer)
    }
    
    func changeSideController(identifier: ControllerName) {
        changeController(identifier: identifier, container: uvContainer)
    }
    
    func showSelectionContainer() {
        changeController(identifier: .selectedItemChildVC, container: uvProductSelectionContainer)
    }
    
    func hideSelectionContainer() {
        uvProductSelectionContainer.isHidden = true
    }
    
    func changeController(identifier: ControllerName, container: UIView) {
        if let viewController = storyboard?.instantiateViewController(withIdentifier: identifier.rawValue) {
            if viewController.isKind(of: CartTotalCountVC.self) {
                if cartTotalCount != nil {
                    cartTotalCount?.removeChild()
                }
                add(viewController, to: container)
                cartTotalCount = viewController
                (viewController as! CartTotalCountVC).delegate = self
            }
            else if viewController.isKind(of: ProductsNameVC.self) {
                if productNameController != nil {
                    productNameController?.removeChild()
                }
                add(viewController, to: container)
                let productCatalogDelegate: ProductCatalogDelegate = viewController as! ProductCatalogDelegate
                productCatalogDelegate.loadData(productList: productList)
                productCatalogDelegate.updateProductListSelection(items: selectedItem)
                productNameController = viewController
                (viewController as! ProductsNameVC).delegate = self
            }
            else if viewController.isKind(of: ProductsImageVC.self) {
                if productImagesController != nil {
                    productImagesController?.removeChild()
                }
                add(viewController, to: container)
                let productCatalogDelegate: ProductCatalogDelegate = viewController as! ProductCatalogDelegate
                productCatalogDelegate.loadData(productList: productList)
                productCatalogDelegate.updateProductListSelection(items: selectedItem)
                productImagesController = viewController
                (viewController as! ProductsImageVC).delegate = self
            }
            else if viewController.isKind(of: ProductWidgetVC.self) {
                if productWidgetVCContoller != nil {
                    productWidgetVCContoller.removeChild()
                }
                add(viewController, to: container)
                let productCatalogDelegate = viewController as? ProductWidgetVC
                productCatalogDelegate?.loadData(productList: pageList)
                productCatalogDelegate?.setWidget(with: productWidget)
                productWidgetVCContoller = viewController
                (viewController as! ProductWidgetVC).delegate = self
            }
            else if viewController.isKind(of: SelectedItemsVC.self) {
                if selectedItemsController != nil {
                    selectedItemsController.removeChild()
                }
                add(viewController, to: container)
                selectedItemsController = viewController
                (viewController as! SelectedItemsVC).delegate = self
            }
            container.fadeIn()
        }
    }
    
    
    func swipeRightToLeft(view: UIView) {
        UIView.animate(
            withDuration: 0.5,
            delay: 0.0,
            options: .curveEaseOut,
            animations: {
                self.constraintTrailingSelection.constant = 0
                self.view.layoutIfNeeded()
            })
    }
    
    func swipeLeftToRight(view: UIView) {

        UIView.animate(
            withDuration: 0.5,
            delay: 0.0,
            options: .curveEaseIn,
            animations: {
                self.constraintTrailingSelection.constant = -300
                self.view.layoutIfNeeded()
            }) { finished in
            self.uvProductSelectionContainer.isHidden = true
        }
    }
    
}

extension PetCatalogVC: SegueHandlerType {
    //MARK:- Enum Segue
    enum SegueIdentifier: String {
        case pushSearchProduct = "ProductToSearchProductSegue"
    }
}

extension PetCatalogVC: ProductWidgetDelegate {
    
    func setPageInProductCatalog(with page: ProductPage) {
        viewModel?.selectPage(with: page)
    }
    
    func gotoSearchProductScreen() {
        viewModel?.gotoSearchProduct()
    }
    
    func enableQR() {
        viewModel?.enableQR()
    }
    
    func openBarCodeScaner(delegateTo: ProductWidgetVC) {
        viewModel?.openBarCodeScaner(delegateTo: delegateTo)
    }
    
    func barCodeScanFail(message: String) {
        viewModel?.barCodeScanFail(message: message)
    }
    
    func barCodeScanSuccess(barCode: String) {
        viewModel?.barCodeScanSuccess(barCode: barCode)
    }
}

extension PetCatalogVC: UpdateCartItemDelegate {
    func showCartView() {
        if let vc: CartSlideVC = instantiate(of: .main, with: .cartSlideVC) {
            vc.delegate = self
            present(vc, animated: true)
        }
    }
    
    func showSelectionView() {
        if uvProductSelectionContainer.isHidden {
            uvProductSelectionContainer.isHidden = false
            swipeRightToLeft(view: uvProductSelectionContainer)
        }
    }
}

extension PetCatalogVC: CartDetailProtocol {
    func showHistoryController() {
        delegate?.gotoHisotoryFromProductCatalog()
        navigationController?.popViewController(animated: true)
    }
}
extension PetCatalogVC: CartProtocol {
    func gotoCartDetailController() {
        switch CustomerTypeModel.shared.type {
        case .dropShip:
            if let vc: DoorshipCartDetailVC = self.instantiate(of: .main, with: .doorshipCartDetailVC) {
                vc.delegate = self
                self.present(vc, animated: true)
            }
        case .wholeSale:
            if let vc: WholesaleCartDetailVC = self.instantiate(of: .main, with: .wholesaleCartDetailVC) {
                vc.delegate = self
                self.present(vc, animated: true)
            }
        default:
            print("default")
        }
    }
    
    func gotoHomeControllerFromCart() {
        delegate?.gotoHomeController()
        navigationController?.popViewController(animated: true)
    }
}


extension PetCatalogVC: SelectItemDelegate {
    func updateMultipleSelection(isOn: Bool) {
        isMultipleOn = isOn
        let imagesController: ProductCatalogDelegate = productImagesController as! ProductCatalogDelegate
        imagesController.updateImagesMultipleSelection(isOn: isOn)
        
        let nameController: ProductCatalogDelegate = productNameController as! ProductCatalogDelegate
        nameController.updateImagesMultipleSelection(isOn: isOn)
    }
    
    func hideView() {
        self.swipeLeftToRight(view: uvProductSelectionContainer)
    }
    
    func addToCart(item: [ProductItem]) {
        if uvProductSelectionContainer.isHidden {
            self.swipeLeftToRight(view: uvProductSelectionContainer)
        }
        if let vc: CartSlideVC = instantiate(of: .main, with: .cartSlideVC) {
            cartSlideVC = vc
            vc.delegate = self
            present(vc, animated: true)
        }
    }
    
    func selectItem(item: ProductItem) {
        let productCatalogDelegate: SelectItemDelegate = selectedItemsController as! SelectItemDelegate
        
        productCatalogDelegate.selectItem(item: item)
        if uvProductSelectionContainer.isHidden {
            uvProductSelectionContainer.isHidden = false
            swipeRightToLeft(view: uvProductSelectionContainer)
        }
    }
    
    func singleSelectItem(item: ProductItem) {
        let productCatalogDelegate: SelectItemDelegate = selectedItemsController as! SelectItemDelegate
        
        productCatalogDelegate.singleSelectItem(item: item)
        if uvProductSelectionContainer.isHidden {
            uvProductSelectionContainer.isHidden = false
            swipeRightToLeft(view: uvProductSelectionContainer)
        }
    }
    
    func updateAllList(item: [ProductItem]) {
        selectedItem = item
        let imagesController:ProductCatalogDelegate = productImagesController as! ProductCatalogDelegate
        imagesController.updateProductListSelection(items: item)
        
        let nameController: ProductCatalogDelegate = productNameController as! ProductCatalogDelegate
        nameController.updateProductListSelection(items: item)
        
        let cartTotalCountController: ProductCatalogDelegate = cartTotalCount as! ProductCatalogDelegate
        cartTotalCountController.updateProductListSelection(items: item)
    }
}

