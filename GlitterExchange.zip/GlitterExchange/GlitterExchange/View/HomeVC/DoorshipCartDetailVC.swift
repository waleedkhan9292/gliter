//
//  DoorshipCartDetailVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 04/11/2020.
//

import UIKit
import ActionSheetPicker_3_0

final class DoorshipCartDetailVC: BaseVC {
    
    //MARK:- Properties
    var delegate: CartDetailProtocol?
    
    private var viewModel: DoorshipCartDetailVM?
    private let datasource = DoorshipCartListDatasource()
    private let companyListDataSource = CompanyListDatasource()
    private let textViewPlaceholder = "Write any additional notes here"
    private lazy var lblArray: [UILabel : String] = [:]
    private lazy var tfArray: [UITextField : String] = [:]
    private lazy var productList: [Item] = []
    private lazy var companyList: [String] = []
    
    //MARK:- IBOutlet Properties
    @IBOutlet weak var tfCity: UITextField!
    @IBOutlet weak var tfState: UITextField!
    @IBOutlet weak var tfZipCode: UITextField!
    @IBOutlet weak var tfCountry: UITextField!
    @IBOutlet weak var tfPONumber: UITextField!
    @IBOutlet weak var tfCompanyName: UITextField!
    @IBOutlet weak var tfAddressName1: UITextField!
    @IBOutlet weak var tfAddressName2: UITextField!
    @IBOutlet weak var tfCustomerName: UITextField!
    @IBOutlet weak var tfSearchCompany: UITextField!
    @IBOutlet weak var tfSearchCustomer: UITextField!
    
    @IBOutlet weak var tfDate: UITextField!
    
    @IBOutlet weak var tvNotes: UITextView!
    
    @IBOutlet weak var uvDateView: UIView!
    @IBOutlet weak var uvQuantityView: UIView!
    @IBOutlet weak var uvSearchCompany: UIView!
    @IBOutlet weak var uvSearchCustomer: UIView!
    @IBOutlet weak var uvPrintOrEmailOrder: UIView!
    @IBOutlet weak var uvCustomerSearchInfo: UIView!
    @IBOutlet weak var uvSearchCustomerTextFieldView: UIView!
    @IBOutlet weak var uvCompanyListCollectionView: UIView!
    
    @IBOutlet weak var btnPlaceOrderNow: UIButton!
    @IBOutlet weak var btnSelectCustomer: UIButton!
    
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblNotes: UILabel!
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var lblZipCode: UILabel!
    @IBOutlet weak var lblCountry: UILabel!
    @IBOutlet weak var lblPONumber: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblDoorshipFee: UILabel!
    @IBOutlet weak var lblItemQuantity: UILabel!
    @IBOutlet weak var lblAddressName1: UILabel!
    @IBOutlet weak var lblAddressName2: UILabel!
    @IBOutlet weak var lblCustomerName: UILabel!
    @IBOutlet weak var lblSearchCustomer: UILabel!
    @IBOutlet weak var lblSearchCompany: UILabel!
    @IBOutlet weak var lblCustomerBillingCompany: UILabel!
    
    @IBOutlet weak var uitProductList: UITableView!
    
    @IBOutlet weak var uvcCompanyList: UICollectionView!
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        setLabel()
        hideView()
        setTextView()
        setTextField()
        roundedCorner()
        setViewBorder()
        uvSearchCustomer.setGradientBackground()
        uvcCompanyList.setCollectionViewFlowLayout()
    }
    
    override func bindView() {
        super.bindView()
        setupListener()
        viewModel?.loadData()
    }
    
    //MARK:- IBAction
    @IBAction func btnBack(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func btnClose(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func btnPrintOrEmailOrder(_ sender: UIButton) {
        if let vc: DownloadOrderPopup = self.instantiate(of: .main, with: .downloadOrderDialogVC) {
            vc.viewModel = DownloadOrderPopupVM(productItems: CartItem.shared.cartProduct.value)
            self.present(vc, animated: true)
        }
    }
    
    @IBAction func btnPlaceOrder(_ sender: UIButton) {
        viewModel?.setCartItem(orderStatus: .orderPlaced)
    }
    
    @IBAction func btnCancelOrder(_ sender: UIButton) {
        viewModel?.setCartItem(orderStatus: .cancelled)
    }
    
    @IBAction func btnSaveAndCheckoutLater(_ sender: UIButton) {
        viewModel?.setCartItem(orderStatus: .pending)
    }
    
    @IBAction func btnSelectDate(_ sender: UIButton) {
        datePicker(sender)
    }
    
    @IBAction func btnSelectCustomer(_ sender: UIButton) {
        viewModel?.getCustomerList()
    }
    
    @IBAction func btnAddQuantity(_ sender: UIButton) {
        let point = sender.convert(CGPoint.zero, to: uitProductList)
        
        guard let indexPath = uitProductList.indexPathForRow(at: point)
        else { return }
        viewModel?.updateQuantity(at: indexPath.row, with: 1)
    }
    
    @IBAction func btnSubtractQuantity(_ sender: UIButton) {
        let point = sender.convert(CGPoint.zero, to: uitProductList)
        
        guard let indexPath = uitProductList.indexPathForRow(at: point)
        else { return }
        viewModel?.updateQuantity(at: indexPath.row, with: -1)
    }
    
    @IBAction func btnRemoveProduct(_ sender: UIButton) {
        let point = sender.convert(CGPoint.zero, to: uitProductList)
        
        guard let indexPath = uitProductList.indexPathForRow(at: point)
        else { return }
        viewModel?.remove(at: indexPath.row)
    }
}

extension DoorshipCartDetailVC {
    //MARK:- Methods
    
    private func setupListener() {
        viewModel = DoorshipCartDetailVM(datasource: datasource,
                                         companyListDataSource: companyListDataSource)
        uitProductList.dataSource = datasource
        uvcCompanyList.dataSource = companyListDataSource
        uvcCompanyList.delegate = self
        
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        viewModel?.onSuccess.bind { [weak self] in
            guard let self = self,
                  let message = $0 else { return }
            showSuccessAlert(message: message)
            self.dismiss(animated: true,completion: {
                self.delegate?.showHistoryController()
            })
        }
        
        viewModel?.isAdmin.bind { [weak self] in
            guard let self = self,
                  let isAdmin = $0 else { return }
            if isAdmin {
                self.uvCustomerSearchInfo.isHidden = false
            }
        }
        
        viewModel?.customerList.bind { [weak self] in
            guard let self = self else { return }
            if $0.count == 0 {
                self.uvSearchCustomerTextFieldView.isHidden = true
            }
            else {
                self.uvSearchCustomerTextFieldView.isHidden = false
                self.customerPicker(self.btnSelectCustomer, customer: $0)
            }
        }
        
        viewModel?.companyList.bind { [weak self] in
            guard let self = self else { return }
            if $0.count == 0 {
                self.uvCustomerSearchInfo.isHidden = true
            }
            else {
                self.uvCustomerSearchInfo.isHidden = false
            }
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0
            else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.datasource.data.bind { [weak self] in
            guard let self = self else { return }
            self.productList = $0
            self.uitProductList.reloadData()
        }
        
        viewModel?.companyListDataSource.data.bind { [weak self] in
            guard let self = self else { return }
            self.companyList = $0
            self.uvcCompanyList.reloadData()
            if self.uvCompanyListCollectionView.frame.height > 149 {
                self.uvcCompanyList.isScrollEnabled = true
            }
            else {
                self.uvcCompanyList.isScrollEnabled = true
            }
        }
        
        viewModel?.setTitle.bind { [weak self] in
            guard let self = self else { return }
            self.lblTitle.text =  $0
        }
        
        viewModel?.updateQuantityLabel.bind { [weak self] in
            guard let self = self else { return }
            self.lblItemQuantity.text = $0
        }
        
        viewModel?.doorshipFee.bind { [weak self] in
            guard let self = self else { return }
            self.lblDoorshipFee.text = $0
        }
        
        viewModel?.cartData.bind { [weak self] in
            guard let self = self,
                  let data = $0 else { return }

            self.tfAddressName1.text = data.address
            self.tfCompanyName.text = data.companyName
            self.tfCustomerName.text = data.customerName
            self.tfState.text = data.state
            self.tfCity.text = data.city
            self.tfCountry.text = data.country
            self.tfPONumber.text = data.poNumber
            self.tfZipCode.text = data.zIPCode
            self.tvNotes.text = data.notes
            
        }
    }
    
    private func hideView() {
        uvCompanyListCollectionView.isHidden = true
    }
    
    private func roundedCorner() {
        uvPrintOrEmailOrder.roundedCorner(radius: uvPrintOrEmailOrder.frame.height/2)
        uvQuantityView.roundTopCorner(radius: uvQuantityView.frame.height/2)
        btnPlaceOrderNow.roundedCorner(radius: btnPlaceOrderNow.frame.height/2)
        uvSearchCompany.roundedCorner(radius: 5)
        uvSearchCustomer.roundedCorner(radius: 5)
        uvCompanyListCollectionView.roundedCorner(radius: 5)
    }
    
    private func setViewBorder() {
        uvDateView.setBorder(with: 0.5, and: UIColor().titleColor)
        uvSearchCompany.setBorder(with: 1.0, and: UIColor().titleColor)
        uvSearchCustomer.setBorder(with: 1.0, and: UIColor().titleColor)
        uvPrintOrEmailOrder.setBorder(with: 1.0, and: UIColor().primaryColor)
    }
    
    private func setTextView() {
        tvNotes.delegate = self
        lblNotes.text = " Notes "
        tvNotes.textColor = UIColor().titleColor
        tvNotes.text = textViewPlaceholder
        tvNotes.textContainerInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        tvNotes.setBorder(with: 1.0, and: UIColor().titleColor)
        tvNotes.roundedCorner(radius: 5)
    }
    
    private func setTextField() {
        tfArray = [
            tfCompanyName : "Enter your dropship customer's company name here, if applicable ",
            tfCustomerName : "Enter dropship customer's name here",
            tfAddressName1 : "Enter your dropship customer's address here",
            tfCity : "Enter your dropship customer's city here",
            tfAddressName2 : "Enter your dropship customer's address line 2 here, if applicable",
            tfState : "Enter your dropship customer's state here",
            tfZipCode : "Enter your dropship customer's zip code here",
            tfCountry : "Enter your dropship customer's country here",
            tfPONumber : "Enter your PO Number for this",
            tfDate : "Enter Ship Date",
            tfSearchCompany : "Search Company",
            tfSearchCustomer : ""
        ]
        
        tfArray.forEach { textField in
            if textField.key != tfDate &&
                textField.key != tfSearchCompany &&
                textField.key != tfSearchCustomer {
                textField.key.setBorder(with: 1.0, and: UIColor().titleColor)
            }
            textField.key.attributedPlaceholder = NSAttributedString(string: textField.value, attributes: [NSAttributedString.Key.foregroundColor: UIColor().titleColor])
            textField.key.addPaddingToTextField()
            textField.key.textColor = UIColor().titleDarkGrey
            textField.key.delegate = self
        }
        
    }
    
    private func setLabel() {
        lblArray = [
            lblCompanyName : " Company Name ",
            lblCustomerName : " Customer Name ",
            lblAddressName1 : " Address Line 1 ",
            lblCity : " City ",
            lblAddressName2 : " Address Line 2(optional) ",
            lblState : " State ",
            lblZipCode : " Zip Code ",
            lblCountry : " Country ",
            lblPONumber : " PO Number ",
        ]
        
        lblArray.forEach { label in
            label.key.text = label.value
            label.key.textColor = UIColor().titleColor
        }
        
    }
    
    private func datePicker(_ sender: UIButton) {
        let datePicker = ActionSheetDatePicker(title: "Select Date",
                                               datePickerMode: .date,
                                               selectedDate: Date(),
                                               doneBlock: { picker, date, origin in
                                                let dateNew = date as? NSDate
                                                    self.tfDate.text = "\(dateNew!)"
                                                self.viewModel?.deliveryDate =  dateNew?.convertToString() ?? ""
                                                    return
                                                },
                                               cancel: { picker in
                                                    return
                                               },
                                               origin: sender.superview!.superview)
        let secondsInWeek: TimeInterval = 7 * 24 * 60 * 60; // 2 week min and max
//        datePicker?.minimumDate = Date(timeInterval: -secondsInWeek, since: Date())
//        datePicker?.maximumDate = Date(timeInterval: secondsInWeek, since: Date())
        if #available(iOS 14.0, *) {
            datePicker?.datePickerStyle = .inline
        }

        datePicker?.show()
    }
    
    private func customerPicker(_ sender: UIButton, customer: [String?]) {
        ActionSheetStringPicker.show(withTitle: "Select Customer",
                                     rows: customer,
                                     initialSelection: 0,
                                     doneBlock: { picker, index, value in
                                        print("assddasf")
                                        self.viewModel?.setSelectedCustomer(customerName: value as? String ?? "")
                                        self.tfSearchCustomer.text = value as? String
                                        return
                                     },
                                     cancel: { picker in
                                        return
                                     },
                                     origin: sender)
    }
    
}

extension DoorshipCartDetailVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfCompanyName:
            viewModel?.companyName = textAfterUpdate
        case tfCustomerName:
            viewModel?.customerName = textAfterUpdate
        case tfAddressName1:
            viewModel?.addressName1 = textAfterUpdate
        case tfCity:
            viewModel?.city = textAfterUpdate
        case tfState:
            viewModel?.state = textAfterUpdate
        case tfCountry:
            viewModel?.country = textAfterUpdate
        case tfAddressName2:
            viewModel?.addressName2 = textAfterUpdate
        case tfZipCode:
            viewModel?.zipCode = textAfterUpdate
        case tfSearchCompany:
            viewModel?.searchCompany = textAfterUpdate
        default:
            break
        }
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        switch textField {
        
        case tfCompanyName:
            lblCompanyName.textColor = UIColor().primaryColor
        case tfCustomerName:
            lblCustomerName.textColor = UIColor().primaryColor
        case tfAddressName1:
            lblAddressName1.textColor = UIColor().primaryColor
        case tfCity:
            lblCity.textColor = UIColor().primaryColor
        case tfState:
            lblState.textColor = UIColor().primaryColor
        case tfCountry:
            lblCountry.textColor = UIColor().primaryColor
        case tfAddressName2:
            lblAddressName2.textColor = UIColor().primaryColor
        case tfZipCode:
            lblZipCode.textColor = UIColor().primaryColor
        case tfSearchCompany:
            uvCompanyListCollectionView.isHidden = false
            lblSearchCompany.textColor = UIColor().primaryColor
            viewModel?.searchCompany = tfSearchCompany.text ?? ""
            uvSearchCompany.setBorder(with: 1.0, and: UIColor().primaryColor)
            return
        default:
            print("asdf")
        }
        textField.setBorder(with: 1.0, and: UIColor().primaryColor)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        switch textField {
        
        case tfCompanyName:
            lblCompanyName.textColor = UIColor().titleColor
        case tfCustomerName:
            lblCustomerName.textColor = UIColor().titleColor
        case tfAddressName1:
            lblAddressName1.textColor = UIColor().titleColor
        case tfCity:
            lblCity.textColor = UIColor().titleColor
        case tfState:
            lblState.textColor = UIColor().titleColor
        case tfCountry:
            lblCountry.textColor = UIColor().titleColor
        case tfAddressName2:
            lblAddressName2.textColor = UIColor().titleColor
        case tfZipCode:
            lblZipCode.textColor = UIColor().titleColor
        case tfSearchCompany:
            uvCompanyListCollectionView.isHidden = true
            lblSearchCompany.textColor = UIColor().titleColor
            uvSearchCompany.setBorder(with: 1.0, and: UIColor().titleColor)
            return
        default:
            print("asdf")
        }
        textField.setBorder(with: 1.0, and: UIColor().titleColor)
    }
}

extension DoorshipCartDetailVC: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        viewModel?.notes = textView.text
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if (textView.text == textViewPlaceholder && textView.textColor == UIColor().titleColor) {
            textView.text = ""
            lblNotes.textColor = UIColor().primaryColor
            textView.textColor = UIColor().titleDarkGrey
            textView.setBorder(with: 1.0, and: UIColor().primaryColor)
        }
        textView.becomeFirstResponder()
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if (textView.text == "") {
            textView.text = textViewPlaceholder
            lblNotes.textColor = UIColor().titleColor
            textView.textColor = UIColor().titleColor
            textView.setBorder(with: 1.0, and: UIColor().titleColor)
        }
        
        textView.resignFirstResponder()
    }
}

extension DoorshipCartDetailVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        tfSearchCompany.text = companyList[indexPath.item]
        uvCompanyListCollectionView.isHidden = true
        tfSearchCompany.resignFirstResponder()
        tfSearchCustomer.text = ""
        viewModel?.setSelectedCompany(companyName: companyList[indexPath.item])
    }
}


extension DoorshipCartDetailVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.size.width
        let tempLabel: UILabel = UILabel(frame: CGRect(x: collectionView.bounds.origin.x, y: collectionView.bounds.origin.y, width: width - 10, height: CGFloat.greatestFiniteMagnitude))
        tempLabel.numberOfLines = 0
        tempLabel.text = companyList[indexPath.item].description
        tempLabel.font = RobotoFont.medium.size(12.0)
        tempLabel.sizeToFit()
        let h = tempLabel.frame.height + 10
        return CGSize(width: width, height: h)
    }
}
