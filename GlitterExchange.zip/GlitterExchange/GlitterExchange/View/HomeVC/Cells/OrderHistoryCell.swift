//
//  OrderHistoryCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

final class OrderHistoryCell: UITableViewCell {
    
    @IBOutlet weak var btnMoreOption: UIButton!
    
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblCustomerName: UILabel!
    @IBOutlet weak var lblAmount: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblPONumber: UILabel!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblOrderID: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblStatusUpdateDate: UILabel!
    
    var productItem: ProductHistoryItems! {
        didSet {
            lblOrderID.text = "\(productItem.id ?? 0)"
            lblCompanyName.text = productItem.userCompanyName
            lblCustomerName.text = productItem.customerName
            lblType.text = productItem.type
            lblAmount.text = "$\(productItem.amount ?? 0.0)"
            lblDate.text = productItem.creationTime?.convertDate
            lblStatus.text = ProductStatus.status(productItem.status ?? 0).value
            lblPONumber.text = productItem.poNumber ?? "N/A"
            lblStatusUpdateDate.text = "\(productItem.lastModificationTime?.convertDate ?? productItem.creationTime?.convertDate ?? "")"
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension OrderHistoryCell {
}
