//
//  PetCatalogCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

final class PetCatalogCell: UITableViewCell {
    
    @IBOutlet weak var lblSortLetter: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAmountWithId: UILabel!
    
    @IBOutlet weak var uvContentView: UIView!
    
    
    var productItem: ProductItem! {
        didSet {
            lblName.text = productItem.name
            lblSortLetter.text = productItem.sortLetter
            lblAmountWithId.text = "ID:\(productItem.sku ?? "") - \( setProduct(with: productItem.price))"
            uvContentView.backgroundColor = productItem.isSelected ?
                UIColor().lighGreyBackground : UIColor.white
             
            uvContentView.roundedCorner(radius: 10)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension PetCatalogCell {
    private func setProduct(with price: Double?) -> String {
        guard let price = price else {
            return "Free"
        }
        if price == 0 {
            return "Free"
        }
        return "$\(price)"
    }
}
