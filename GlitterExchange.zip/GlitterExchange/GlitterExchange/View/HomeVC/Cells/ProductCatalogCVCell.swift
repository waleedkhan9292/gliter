//
//  ProductCatalogCVCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 07/10/2020.
//

import UIKit

final class ProductCatalogCVCell: UICollectionViewCell {
    
    @IBOutlet weak var ivProductImage: UIImageView!
    
    @IBOutlet weak var lblNewItem: UILabel!
    @IBOutlet weak var lblSortLetter: UILabel!
    
    @IBOutlet weak var uvNewItem: UIView!
    @IBOutlet weak var uvCheckMark: UIView!
    
    var productItem: ProductItem! {
        didSet {
            uvNewItem.isHidden = true
            uvCheckMark.roundedCorner(radius: uvCheckMark.frame.size.height/2)
            uvCheckMark.isHidden = productItem.isSelected ? false : true
            lblSortLetter.text = productItem.sortLetter
            setImage(with: productItem.sku ?? "", and: productItem.catalogID ?? 1)
            
        }
    }
}


extension ProductCatalogCVCell {
    private func setImage(with sku: String, and catalogId: Int) {
        let urlString = Environment.rootURL + "api/api/File/ProductImage/\(catalogId)/\(sku)"
        loadImage(imageView: ivProductImage, uri: urlString)
    }
}
