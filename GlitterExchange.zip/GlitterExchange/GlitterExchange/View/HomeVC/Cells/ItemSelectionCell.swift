//
//  ItemSelectionCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 26/10/2020.
//

import UIKit

final class ItemSelectionCell: UITableViewCell {
    
    @IBOutlet weak var lblUPC: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblProductId: UILabel!
    
    @IBOutlet weak var ivProductImage: UIImageView!
    
    var productItem: ProductItem! {
        didSet {
            lblName.text = productItem.name
            lblProductId.text = "Product ID: \(productItem.sku ?? "")"
            lblUPC.text = "UPC: \(productItem.upc ?? "")"
            setImage(with: productItem.sku ?? "", and: productItem.catalogID ?? 1)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

extension ItemSelectionCell {
    private func setImage(with sku: String, and catalogId: Int) {
        let urlString = Environment.rootURL + "api/api/File/ProductImage/\(catalogId)/\(sku)"
        loadImage(imageView: ivProductImage, uri: urlString)
    }
    
}
