//
//  CartItemCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 31/10/2020.
//

import UIKit
final class CartItemCell: UITableViewCell {
    
    @IBOutlet weak var ivProduct: UIImageView!
    
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblQuantity: UILabel!
    @IBOutlet weak var lblItemName: UILabel!
    @IBOutlet weak var lblProductSku: UILabel!
    @IBOutlet weak var lblProductSubTotal: UILabel!
    
    
    var productItem: Item! {
        didSet {
            lblItemName.text = productItem.product?.name
            lblProductSku.text = productItem.product?.sku
            lblPrice.text = "Cost: $\(productItem.product?.price ?? 0.0)"
            lblProductSubTotal.text = "Subtotal: \(productItem.itemTotal ?? 0.0)"
            setImage(with: productItem.product?.sku ?? "", and: productItem.product?.catalogID ?? 1)
            lblQuantity.text = "\(productItem.quantity ?? 1)"
            lblQuantity.roundedCorner(radius: lblQuantity.frame.height/2)
            lblQuantity.setBorder(with: 1.0, and: UIColor().primaryColor)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

extension CartItemCell {
    private func setImage(with sku: String, and catalogId: Int) {
        let urlString = Environment.rootURL + "api/api/File/ProductImage/\(catalogId)/\(sku)"
        loadImage(imageView: ivProduct, uri: urlString)
    }
    
}
