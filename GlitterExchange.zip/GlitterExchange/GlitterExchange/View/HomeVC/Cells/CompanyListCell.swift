//
//  CompanyListCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 14/11/2020.
//

import UIKit

class CompanyListCell: UICollectionViewCell {
    
    @IBOutlet weak var lblCompanyName: UILabel!
    
    var companyName: String! {
        didSet {
            lblCompanyName.text = companyName
        }
    }
}
