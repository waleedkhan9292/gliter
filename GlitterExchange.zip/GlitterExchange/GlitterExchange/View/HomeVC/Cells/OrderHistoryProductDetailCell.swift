//
//  OrderHistoryProductDetailCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 19/10/2020.
//

import UIKit

final class OrderHistoryProductDetailCell: UITableViewCell {

    @IBOutlet weak var lblItemName: UILabel!
    @IBOutlet weak var lblProductCode: UILabel!
    @IBOutlet weak var lblProductQuantity: UILabel!
    @IBOutlet weak var lblProductPrice: UILabel!
    
    var productItem: Item! {
        didSet {
            lblItemName.text = productItem.product?.name
            lblProductCode.text = productItem.product?.sku
            lblProductQuantity.text = "\(productItem.itemTotal ?? 0)"
            lblProductPrice.text = "$\(productItem.product?.price ?? 0.0)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
