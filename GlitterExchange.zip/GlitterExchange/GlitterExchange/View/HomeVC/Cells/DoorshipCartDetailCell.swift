//
//  DoorshipCartDetailCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 04/11/2020.
//

import UIKit

final class DoorshipCartDetailCell: UITableViewCell {
    
    @IBOutlet weak var ivProduct: UIImageView!
    
    @IBOutlet weak var lblQuantity: UILabel!
    @IBOutlet weak var lblItemName: UILabel!
    @IBOutlet weak var lblProductSku: UILabel!
    
    var productItem: Item! {
        didSet {
            lblItemName.text = productItem.product?.name
            lblProductSku.text = productItem.product?.sku
            setImage(with: productItem.product?.sku ?? "", and: productItem.product?.catalogID ?? 1)
            lblQuantity.text = "\(productItem.quantity ?? 1)"
            lblQuantity.roundedCorner(radius: lblQuantity.frame.height/2)
            lblQuantity.setBorder(with: 1.0, and: UIColor().primaryColor)
        }
    }
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension DoorshipCartDetailCell {
    private func setImage(with sku: String, and catalogId: Int) {
        let urlString = Environment.rootURL + "api/api/File/ProductImage/\(catalogId)/\(sku)"
        loadImage(imageView: ivProduct, uri: urlString)
    }
    
}
