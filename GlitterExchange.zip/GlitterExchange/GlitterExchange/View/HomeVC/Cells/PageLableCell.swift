//
//  PageLableCell.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 24/10/2020.
//

import UIKit

final class PageLableCell: UITableViewCell {

    @IBOutlet weak var lblPageName: UILabel!
    
    var pageLabel: ProductPage! {
        didSet {
            lblPageName.text = "\(pageLabel.pageNo ?? 0) (\(pageLabel.pageLabel ?? ""))"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
