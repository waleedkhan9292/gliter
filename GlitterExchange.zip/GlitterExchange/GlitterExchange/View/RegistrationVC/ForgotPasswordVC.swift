//
//  ForgotPasswordVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 09/10/2020.
//

import UIKit
import MaterialComponents

final class ForgotPasswordVC: BaseVC {
    
    //MARK:- IBOutlet Properties
    @IBOutlet weak var tfEmail: MDCOutlinedTextField!
    
    @IBOutlet weak var btnResetPassword: UIButton!
    
    //MARK:- Properties
    weak var viewModel: ForgotPasswordVM?
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        setupButton()
        setupTextField()
        setupDelegate()
    }
    
    override func bindView() {
        super.bindView()
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.onSucess.bind { 
            guard let message = $0 else { return }
            showSuccessAlert(message: message)
        }
        
        viewModel?.gotoPreviousScreen.bind { [weak self] in
            guard let self = self,
                  let shouldMoveTo = $0
            else { return }
            if shouldMoveTo {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    //MARK:- IBAction Methods
    @IBAction func btnResetPassword(_ sender: UIButton) {
        viewModel?.resetPassword()
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension ForgotPasswordVC {
    
    //MARK:- Methods
    func setupTextField() {
        tfEmail.label.text = "Email"
        tfEmail.setupTextField()
    }
    
    func setupDelegate() {
        tfEmail.delegate = self
    }
    
    func setupButton() {
        btnResetPassword.roundedCorner(radius: btnResetPassword.frame.size.height/2)
    }
    
}

extension ForgotPasswordVC: UITextFieldDelegate {
    
    //MARK:- Text Field Deleagte
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel?.resetPassword()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        
        case tfEmail:
            self.viewModel?.email = textAfterUpdate
        default:
            break
        }
        
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        
        switch textField {
        
        case tfEmail:
            self.viewModel?.email = ""
        default:
            break
        }
        
        return true
    }
}
