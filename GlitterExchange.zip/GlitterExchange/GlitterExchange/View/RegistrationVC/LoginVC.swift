//
//  LoginVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//

import UIKit
import MaterialComponents

final class LoginVC: BaseVC {
    
    //MARK:- IBOutlet Properties
    @IBOutlet weak var tfEmail: MDCOutlinedTextField!
    @IBOutlet weak var tfPasword: MDCOutlinedTextField!
    
    @IBOutlet weak var btnSignIn: UIButton!
    
    //MARK:- Properties
    private var viewModel: LoginVM? = {
        return LoginVM()
    }()
    
    //MARK:- Methods
    override func configureView() {
        super.configureView()
        setupViewModel()
        setupButton()
        setupTextField()
        setupDelegate()
    }
    
    override func bindView() {
        super.bindView()
        viewModel?.error.bind {
            guard let error = $0 else { return }
            showErrorAlert(message: error)
        }
        
        viewModel?.isLoading.bind {
            guard let isloading = $0 else { return }
            isloading ? showLoader(): hideLoader()
        }
        
        viewModel?.customerTypeVM.bind { [weak self] in
            
            guard let self = self,
                  let customerTypeSelectionVM = $0
            else { return }
            
            self.navigateNextScreen(withIdentifier: .pushDealerSelection, sender: customerTypeSelectionVM)
        }
        
        viewModel?.forgotPasswordVM.bind { [weak self] in
            guard let self = self,
                  let forgotPasswordVM = $0
            else { return }
            self.navigateNextScreen(withIdentifier: .presentModalyForgotPassword, sender: forgotPasswordVM)
            
        }
    }
    
    //MARK:- IBAction Methods
    @IBAction func btnSignIn(_ sender: UIButton) {
        viewModel?.login()
    }
    
    @IBAction func btnRememberMe(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        viewModel?.markRemember(shouldRember: sender.isSelected)
    }
    
    @IBAction func btnForgotPassword(_ sender: UIButton) {
        viewModel?.gotoForgotPasswordScreen()
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segueIdentifier(for: segue) {
        case .pushDealerSelection:
            
            if let destinationVC = segue.destination as? UINavigationController,
               let vc = destinationVC.viewControllers[0] as? CustomerTypeSelectionVC,
               let vm = sender as? CustomerTypeSelectionVM {
                vc.viewModel = vm
            }

        case .presentModalyForgotPassword:
            if let vc = segue.destination as? ForgotPasswordVC,
               let vm = sender as? ForgotPasswordVM {
                    vc.viewModel = vm
                
            }
        }
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        tfEmail.text = "shaheerr@gmail.com"
//        tfPasword.text = "Shaheer"
//        
//   i }
}

extension LoginVC: SegueHandlerType {
    //MARK:- Enum Segue
    enum SegueIdentifier: String {
        case pushDealerSelection = "LoginToDealerSelectionSegue"
        case presentModalyForgotPassword = "LoginToForgotPasswordSegue"
    }
}

extension LoginVC {
    
    //MARK:- Methods
    func setupViewModel() {
//        viewModel = LoginVM()
    }
    
    func setupTextField() {
        tfEmail.label.text = "Email"
        tfPasword.label.text = "Password"
        tfEmail.setupTextField()
        tfPasword.setupTextField()
    }
    
    func setupDelegate() {
        tfEmail.delegate = self
        tfPasword.delegate = self
    }
    
    func setupButton() {
        btnSignIn.roundedCorner(radius: btnSignIn.frame.size.height/2)
    }
    
}

//MARK:- Text Field Delegate
extension LoginVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        viewModel?.login()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let textAfterUpdate = textFieldText.replacingCharacters(in: range, with: string)
        
        switch textField {
        case tfEmail:
            self.viewModel?.email = textAfterUpdate
        case tfPasword:
            self.viewModel?.password = textAfterUpdate
        default:
            break
        }
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        switch textField {
        case tfEmail:
            self.viewModel?.email = ""
        case tfEmail:
            self.viewModel?.password = ""
        default:
            break
        }
        return true
    }
}
