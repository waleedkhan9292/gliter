//
//  BaseVC.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//

import SVProgressHUD

class BaseVC: UIViewController, Configurable {

   override func viewDidLoad() {
        super.viewDidLoad()
        self.configureView()
    }

    func configureView() {
        self.bindView()
    }

    func bindView() {}
}
