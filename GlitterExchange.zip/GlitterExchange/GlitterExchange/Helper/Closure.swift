//
//  Closure.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//

import Foundation

typealias ViewModelValidationClosure = ((_ errorMessage: String?) -> Void)
typealias EmptyClosure = () -> Void
typealias SuccessClosure = () -> Void
typealias ObjectClosure<T> = (_ object: T) -> Void



