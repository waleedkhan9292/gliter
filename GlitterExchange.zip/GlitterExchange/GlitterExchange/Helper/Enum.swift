//
//  Enum.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//

import UIKit

enum ControllerName: String {
    case homeChildVC
    case cartSlideVC
    case customChildVC
    case holidayChildVC
    case petTypeChildVC
    case contactUsChildVC
    case marketingChildVC
    case collegiateChildVC
    case saveOrderDialogVC
    case selectedItemChildVC
    case orderHistoryChildVC
    case productsNameChildVC
    case productsImageChildVC
    case retailDisplayChildVC
    case doorshipCartDetailVC
    case wholesaleCartDetailVC
    case downloadOrderDialogVC
    case cartTotalCountChildVC
    case userProfileController
    case changePasswordDialogVC
    case addOrderToCartDialogVC
    case digitalMarketingChildVC
    case orderHistoryDetailChildVC
    case changeShippingAddressDialogVC
}

enum AppStoryboard: String {
    case main = "Main"
}

enum LocalError: String {
    case emptyTextField = "Please Fill All Fields"
    case invalidPasswordError = "Invalid Password"
    case emptyEmailField = "Please Fill Email Field"
    case invalidEmailError = "Invalid Email Address"
    case objectNotIntialized = "Object not initialized"
    case emptyPasswordField = "Please Fill Password Field"
    case emptyNewPasswordField = "Please Fill New Password Field"
    case currentPasswordMissmatch = "Current password is incorrect"
    case emptyCurrentPasswordField = "Please Fill Current Password Field"
    case emptyConfirmPasswordField = "Please Fill Confirm Password Field"
    case confirmPasswordMissmatch = "Confirm password doesnot match with new password"
}

enum UserTextFieldError: String {
    case emptyCity = "City Cannot Be Empty"
    case emptyState = "State Cannot Be Empty"
    case emptyStreet = "Street Cannot Be Empty"
    case emptyCountry = "Country Cannot Be Empty"
    case emptyZipCode = "Zip Code Cannot Be Empty"
    case emptyFullName = "Full Name Cannot Be Empty"
    case emptyCompanyName = "Company Name Cannot Be Empty"
    case emptyAddressLane = "Address Lane Cannot Be Empty"
}

enum UserDefualtKey: String {
    case myProfile
    case rememberMe
    case loginInput
    case authUserKey
    case customerType
    case myProfileWithRole
}

enum CustomerType: String {
    case dropShip = "dropship"
    case wholeSale = "wholesale"
}

enum ProductCatalog: Int {
    case pet = 1
    case holiday = 2
    case collegiate = 3
    case digitalMarketing = 4
    case retailDisplay = 5
    
    var value: String {
        switch self {
        case .pet:
            return "PET CATALOG"
        case .holiday:
            return "HOLIDAY"
        case .collegiate:
            return "COLLEGIATE"
        case .digitalMarketing:
            return "DIGITAL MARKETING"
        case .retailDisplay:
            return "RETAIL DISPLAY"
        }
    }
}

enum ProductStatus {
    
    case status(Int)
    case orderPlaced
    case pending
    case shipped
    case cancelled
    
    var value: String {
        get {
            switch self {
            case .status(let value):
                return getStatus(value: value)
            default:
                return ""
            }
        }
    }
    
    private func getStatus(value: Int) -> String {
        var status = ""
        switch value {
        case 0:
            status = "Order Placed"
        case 1:
            status = "Pending Checkout"
        case 5:
            status = "Shipped"
        case 3:
            status = "Cancelled"
        default:
            status = ""
        }
        return status
    }
    
    var getStatusInt: Int {
        switch self {
        case .orderPlaced:
            return 0
        case .pending:
            return 1
        case .shipped:
            return 5
        case .cancelled:
            return 3
        default:
            return 1
        }
    }
}

enum OrderType {
    case orderType(String)
    
    var value: String {
        get {
            switch self {
            case .orderType(let value):
                return getType(value: value)
            }
        }
    }
    
    private func getType(value: String) -> String {
        var status = ""
        switch value {
        case "wholesale":
            status = "Wholesale Order"
        case "dropship":
            status = "Dropship Order"
        default:
            status = ""
        }
        return status
    }
}

enum UserRole {
    case role(Int)
    case admin
    case user
    case manager
    
    var userRole: Int {
        switch self {
        case .admin:
            return 0
        case .manager:
            return 4
        case .user:
            return 3
        default:
            return 1
        }
    }
    
    var creatorID: Int {
        switch self {
        case .admin:
            return 0
        case .manager:
            return 0
        case .user:
            return 0
        default:
            return 0
        }
    }
}

extension UserRole: Equatable {
    static func == (lhs: UserRole, rhs: UserRole) -> Bool {
        return lhs.userRole == rhs.userRole
    }
}

enum OrderSelectionType {
    case print
    case createLookbook
    case downloadExcelFile
    
    var shouldHidePriceView: Bool {
        switch self {
        case .print:
            return true
        case .createLookbook:
            return false
        case .downloadExcelFile:
            return true
        }
    }
    
    var contentTitle: String {
        switch self {
        case .print:
            return "Print / Email Order"
        case .createLookbook:
            return "Create Lookbook"
        case .downloadExcelFile:
            return "Download Excel File"
        }
    }
    
    var contentImage: UIImage! {
        switch self {
        case .print:
            return UIImage(named: "email-big")
        case .createLookbook:
            return UIImage(named: "catalog-big")
        case .downloadExcelFile:
            return UIImage(named: "excel-big")
        }
    }
    
    var contentDetail: String {
        switch self {
        case .print:
            return "Download or receive a printable PDF file of your order by email. The details include price and quantities."
        case .createLookbook:
            return "Create a printable PDF file in the form of a lookbook with product images and titles. You can also hide the prices to showcase to your customers."
        case .downloadExcelFile:
            return "Download or receive a CSV/Excel file of your order by email. The details include price and quantities.\n\nThis feature will be added soon."
        }
    }
    
    var downloadButtonTitle: String {
        switch self {
        case .print,
             .createLookbook:
            return "   Download Printable PDF   "
        case .downloadExcelFile:
            return "   Download Excel Sheet   "
        }
    }
    
}

enum RobotoFont: String {
    case black = "Black"
    case blackItalic = "BlackItalic"
    case bold = "Bold"
    case boldItalic = "BoldItalic"
    case italic = "Italic"
    case light = "Light"
    case lightItalic = "LightItalic"
    case medium = "Medium"
    case mediumItalic = "MediumItalic"
    case regular = "Regular"
    case thin = "Thin"
    case thinItalic = "ThinItalic"
    
    private var name: String {
        return "Roboto-\(rawValue)"
    }
    
    func size(_ size: CGFloat) -> UIFont {
        if let font = UIFont(name: name, size: size) {
            return UIFontMetrics.default.scaledFont(for: font)
        }
        
        fatalError("There is no font named: \(name)")
    }
}
