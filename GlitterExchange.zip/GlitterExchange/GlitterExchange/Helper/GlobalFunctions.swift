//
//  GlobalFunctions.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 16/10/2020.
//

import Foundation
import Kingfisher
import SVProgressHUD

func getValueFromUserDefault(with key: UserDefualtKey) -> AnyObject? {
    let defaults = UserDefaults.standard;
    let key = key.rawValue
    if defaults.value(forKey: key) != nil {
        return defaults.value(forKey: key) as AnyObject
    }
    return nil
}

func setValueInUserDefault(with key: UserDefualtKey, and value: String) {
    let defaults = UserDefaults.standard
    let key = key.rawValue
    defaults.setValue(value, forKey: key)
    defaults.synchronize()
}

func removeValueFromUserDefault(key: String) {
    let defaults = UserDefaults.standard;
    defaults.removeObject(forKey: key);
    defaults.synchronize();
}

func resetDefaults() {
    let defaults = UserDefaults.standard
    let dictionary = defaults.dictionaryRepresentation()
    dictionary.keys.forEach { key in
        defaults.removeObject(forKey: key)
    }
}

func showLoader() {
    SVProgressHUD.setDefaultMaskType(.black)
    SVProgressHUD.show(withStatus: "Loading...")
}

func hideLoader() {
    SVProgressHUD.dismiss()
}

func showErrorAlert(message: String) {
    SVProgressHUD.showError(withStatus: message)
}

func showSuccessAlert(message: String) {
    SVProgressHUD.setDefaultMaskType(.black)
    SVProgressHUD.showSuccess(withStatus: message)
}

func getCustomerType() -> CustomerType {
    return CustomerTypeModel.shared.type ?? .wholeSale
}

func loadImage(imageView: UIImageView, uri: String) {
    imageView.kf.indicatorType = .activity
    imageView.kf.setImage(with: URL(string: uri))
}

func getMyProfile() -> Profile? {
    guard let jsonString = getValueFromUserDefault(with: .myProfile),
          let profileResponse: GeneralResponseObj<Profile> = JSONDecoder().decodeObject(jsonString)
    else { return nil}
    return profileResponse.result
}

func getMyProfileWithRole() -> Profile? {
    guard let jsonString = getValueFromUserDefault(with: .myProfileWithRole),
          let profileResponse: GeneralResponseObj<Profile> = JSONDecoder().decodeObject(jsonString)
    else { return nil}
    return profileResponse.result
}
