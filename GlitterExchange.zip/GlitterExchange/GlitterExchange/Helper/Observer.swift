//
//  Observer.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 08/10/2020.
//

import Foundation

class Observer<T> {
    
    typealias ObserverCompletion = (T) -> ()
    
    var observers: ObserverCompletion?
    
    var value: T {
        didSet {
            observers?(value)
        }
    }
    
    init(_ value: T) {
        self.value = value
    }
    
    func bind(observer: ObserverCompletion?) {
        self.observers = observer
        observers?(value)
    }
}
