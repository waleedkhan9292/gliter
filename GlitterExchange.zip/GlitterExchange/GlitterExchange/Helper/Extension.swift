//
//  Extension.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 24/09/2020.
//

import UIKit
import MaterialComponents

extension MDCOutlinedTextField {
    func setupTextField() {
        self.setTextColor(UIColor().titleColor, for: .editing)
        self.setTextColor(UIColor().subTitleColor, for: .normal)
        self.setOutlineColor(UIColor().primaryColor, for: .editing)
        self.setOutlineColor(UIColor().subTitleColor, for: .normal)
        self.setNormalLabelColor(UIColor().subTitleColor, for: .normal)
        self.setFloatingLabelColor(UIColor().primaryColor, for: .editing)
        self.setFloatingLabelColor(UIColor().subTitleColor, for: .normal)
    }
}

extension MDCUnderlinedTextField {
    func setupTextField() {
        self.setTextColor(UIColor().titleDarkGrey, for: .normal)
        self.setTextColor(UIColor().titleDarkGrey, for: .editing)
        self.setUnderlineColor(UIColor().subTitleColor, for: .normal)
        self.setUnderlineColor(UIColor().secondaryColor, for: .editing)
        self.setNormalLabelColor(UIColor().subTitleColor, for: .normal)
        self.setFloatingLabelColor(UIColor().subTitleColor, for: .normal)
        self.setFloatingLabelColor(UIColor().secondaryColor, for: .editing)
    }
}


extension UIColor {
    
    var primaryColor: UIColor {
        return UIColor(named: "PrimaryColor")!
    }
    
    var subTitleColor: UIColor {
        return UIColor(named: "SubTitleColor")!
    }
    
    var titleColor: UIColor {
        return UIColor(named: "TitleColor")!
    }
    
    var secondaryColor: UIColor {
        return UIColor(named: "SecondaryColor")!
    }
    
    var titleDarkGrey: UIColor {
        return UIColor(named: "TitleDarkGrey")!
    }
    
    var lighGreyBackground: UIColor {
        return UIColor(named: "LightGreyBackground")!
    }
}

extension UIView {
    func roundedCorner(radius: CGFloat)  {
        self.layer.cornerRadius = radius
    }
    
    func fadeIn() {
        self.alpha = 0
        
        UIView.animate(withDuration: 0.5, animations: {
            self.alpha = 1
        }, completion: { finished in
        })
    }
    
    func roundTopCorner(radius: CGFloat) {
        self.layer.cornerRadius = radius
        self.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    
    func setBorder(with width: CGFloat, and color: UIColor) {
        self.layer.borderWidth = width
        self.layer.borderColor = color.cgColor
    }
    
    func shadow() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 1
        self.layer.shadowOffset = .zero
        self.layer.shadowRadius = 10
    }
    
    func setGradientBackground() {
        let gradient: CAGradientLayer = CAGradientLayer()

        gradient.colors = [UIColor().lighGreyBackground.withAlphaComponent(0.5).cgColor, UIColor().lighGreyBackground.withAlphaComponent(0.2).cgColor]
        gradient.locations = [0.0 , 1.0]
        gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
        gradient.endPoint = CGPoint(x: 0.0, y: 1.0)
        gradient.frame = CGRect(x: 0.0, y: 0.0, width: self.frame.size.width, height: self.frame.size.height)

        self.layer.insertSublayer(gradient, at: 0)
    }
}

extension UITableViewCell {
    class func identifier() -> String {
        return String(describing: self)
    }
}

extension UICollectionViewCell {
    class func identifier() -> String {
        return String(describing: self)
    }
}

extension UICollectionView {
    func setCollectionViewFlowLayout() {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        self.collectionViewLayout = layout
    }

}

extension UIViewController {
    
    func removeChild() {
        willMove(toParent: nil)
        view.removeFromSuperview()
        removeFromParent()
    }
    
    func add(_ child: UIViewController, to containerView: UIView) {
        
        addChild(child)
        containerView.addSubview(child.view)
        
        child.view.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
                                        child.view.topAnchor.constraint(equalTo: containerView.topAnchor),
                                        child.view.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
                                        child.view.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
                                        child.view.bottomAnchor.constraint(equalTo: containerView.bottomAnchor)])
        
        child.didMove(toParent: self)
    }
    
    func instantiate<T: UIViewController>(
        of storyBoard: AppStoryboard,
        with identifier: ControllerName) -> T? {
        
        let storyboard = UIStoryboard(name: storyBoard.rawValue, bundle: nil)
        let identifier = identifier.rawValue
        return storyboard.instantiateViewController(withIdentifier: identifier) as? T
    }
}

extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return nil }
        do {
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            return nil
        }
    }
    
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
    
    var toUTF8Data: Data? {
        return self.data(using: .utf8)
    }
    
    
    var convertDate: String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSZ"
        dateFormatter.locale = Locale.current
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        guard let dateObj = dateFormatter.date(from: self) else {

            return nil
        }

        dateFormatter.dateFormat = "MM/dd/yyyy"
        return dateFormatter.string(from: dateObj)
    }
    
    func isValidEmailAddress() -> Bool {
        
        let regex = try? NSRegularExpression(
            pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$",
            options: .caseInsensitive)
        
        return regex?.firstMatch(
            in: self,
            options: [],
            range: NSRange(location: 0, length: count)) != nil
        
    }
    
    func isValidPassword() -> Bool {
        
        let regex = try? NSRegularExpression (
            pattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$",//"^(?=\\S*[a-z])(?=\\S*[A-Z])(?=\\S*\\d)(?=\\S*[^\\w\\s])\\S{8,}$",
            options: .caseInsensitive)
        
        return regex?.firstMatch (
            in: self, options: [],
            range: NSRange(location: 0, length: self.count)) != nil
    }
    
}

extension JSONEncoder {
    
    func encodeObject<V: Encodable>(_ object: V) -> String? {
        guard let json = try? encode(object) else {
            fatalError("Object could not be encoded to JSON.")
        }
        
        return json.toUTF8String
    }
}

extension JSONDecoder {
    
    func decodeObject<V: Decodable>(_ object: Any?) -> V {
        
        guard let objectString = object as? String,
              let data = objectString.toUTF8Data,
              let decodedObject = try? decode(V.self, from: data) else {
            fatalError("Could not convert Any object to a String.")
        }
        
        return decodedObject
    }
}

extension Data {
    
    var toUTF8String: String? {
        return String(data: self, encoding: .utf8)
    }
    
}

extension UITextField {
    func addPaddingToTextField() {
        let paddingView: UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: 10, height: 10))
        self.leftView = paddingView;
        self.rightView = paddingView;
        self.leftViewMode = .always;
        self.rightViewMode = .always;
    }
}

extension Date {
    func convertToString() -> String {
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let result = formatter.string(from: self)
        return result
    }
}

extension NSDate {
    func convertToString() -> String {
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let result = formatter.string(from: self as Date)
        return result
    }
    func toDispayString() -> String {
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.dateFormat = "MM/dd/yyyy"
        let result = formatter.string(from: self as Date)
        return result
    }
}
