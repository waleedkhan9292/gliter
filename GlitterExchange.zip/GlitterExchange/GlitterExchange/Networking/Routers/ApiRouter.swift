//
//  ApiRouter.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 13/10/2020.
//

import Alamofire
import Foundation

// APIRouter Enum to create request

enum APIRouter: URLRequestConvertible {
    
    case myProfile
    case catalog(param: Int)
    case getRole(param: Profile)
    case deleteOrder(param: Int)
    case duplicateOrder(param: Int)
    case getOrderDetail(param: Int)
    case pagesForCatalog(param: Int)
    case pdfExport(param: [String: Any])
    case contactUs(param: ContactUsInput)
    case excelExport(param: [String: Any])
    case updateUserProfile(param: Profile)
    case getUsersList(param: GetUserInput)
    case createOrEdit(param: [String: Any])
    case searchProduct(param: SearchProduct)
    case authenticateUser(param: LoginInput)
    case orderHistory(param: OrderHistoryInput)
    case downloadPdfFile(param: DownloadFileInput)
    case productCatalog(param: ProductCatalogInput)
    case forgotPassword(param: ForgotPasswordInput)
    case changePassword(param: ChangePasswordInput)
    case sendEmailLookBook(param: LookBookEmailInput)
    case pdfLookbookExport(param: PdfLookbookExportInput)
    case sendEmailPDF(param: [String: Any], email: String)
    case sendEmailExcel(param: [String: Any], email: String)
    
    // MARK: - APIPath
    private var api: String {
        return "api//api/"
    }
    
    // MARK: - HTTPMethod
    private var method: HTTPMethod {
        switch self {
        case .contactUs,
             .pdfExport,
             .excelExport,
             .sendEmailPDF,
             .createOrEdit,
             .sendEmailExcel,
             .forgotPassword,
             .changePassword,
             .duplicateOrder,
             .authenticateUser,
             .sendEmailLookBook,
             .pdfLookbookExport:
            return .post
            
        case .updateUserProfile:
            return .put
            
        case .deleteOrder:
            return .delete
            
        case .catalog,
             .myProfile,
             .getRole,
             .getUsersList,
             .orderHistory,
             .searchProduct,
             .getOrderDetail,
             .productCatalog,
             .downloadPdfFile,
             .pagesForCatalog:
            return .get
        }
    }
    
    // MARK: - Path
    private var path: String {
        switch self {
        case .authenticateUser:
            return "TokenAuth/Authenticate"
        case .myProfile:
            return "services/app/Account/GetMyprofile"
        case .getRole(let param):
            return "services/app/User/Get?Id=\(param.id ?? 3)"
        case .changePassword:
            return "services/app/Account/ChangePassword"
        case .updateUserProfile:
            return "services/app/Account/UpdateMyProfile"
        case .contactUs:
            return "services/app/Account/ContactUsEmail"
        case .pdfExport:
            return "services/app/OrderAppServices/PdfOrderExport"
        case .deleteOrder(let orderId):
            return
                "services/app/OrderAppServices/DeleteOrder?orderId=\(orderId)"
        case .getOrderDetail(let orderId):
            return "services/app/OrderAppServices/GetOrderDetails?Id=\(orderId)"
        case .duplicateOrder(let orderId):
            return
                "services/app/OrderAppServices/DuplicateOrder?orderId=\(orderId)"
        case .forgotPassword(let param):
            return
                "services/app/Account/ForgetPassword?email=\(param.email!)&newpassword=\(param.newPassword!)"
        case .orderHistory(param: let param):
            return
                "services/app/OrderAppServices/GetOrderhistory?Type=\(param.type!)&SkipCount=\(param.skipCount!)&MaxResultCount=\(param.maxResultCount!)"
        case .excelExport:
            return "services/app/OrderAppServices/ExportOrderFile"
        case .productCatalog(param: let param):
            return
                "services/app/Product/GetPagedCatalogProducts?CategoryId=\(param.categoryId!)&SkipCount=\(param.skipCount!)&MaxResultCount=\(param.maxResultCount!)"
        case .catalog(param: let categoryId):
            return "services/app/Catalog/Get?Id=\(categoryId)"
        case .pagesForCatalog(param: let categoryId):
            return "services/app/Product/GetAllPagesForCatalog?id=\(categoryId)"
        case .searchProduct(param: let param):
            return "services/app/Product/GetAllSerchProducts?searchData=\(param.searchData ?? "")&SkipCount=\(param.skipCount ?? 0)&MaxResultCount=\(param.maxResultCount ?? 0)"
        case .downloadPdfFile(param: let param):
            return "File/DownloadPdfFile?FileName=\(param.fileName ?? "")&FileType=\(param.fileType ?? "")&FileToken=\(param.fileToken ?? "")"
        case .createOrEdit:
            return "services/app/OrderAppServices/CreatOrEdit"
        case .sendEmailPDF(_ , email: let email):
            return "services/app/OrderAppServices/PrintOrderInputEmail?email=\(email)"
        case .sendEmailExcel(_ , email: let email):
            return"services/app/OrderAppServices/PrintOrderExcelInputEmail?email=\(email)"
        case .sendEmailLookBook(param: let param):
            return "services/app/OrderAppServices/PrintOrderLookbookEmail?email=\(param.email ?? "")&HidePrice=\(param.hidePrice ?? false)"
        case .pdfLookbookExport(param: let param):
            return "services/app/OrderAppServices/PdfLookbookExport?HidePrice=\(param.hidePrice ?? false)"
        case .getUsersList(param: let param):
            return "services/app/User/GetUsers?Filter=\(param.filter)&RoleId=\(param.roleId)&CreatorUserId=\(param.creatorUserId)&SkipCount=\(param.skipCount)&MaxResultCount=\(param.maxResultCount)"
        }
    }
    
    // MARK: - Parameters
    private var parameters: Parameters? {
        switch self {
        
        case .pdfExport(let param):
            return param
        case .contactUs(let param):
            return param.representation
        case .createOrEdit(let param):
            return param
        case .sendEmailPDF(let param, _):
            return param
        case .sendEmailExcel(let param, _):
            return param
        case .changePassword(let param):
            return param.representation
        case .authenticateUser(let param):
            return param.representation
        case .excelExport(param: let param):
            return param
        case .updateUserProfile(let param):
            return param.representation
        case .sendEmailLookBook(let param):
            return param.representation
        case .pdfLookbookExport(let param):
            return param.representation
        case .getRole:
            return nil
        case .getUsersList:
            return nil
        case .forgotPassword:
            return nil
        case .catalog:
            return nil
        case .myProfile:
            return nil
        case .deleteOrder:
            return nil
        case .orderHistory:
            return nil
        case .searchProduct:
            return nil
        case .getOrderDetail:
            return nil
        case .duplicateOrder:
            return nil
        case .productCatalog:
            return nil
        case .pagesForCatalog:
            return nil
        case .downloadPdfFile:
            return nil
        }
    }
    
    // MARK: - URLRequestConvertible
    func asURLRequest() throws -> URLRequest {
        
        let url =  Environment.rootURL + api
        
        var urlRequest = URLRequest(url:  URL(string: url.appending(path).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!)
        urlRequest.httpMethod = method.rawValue
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.addValue("Bearer \(getAuthorizationToken())", forHTTPHeaderField: "Authorization")
        
        if let parameters = parameters {
            do {
                urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
            } catch {
                throw AFError.parameterEncodingFailed(reason: .jsonEncodingFailed(error: error))
            }
        }
        
        return urlRequest
    }
    
    private func getAuthorizationToken() -> String {
        guard let jsonString = getValueFromUserDefault(with: .authUserKey),
              let authUser: GeneralResponseObj<AuthUser> = JSONDecoder().decodeObject(jsonString),
              let token = authUser.result?.accessToken else {
            return ""
        }
        print("Token: \(token)")
        return token
    }
}

