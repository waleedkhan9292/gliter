//
//  ResponseSerializer.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 13/10/2020.
//

import Alamofire
import Foundation

extension DataRequest {
    
    @discardableResult func responseObject<T: Decodable> (
        queue: DispatchQueue? = nil,
        _ type: T.Type,
        completionHandler: @escaping (AFDataResponse<T>) -> Void
    ) -> Self {
        let decoder = JSONDecoder()
        return responseDecodable(
            of: T.self,
            queue: queue ?? .main,
            decoder: decoder,
            completionHandler: completionHandler
        )
    }
}

extension DownloadRequest {
    
    @discardableResult func responseObject<T: Decodable> (
        queue: DispatchQueue? = nil,
        _ type: T.Type,
        completionHandler: @escaping (AFDownloadResponse<T>) -> Void
    ) -> Self {
        let decoder = JSONDecoder()
        return responseDecodable(
            of: T.self,
            queue: queue ?? .main,
            decoder: decoder,
            completionHandler: completionHandler
        )
    }
}
