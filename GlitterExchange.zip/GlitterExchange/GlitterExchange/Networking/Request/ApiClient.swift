//
//  ApiClient.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//
import Alamofire
import Foundation

final class ApiClient: ApiClientProtocol {
    
    var sessionManager: Session = {
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = HTTPHeaders.default.dictionary
        configuration.timeoutIntervalForRequest = TimeInterval(60)
        configuration.timeoutIntervalForResource = TimeInterval(60)
        configuration.requestCachePolicy = NSURLRequest.CachePolicy.reloadRevalidatingCacheData
        configuration.httpCookieStorage = nil
        
        var trustedPolicy: ServerTrustManager?
        let sessionManager = Session (
            configuration: configuration,
            serverTrustManager: trustedPolicy)
        
        return sessionManager
    }()
    
    func performRequest<T> (
        route: APIRouter,
        completionHandler: @escaping(AFDataResponse<T>) -> ()) where T : Decodable {
        sessionManager.request(route).responseObject(T.self) { response in
            completionHandler(response)
        }
    }
    
//    func performDownloadRequest<T> (
//        route: APIRouter,
//        completionHandler: @escaping(AFDownloadResponse<T>) -> ()) where T : Decodable {
//        sessionManager.download(route).responseObject(T.self) { response in
//            let fl = response.fileURL?.path
//            completionHandler(response)
//        }
//        sessionManager.download(route).responseData { response in
//            let url = response.fileURL
//            print(url)
//        }
//    }
    
    func performDownloadRequest (
        route: APIRouter,
        completionHandler: @escaping(URL?) -> ()) {
        sessionManager.download(route).responseData { response in
            completionHandler(response.fileURL)
        }
    }
}
