//
//  ApiClientProtocol.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//

import Alamofire
import Foundation


protocol ApiClientProtocol: class {
    
    var sessionManager: Session { get set }
    
    func performRequest<T>(route: APIRouter, completionHandler: @escaping (AFDataResponse<T>) -> ()) where T : Decodable
    
//    func performDownloadRequest<T> (
//        route: APIRouter,
//        completionHandler: @escaping(AFDownloadResponse<T>) -> ()) where T : Decodable
    func performDownloadRequest (
        route: APIRouter,
        completionHandler: @escaping(URL?) -> ()) 
}
