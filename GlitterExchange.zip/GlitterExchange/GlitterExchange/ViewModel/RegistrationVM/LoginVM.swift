//
//  LoginVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//
import Alamofire
import Foundation

final class LoginVM {
    
    //MARK:- Properties
    var email: String = "" {
        didSet { self.validateEmail() }
    }
    
    var password: String = "" {
        didSet { self.validatePassword() }
    }
    
    var rememberClient: Bool?
    
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var customerTypeVM = Observer<CustomerTypeSelectionVM?>(nil)
    var forgotPasswordVM = Observer<ForgotPasswordVM?>(nil)
    
    private var apiClient: ApiClientProtocol?
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
        rememberClient = false
    }
    
}

extension LoginVM {
    
    //MARK:- Public Methods
    func login() {
        if validateAllFields() {
            loginApi()
        }
    }
    
    func markRemember(shouldRember: Bool) {
        rememberClient = shouldRember
    }
    
    func gotoForgotPasswordScreen() {
        forgotPasswordVM.value = ForgotPasswordVM(apiClient: apiClient!)
    }
    
    
    //MARK:- Private Methods
    @discardableResult
    private func validateEmail() -> LocalError? {
//        if email?.isEmpty ?? true {
//            return .emptyEmailField
//        }
//        let isEmailValid = self.email?.isValidEmailAddress() ?? false
//
//        return isEmailValid ? nil:
//            .invalidEmailError
        return email.isEmpty ?
            .invalidEmailError : nil
    }
    
    @discardableResult
    private func validatePassword() -> LocalError? {
//        if password?.isEmpty ?? true {
//            return .emptyPasswordField
//        }
        
//        let isPasswordValid = self.password?.isValidPassword() ?? false
//        return isPasswordValid ? nil:
//            .invalidPasswordError
        return password.isEmpty ?
            .emptyPasswordField : nil
    }
    
    private func validateAllFields() -> Bool {
        
        var error: LocalError?
        
        if let passwordError = validatePassword() {
            error = passwordError
        }
        
        if let emailError = validateEmail() {
            error = emailError
        }
        
        guard let localError = error else { return true }
        self.error.value = localError.rawValue
        return false
    }
    
    private func loginApi() {
        isLoading.value = true
        let input = LoginInput (
            userNameOrEmail: email,
            password: password,
            remeberClient: rememberClient)
        
        let request: APIRouter = .authenticateUser(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<AuthUser>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.saveLoiginInputUserDefault(input)
                    self.saveInUserDefault(response: value, key: .authUserKey)
                    self.saveAndGotoNextScreen()
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func saveInUserDefault<T>(response: GeneralResponseObj<T>, key: UserDefualtKey) {
        guard let jsonString = JSONEncoder().encodeObject(response) else {
            return
        }
        setValueInUserDefault(with: key, and: jsonString)
    }
    
    private func saveLoiginInputUserDefault(_ loginInput: LoginInput) {
        guard let jsonString = JSONEncoder().encodeObject(loginInput) else {
            return
        }
        setValueInUserDefault(with: .loginInput, and: jsonString)
    }
    
    private func saveAndGotoNextScreen() {
        customerTypeVM.value = CustomerTypeSelectionVM(apiClient: apiClient!)
    }
}
