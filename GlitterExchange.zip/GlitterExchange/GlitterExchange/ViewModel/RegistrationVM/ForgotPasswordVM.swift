//
//  ForgotPasswordVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 09/10/2020.
//

import Foundation
import Alamofire

final class ForgotPasswordVM {
    
    //MARK:- Properties
    var email: String? {
        didSet { self.validateEmail() }
    }
    
    var error = Observer<String?>(nil)
    var onSucess = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var gotoPreviousScreen = Observer<Bool?>(nil)
    
    private var apiClient: ApiClientProtocol?
    
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
    }
    
}

extension ForgotPasswordVM {
    
    //MARK:- Public Methods
    func resetPassword() {
        if validateAllFields() {
            resetPasswordApi()
        }
    }
    
    
    //MARK:- Private Methods
    @discardableResult
    private func validateEmail() -> LocalError? {
        if email?.isEmpty ?? true {
            return .emptyEmailField
        }
        let isEmailValid = self.email?.isValidEmailAddress() ?? false
        return isEmailValid ? nil: .invalidEmailError
    }
    
    private func validateAllFields() -> Bool {
        var error: LocalError?
        if let emailError =  validateEmail() {
            error = emailError
        }
        
        guard let localError = error else { return true }
        self.error.value = localError.rawValue
        return false
    }
    
    private func resetPasswordApi() {
        isLoading.value = true
        let input = ForgotPasswordInput (
            email: email,
            newPassword: generateRandomPassword()) //"Shaheer1"
        
        let request: APIRouter = .forgotPassword(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<String>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.gotoLoginScreen()
                }
                else {
                    self.error.value = value.error?.message
                }
                
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func generateRandomPassword() -> String {
        let len = 8,
            pswdChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
            rndPswd = String( (0..<len)
                                .compactMap { _ in pswdChars.randomElement() })
        return rndPswd
    }
    
    private func gotoLoginScreen() {
        onSucess.value = "Successfuly Sent Password."
        self.gotoPreviousScreen.value = true
    }
}
