//
//  CustomerTypeSelectionVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 09/10/2020.
//

import Alamofire
import Foundation

final class CustomerTypeSelectionVM {
    typealias ProfileResponse = GeneralResponseObj<Profile>
    
    //MARK:- Properties
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var tabViewModel = Observer<TabVM?>(nil)
    var markCheckBox = Observer<Bool?>(nil)
    
    private var apiClient: ApiClientProtocol?
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
        self.loginApi() 
    }
    
}

extension CustomerTypeSelectionVM {
    
    //MARK:- Public Methods
    func setTabControllerVM(with identifier: ControllerName) {
        tabViewModel.value = TabVM(with: identifier)
    }
    
    func clearAllData() {
        resetDefaults()
    }
    
    func setCustomer(with type: CustomerType) {
        CustomerTypeModel.shared.type = type
    }
    
    func price(shouldHide: Bool) {
        CustomerTypeModel.shared.hidePrices = shouldHide
    }
    
    func updateCheckBox() {
        CustomerTypeModel.shared.hidePrices ?
            (markCheckBox.value = true) : (markCheckBox.value = false)
    }

    //MARK:- Private Methods
    private func loginApi() {
        isLoading.value = true
        guard let input = getUserLoginInput() else { return }
        
        let request: APIRouter = .authenticateUser(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<AuthUser>>) in
            
            guard let self = self else { return }
            
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.saveInUserDefault(response: value, key: .authUserKey)
                    self.getMyProfileApi()
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func saveInUserDefault<T>(response: GeneralResponseObj<T>, key: UserDefualtKey) {
        guard let jsonString = JSONEncoder().encodeObject(response) else {
            return
        }
        setValueInUserDefault(with: key, and: jsonString)
    }
    
    private func getUserLoginInput() -> LoginInput? {
        guard let jsonString = getValueFromUserDefault(with: .loginInput) as? String,
           let input: LoginInput = JSONDecoder().decodeObject(jsonString) else {
            return nil
        }
        return input
    }
    
    private func getMyProfileApi() {
        isLoading.value = true
        
        let request: APIRouter = .myProfile
        
        guard apiClient != nil else {
            self.isLoading.value = false
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<ProfileResponse>) in
            
            guard let self = self else { return }
            
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.saveMyProfile(profile: value)
                    self.getProfileWithRoleApi(input: value.result)
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func getProfileWithRoleApi(input: Profile?) {
        isLoading.value = true
        
        
        guard apiClient != nil,
              let input = input else {
            self.isLoading.value = false
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        let request: APIRouter = .getRole(param: input)
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<ProfileResponse>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.saveMyProfileWithRole(profile: value)
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func saveMyProfileWithRole(profile: ProfileResponse) {
        guard let jsonString = JSONEncoder().encodeObject(profile) else {
            return
        }
        setValueInUserDefault(with: .myProfileWithRole, and: jsonString)
    }
    
    private func saveMyProfile(profile: ProfileResponse) {
        guard let jsonString = JSONEncoder().encodeObject(profile) else {
            return
        }
        setValueInUserDefault(with: .myProfile, and: jsonString)
    }
}
