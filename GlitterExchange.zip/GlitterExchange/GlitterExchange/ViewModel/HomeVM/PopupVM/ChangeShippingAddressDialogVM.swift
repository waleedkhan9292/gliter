//
//  ChangeShippingAddressDialogVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 17/11/2020.
//

import Foundation

final class ChangeShippingAddressDialogVM {
    
    
    //MARK:- Properties
    
    var tfCity = Observer<String?>("")
    var tfState = Observer<String?>("")
    var tfZipCode = Observer<String?>("")
    var tfCountry = Observer<String?>("")
    var tfCompanyName = Observer<String?>("")
    var tfAddressName1 = Observer<String?>("")
    var tfAddressName2 = Observer<String?>("")
    var tfCustomerName = Observer<String?>("")
    
    lazy var city = ""
    lazy var state = ""
    lazy var zipCode = ""
    lazy var country = ""
    lazy var companyName = ""
    lazy var addressName1 = ""
    lazy var addressName2 = ""
    lazy var customerName = ""
    
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var onSucess = Observer<String?>(nil)
    
    
    //MARK:- Constructor
    init() {
    }
    
}

extension ChangeShippingAddressDialogVM {
    
    //MARK:- Public Methods
    func changeShipingAddress() {
        if validateForm() {
            updateValues()
        }
    }
    
    func loadData() {
        (tfAddressName1.value, addressName1) = (CartItem.shared.cartProduct.value?.address ?? "",
                                                CartItem.shared.cartProduct.value?.address ?? "")
        (tfCompanyName.value, companyName) = (CartItem.shared.cartProduct.value?.companyName ?? "",
                                              CartItem.shared.cartProduct.value?.companyName ?? "")
        (tfCustomerName.value, customerName) = (CartItem.shared.cartProduct.value?.customerName ?? "",
                                                CartItem.shared.cartProduct.value?.customerName ?? "")
        (tfState.value, state) = (CartItem.shared.cartProduct.value?.state ?? "",
                            CartItem.shared.cartProduct.value?.state ?? "")
        (tfCity.value, city) = (CartItem.shared.cartProduct.value?.city ?? "",
                          CartItem.shared.cartProduct.value?.city ?? "")
        (tfCountry.value, country) = (CartItem.shared.cartProduct.value?.country ?? "",
                                CartItem.shared.cartProduct.value?.country ?? "")
        (tfZipCode.value, zipCode) = (CartItem.shared.cartProduct.value?.zIPCode ?? "",
                                CartItem.shared.cartProduct.value?.zIPCode ?? "")
    }
    
    //MARK:- Private Methods
    private func validateForm() -> Bool{
        if customerName.isEmpty {
            error.value = "Please enter customer name."
            return false
        }
        else if addressName1.isEmpty {
            error.value = "Please enter address line."
            return false
        }
        else if city.isEmpty {
            error.value = "Please enter city."
            return false
        }
        else if state.isEmpty {
            error.value = "Please enter state."
            return false
        }
        else if zipCode.isEmpty {
            error.value = "Please enter zip code."
            return false
        }
        else if country.isEmpty {
            error.value = "Please enter country."
            return false
        }
        
        return true
    }
    
    
    
    private func updateValues() {
        CartItem.shared.cartProduct.value?.address = addressName1
        CartItem.shared.cartProduct.value?.companyName = companyName
        CartItem.shared.cartProduct.value?.customerName = customerName
        CartItem.shared.cartProduct.value?.state = state
        CartItem.shared.cartProduct.value?.city = city
        CartItem.shared.cartProduct.value?.country = country
        CartItem.shared.cartProduct.value?.zIPCode = zipCode
        
        onSucess.value = "Address has been updated."
    }
}
