//
//  ChangePasswordDialogVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 15/10/2020.
//

import Alamofire
import Foundation

final class ChangePasswordDialogVM {
    
    //MARK:- Properties
    lazy var currentPassword: String = ""
    
    var newPassword: String = "" {
        didSet { self.validateNewPassword() }
    }
    
    lazy var confirmPassword: String = ""
    
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var onSucess = Observer<String?>(nil)
    
    private var apiClient: ApiClientProtocol?
    private var loginInput: LoginInput?
    
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
        loginInput = getLoginInput()
    }
    
}

extension ChangePasswordDialogVM {
    
    //MARK:- Public Methods
    func changePassword() {
        if validateAllFields() {
            changePasswordApi()
        }
    }
    
    //MARK:- Private Methods
    private func validateCurrentPassword() -> LocalError? {
//        if currentPassword?.isEmpty ?? true {
//            return .emptyCurrentPasswordField
//        }
//        let isValid = currentPasswordValidation() ?? false
//        return isValid ? nil:
//            .currentPasswordMissmatch
        return currentPassword.isEmpty ? .emptyCurrentPasswordField : nil
    }
    
    @discardableResult
    private func validateNewPassword() -> LocalError?  {
        if currentPassword.isEmpty {
            return .emptyCurrentPasswordField
        }
        let isPasswordValid = self.newPassword.isValidPassword()
        
        return isPasswordValid ? nil:
            .invalidPasswordError
    }
    
    private func validatePasswordConfirmation() -> LocalError?  {
        if confirmPassword.isEmpty {
            return .emptyCurrentPasswordField
        }
        
        if confirmPassword == newPassword {
            return nil
        }
        return .confirmPasswordMissmatch
        
    }
    
    private func validateAllFields() -> Bool {
        
        var error: LocalError?
        
        if let currentPasswordErr = validateCurrentPassword() {
            error = currentPasswordErr
        }
        
        if let newPasswordErr = validateNewPassword() {
            error = newPasswordErr
        }
        
        if let confirmPasswordErr = validatePasswordConfirmation() {
            error = confirmPasswordErr
        }
        
        guard let localError = error else { return true }
        self.error.value = localError.rawValue
        return false
    }
    
    private func changePasswordApi() {
        isLoading.value = true
        let input = ChangePasswordInput (
            currentPassword: currentPassword,
            newPassword: newPassword)
        
        let request: APIRouter = .changePassword(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<Bool>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.updatePasswordInUserDefualts()
                    self.onSucess.value = "Password Changed Successfuly."
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func getLoginInput() -> LoginInput? {
        guard let jsonString = getValueFromUserDefault(with: .loginInput) as? String,
              let loginInput: LoginInput = JSONDecoder().decodeObject(jsonString) else {
            return nil
        }
        return loginInput
    }
    
    private func currentPasswordValidation() -> Bool? {
        if currentPassword == loginInput?.password {
            return true
        }
        return false
    }
    
    private func updatePasswordInUserDefualts() {
        guard let jsonString = JSONEncoder().encodeObject(loginInput) else {
            return
        }
        setValueInUserDefault(with: .loginInput, and: jsonString)
    }
}
