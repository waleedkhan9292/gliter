//
//  DownloadOrderPopupVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 28/10/2020.
//

import Alamofire
import Foundation

final class DownloadOrderPopupVM {
    
    //MARK:- Properties
    var isLoading = Observer<Bool?>(nil)
    var error = Observer<String?>(nil)
    var onSuccess = Observer<String?>(nil)
    var setType = Observer<OrderSelectionType>(.print)
    var hidePrice = Observer<Bool>(CustomerTypeModel.shared.hidePrices)
    var openFile = Observer<URL?>(nil)
    var showReplaceOrderPopup = Observer<Bool?>(nil)
    
    var fileURL: URL?
    var fileTempPath: URL?
    
    lazy var email = ""
    
    private var apiClient: ApiClientProtocol?
    private var productItems: ProductHistoryItems?
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient(),
         productItems: ProductHistoryItems?) {
        self.apiClient = apiClient
        self.productItems = productItems
    }
}

extension DownloadOrderPopupVM {
    
    //MARK:- Public Methods
    func setView(type: OrderSelectionType) {
        setType.value = type
    }
    
    func hidePrice(shouldHide: Bool) {
        hidePrice.value = shouldHide
        CustomerTypeModel.shared.hidePrices = shouldHide
    }
    
    func sendEmail() {
        if validateField() {
            switch setType.value {
            case .print:
                sendPDFEmail()
            case .createLookbook:
                sendLookBookEmail()
            case .downloadExcelFile:
                sendExcelEmail()
            }
        }
    }
    
    func downloadFile() {
        switch setType.value {
        case .print:
            exportPDF()
        case .createLookbook:
            exportLookBookPDF()
        case .downloadExcelFile:
            exportExcelFile()
        }
    }
    
    func replaceFile() {
        guard let url = fileURL else { return }
        
        try? FileManager.default.removeItem(at: url)
        saveFile()
    }
    
    func openSavedFile() {
        openFile.value = fileURL
    }
    
    func saveFile() {
        guard let destinationURL = fileURL,
              let tempPathUri = fileTempPath else { return }
        do {
            try FileManager.default.copyItem(at: tempPathUri, to: destinationURL)
            openFile.value = destinationURL
        }
        catch let error {
            self.error.value = error.localizedDescription
        }
    }
    
    //MARK:- Private Methods
    private func validateField() -> Bool {
        if email.isEmpty {
            error.value = "Email Field cannot be empty."
            return false
        }
        return true
    }
    
    private func getProductId() -> [Int]? {
        return productItems?.items!.map { $0.productID! }
    }
    
    private func getProductsList() -> [String: Any]? {
        let json = JSONEncoder().encodeObject(productItems)
        if let data = json?.data(using: .utf8) {
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:AnyObject]
                return json
            } catch let error {
                self.error.value = error.localizedDescription
            }
        }
        return nil
    }
    
    private func exportPDF() {
        
        guard let input = getProductsList() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        let request: APIRouter = .pdfExport(param: input)
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<DownloadFileInput>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.downloadFileApi(input: value.result)
                }
                else {
                    self.isLoading.value = false
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func exportExcelFile() {
        
        guard let input = getProductsList() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        let request: APIRouter = .excelExport(param: input)
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<DownloadFileInput>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.downloadFileApi(input: value.result)
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func exportLookBookPDF() {
        
        guard let products = getProductId() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        let input = PdfLookbookExportInput(productId: products,
                                           hidePrice: hidePrice.value)
        let request: APIRouter = .pdfLookbookExport(param: input)
        
        isLoading.value = true
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<DownloadFileInput>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.downloadFileApi(input: value.result)
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func downloadFileApi(input: DownloadFileInput?) {
        guard let input = input else {
            isLoading.value = false
            return
        }
        isLoading.value = true
        
        let request: APIRouter = .downloadPdfFile(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        var error: String? = nil
        apiClient?.performDownloadRequest(route: request) { [weak self]
            (response: URL?) in
            
            guard let self = self,
                  let path = response else {
                error = "Could not download file."
                return
            }
            defer {
                self.error.value = error
            }
            self.isLoading.value = false
//            self.onSuccess.value = "File downloaded successfuly."
            self.moveFile(at: path, with: input.fileName!)
        }
    }
    
    private func sendPDFEmail() {
        guard let input = getProductsList() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        let request: APIRouter = .sendEmailPDF(param: input, email: email)
        
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<String>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.onSuccess.value = "Email sent successfuly."
                }
                else {
                    self.isLoading.value = false
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func sendExcelEmail() {
        
        guard let input = getProductsList() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        let request: APIRouter = .sendEmailExcel(param: input, email: email)
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<String>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.onSuccess.value = "Email sent successfuly."
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func sendLookBookEmail() {
        guard let products = getProductId() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        let input = LookBookEmailInput(productId: products,
                                       hidePrice: hidePrice.value,
                                       email: email)
        
        let request: APIRouter = .sendEmailLookBook(param: input)
        
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<String>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.onSuccess.value = "Email sent successfuly."
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func moveFile(at tempPathUri: URL, with filename: String) {
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        guard let destinationURL = documentsPath?.appendingPathComponent(filename) else {
            return
        }
        fileTempPath = tempPathUri
        fileURL = destinationURL
        
        // cooment the below when to use open pdf pop up
//        do {
//            try? FileManager.default.removeItem(at: destinationURL)
//            try FileManager.default.copyItem(at: tempPathUri, to: destinationURL)
//        }
//        catch let error {
//            self.error.value = error.localizedDescription
//        }
        
        
        
        if FileManager.default.fileExists(atPath: destinationURL.path) { //uncomment when to show pop up
            showReplaceOrderPopup.value = true
            return
        }
        saveFile()
    }
    
}
