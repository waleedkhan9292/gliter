//
//  CartSlideVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 31/10/2020.
//

import Alamofire
import Foundation

final class CartSlideVM {
    
    //MARK:- Properties
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var shouldProceedNext = Observer<Bool?>(nil)
    var updateQuantityLabel = Observer<String>("")
    var downloadOrderPopupVM = Observer<DownloadOrderPopupVM?>(nil)
    
    private var apiClient: ApiClientProtocol?
    var datasource: GenericDataSource<Item>
    
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient(),
         datasource: GenericDataSource<Item> = CartListDatasource()) {
        self.apiClient = apiClient
        self.datasource = datasource
    }
    
}

extension CartSlideVM {
    
    func loadData() {
        datasource.data.value = CartItem.shared.cartProduct.value?.items ?? []
        calculateQuanityAndPrice()
    }
    
    func createOrder() {
        createOrderApi()
    }
    
    func updateQuantity(of item: Item, with quantity: Int) {
        
        guard let index = CartItem.shared.cartProduct.value?.items?.firstIndex(where: { $0 == item }),
              let cartQuantity = CartItem.shared.cartProduct.value?.items?[index].quantity
        else { return }
        
        let totalQuantity = cartQuantity + quantity
        guard totalQuantity > 0 else { return }
        
        CartItem.shared.cartProduct.value?.items?[index].quantity = totalQuantity
        CartItem.shared.cartProduct.value?.items?[index].itemTotal = {
            return Double(totalQuantity) * CartItem.shared.cartProduct.value!.items![index].unitPrice!
        }()
        loadData()
    }
    
    func gotoDownloadPopup() {
        downloadOrderPopupVM.value = DownloadOrderPopupVM(productItems: CartItem.shared.cartProduct.value)
    }
    
    private func calculateQuanityAndPrice() {
        var totalItems = 0
        var subTotal: Double = 0.0
        CartItem.shared.cartProduct.value?.items?.forEach {
            subTotal = subTotal + $0.itemTotal!
            totalItems = totalItems + $0.quantity!
        }
        updateQuantityLabel.value = "Qty. \(totalItems) Sub Total: $\(subTotal)"
    }
    
    private func createOrderApi() {
        guard let input = getProductsList() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        let request: APIRouter = .createOrEdit(param: input)
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductHistoryItems>>) in
            
            guard let self = self else { return }
            self.isLoading.value = false
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    CartItem.shared.cartProduct.value?.id = value.result?.id
                    self.shouldProceedNext.value = true
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func getProductsList() -> [String: Any]? {
        let json = JSONEncoder().encodeObject(CartItem.shared.cartProduct.value)
        if let data = json?.data(using: .utf8) {
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:AnyObject]
                return json
            } catch let error {
                self.error.value = error.localizedDescription
            }
        }
        return nil
    }
    
}
