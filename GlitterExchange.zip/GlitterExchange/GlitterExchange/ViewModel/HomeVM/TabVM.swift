//
//  TabVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 09/10/2020.
//

import Foundation

final class TabVM {
    //MARK:- Properties
    
    struct ContainerChild {
        let controllerName: ControllerName?
        let controllerVM: Any?
    }
    
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var orderId = Observer<Int?>(nil)
    var cartItemCount = Observer<String>("0")
    var productCatalogVM = Observer<ProductCatalogVM?>(nil)
    var productSearchVM = Observer<ProductSearchVM?>(nil)
    var childIdentifier = Observer<ControllerName?>(nil)
    var containerChild = Observer<ContainerChild?>(nil)
    
    //MARK:- Constructor
    init(with identifier: ControllerName = .homeChildVC) {
        childIdentifier.value = identifier
    }
    
}

extension TabVM {
    
    //MARK:- Public Methods
    func setProductContainer(with identifier: ProductCatalog) {
        productCatalogVM.value = ProductCatalogVM(productCatalogId: identifier)
    }
    
    func setSearchProductContainer() {
        productSearchVM.value = ProductSearchVM()
    }
    
    func selectTab(_ identifier: ControllerName) {
        childIdentifier.value = identifier
    }
    func setOrderId(_ orderId: Int) {
        self.orderId.value = orderId
    }
    
    func clearAllData() {
        resetDefaults()
    }
    
    func cartItemCountUpdate() {
        CartItem.shared.cartProduct.bind { [weak self] in
            guard let self = self else { return }
            self.cartItemCount.value = "\($0?.items?.count ?? 0)"
        }
    }
    //MARK:- Private Methods
    
}
