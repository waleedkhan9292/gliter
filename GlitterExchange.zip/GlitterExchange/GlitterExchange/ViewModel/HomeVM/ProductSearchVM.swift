//
//  ProductSearchVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 25/10/2020.
//

import Alamofire
import Foundation

final class ProductSearchVM {
    
    //MARK:- Properties
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var childIdentifier = Observer<ControllerName?>(nil)
    var pageList = Observer<[ProductPage]?>(nil)
    var productList = Observer<[ProductItem]>([])
    var pageLabel = Observer<String>("")
    var setNumberOfPages = Observer<String>("")
    
    private var apiClient: ApiClientProtocol?
    private lazy var productCount = 999
    private lazy var pageNumber = 0
    
    lazy var searchText = ""
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
    }
    
}

extension ProductSearchVM {
    
    //MARK:- Public Methods
    func nextPage() {
        if productCount > pageNumber {
            pageNumber = pageNumber + 1
            searchProductListApi()
        }
    }
    
    func previousPage() {
        if pageNumber > 0 {
            pageNumber = pageNumber - 1
            searchProductListApi()
        }
    }
    
    func productSearch() {
        searchProductListApi()
    }
    
    //MARK:- Private Methods
    private func searchProductListApi() {
        if searchText.count < 3 {
            resetValues()
            return
        }
        
        isLoading.value = true
        
        let input = SearchProduct(searchData: searchText,
                                        skipCount: pageNumber,
                                        maxResultCount: productCount)
        
        let request: APIRouter = .searchProduct(param: input)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductItemResult>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    if self.searchText.count < 3 {
                        
                        self.resetValues()
                    }
                    else {
                        self.setNumberOfPages.value = "Page \(value.result?.pageNo ?? 1) of \(value.result?.totalPages ?? 0)"
                        self.pageLabel.value = value.result?.pageLabel ?? ""
                        self.productList.value = value.result?.items ?? []
                    }
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func resetValues() {
        setNumberOfPages.value = ""
        pageLabel.value = ""
        productList.value = []
    }
}
