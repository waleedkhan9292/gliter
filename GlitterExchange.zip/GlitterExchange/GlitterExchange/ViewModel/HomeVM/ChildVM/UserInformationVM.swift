//
//  UserInformationVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 15/10/2020.
//

import Alamofire
import Foundation

final class UserInformationVM {
    typealias ProfileResponse = GeneralResponseObj<Profile>
    //MARK:- Properties
    lazy var fullName = ""
    lazy var companyName = ""
    lazy var street = ""
    lazy var city = ""
    lazy var addressLane = ""
    lazy var state = ""
    lazy var zipCode = ""
    lazy var country = ""
    
    var profileInput: Profile?

    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var onSuccess = Observer<String?>(nil)
    var updateProfile = Observer<Profile?>(nil)
    var changePasswordVM = Observer<ChangePasswordDialogVM?>(nil)
    
    private var apiClient: ApiClientProtocol?
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
    }
    
}

extension UserInformationVM {
    
    //MARK:- Public Methods
    func gotoChangePassword() {
        changePasswordVM.value = ChangePasswordDialogVM(apiClient: apiClient!)
    }
    
    func updateUserProfile() {
        if validateAllFields() {
            updateUserProfileApi()
        }
    }
    
    func getMyProfile() {
        getMyProfileSavedData()
    }
    
    private func getMyProfileSavedData() {
        
        defer {
            getMyProfileApi()
        }
        
        guard let jsonString = getValueFromUserDefault(with: .myProfile),
              let profileResponse: ProfileResponse = JSONDecoder().decodeObject(jsonString)
        else { return }
        updateProfileUI(profile: profileResponse.result)
        
    }

    
    //MARK:- Private Methods
    private func validateAllFields() -> Bool {
        
        var textFieldError: UserTextFieldError?
        
        if fullName.isEmpty {
            textFieldError = .emptyFullName
        }
        if companyName.isEmpty {
            textFieldError = .emptyCompanyName
        }
        if street.isEmpty {
            textFieldError = .emptyStreet
        }
        if city.isEmpty {
            textFieldError = .emptyCity
        }
        if country.isEmpty {
            textFieldError = .emptyCountry
        }
//        if addressLane.isEmpty {
//            textFieldError = .emptyAddressLane
//        }
        if state.isEmpty {
            textFieldError = .emptyState
        }
        if zipCode.isEmpty {
            textFieldError = .emptyZipCode
        }
        guard let txtError = textFieldError else { return true }
        
        error.value = txtError.rawValue
        return false
    }
    
    private func updateUserProfileApi() {
        isLoading.value = true
        
        let input = getProfileInput()
        
        let request: APIRouter = .updateUserProfile(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<ProfileResponse>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.saveMyProfile(profile: value)
                    self.onSuccess.value = "Profile Updated Successfuly"
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func getMyProfileApi() {
        isLoading.value = true
        
        let request: APIRouter = .myProfile
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<ProfileResponse>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.saveMyProfile(profile: value)
                    self.updateProfileUI(profile: value.result)
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func saveMyProfile(profile: ProfileResponse) {
        guard let jsonString = JSONEncoder().encodeObject(profile) else {
            return
        }
        setValueInUserDefault(with: .myProfile, and: jsonString)
    }
    
    private func getProfileInput() -> Profile {
        profileInput?.updateName(name: fullName)
        profileInput?.updatestreet(street: street)
        profileInput?.updateaddressLane(addressLane: addressLane)
        profileInput?.updateState(state: state)
        profileInput?.updateCity(city: city)
        profileInput?.updateCountry(country: country)
        profileInput?.updateZipCode(zipCode: zipCode)
        profileInput?.updateCompayName(companyName: companyName)
        return profileInput!
    }
    
    private func updateProfileUI(profile: Profile?) {
        guard let profile = profile else { return }
        
        defer { updateProfile.value = profile }
        
        profileInput = profile
        fullName = profile.name ?? ""
        companyName = profile.companyName ?? ""
        city = profile.city ?? ""
        state = profile.state ?? ""
        street = profile.street ?? ""
        country = profile.country ?? ""
        addressLane = profile.address ?? ""
        zipCode = profile.zIPCode ?? ""
    }
}
