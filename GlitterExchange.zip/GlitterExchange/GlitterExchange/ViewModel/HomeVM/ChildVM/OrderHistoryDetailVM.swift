//
//  OrderHistoryDetailVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 19/10/2020.
//

import Alamofire
import Foundation

final class OrderHistoryDetailVM {
    
    //MARK:- Properties
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var onSuccess = Observer<String?>(nil)
    var setTitle = Observer<String?>(nil)
    var setTotalPrice = Observer<String?>(nil)
    var orderDate = Observer<String?>(nil)
    var poNumber = Observer<String?>(nil)
    var billAddress = Observer<String?>(nil)
    var shipAddress = Observer<String?>(nil)
    var status = Observer<String?>(nil)
    var addorderToCartVM = Observer<Bool?>(nil)
    var dropshipFee = Observer<String?>(nil)
    var shouldGoToBackScreen = Observer<Bool?>(nil)
    var productInfo = Observer<ProductHistoryItems?>(nil)
    
    var datasource: GenericDataSource<Item>
    
    private var apiClient: ApiClientProtocol?
    private var orderId: Int?
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient(),
         datasource: GenericDataSource<Item> = OrderHistoryDetailListDatasource()) {
        
        self.apiClient = apiClient
        self.datasource = datasource
    }
    
}

extension OrderHistoryDetailVM {
    
    //MARK:- Public Methods
    func loadData(orderId: Int?) {
        guard let orderId = orderId else { return }
        self.orderId = orderId
        loadDataApi()
    }
    
    func continueOrder() {
        addorderToCartVM.value = true
    }
    
    func duplicateOrder() {
        guard let orderId = orderId else { return }
        duplicateOrderApi(of: orderId)
    }
    
    func deleteOrder() {
        guard let orderId = orderId else { return }
        deleteOrderApi(of: orderId)
    }
    
    func gotoBackScreen() {
        shouldGoToBackScreen.value = true
    }
    
    //MARK:- Private Methods
    private func loadDataApi() {
        
        guard let orderId = orderId else { return }
        isLoading.value = true
        let request: APIRouter = .getOrderDetail(param: orderId)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductHistoryItems>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.setTitle.value = self.setTitle(with: value.result?.type ?? "",
                                                        and: orderId)
                    self.status.value = self.getOrderStatus(with: value.result?.status ?? 0)
                    self.setTotalPrice.value = "\(value.result?.amount ?? 0.0)"
                    self.orderDate.value = value.result?.date?.convertDate
                    self.poNumber.value = "\(value.result?.poNumber ?? "Not Available")"
                    self.billAddress.value = self.getBillingAddress(of: value)
                    self.shipAddress.value = self.getShippingAddress(of: value)
                    
                    self.dropshipFee.value = self.setDropship(with: value.result?.dropshipFee)
                    self.productInfo.value = value.result
                    self.datasource.data.value = value.result?.items ?? []
                    
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func duplicateOrderApi(of orderId: Int) {
        isLoading.value = true
        
        let request :APIRouter = .duplicateOrder(param: orderId)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<Int>>) in
            
            guard let self = self else { return }
            
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.onSuccess.value = "Duplicate Order Generated Succesfuly."
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func deleteOrderApi(of orderId: Int) {
        isLoading.value = true
        
        let request :APIRouter = .deleteOrder(param: orderId)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<Int>>) in
            
            guard let self = self else { return }
            
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.shouldGoToBackScreen.value = true
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func setDropship(with fee: Double?) -> String? {
        switch getCustomerType() {
        case .dropShip:
            return "$\(fee ?? 0.0)"
        case .wholeSale:
            return nil
        }
    }
    
    private func getBillingAddress(of value: GeneralResponseObj<ProductHistoryItems>) -> String {
        return "\(value.result?.userCompanyName ?? "")\n\(value.result?.username ?? "")\n\(value.result?.userStreet ?? "")\n\(value.result?.userCity ?? "")\n\(value.result?.userState ?? "")\n\(value.result?.userCountry ?? "")\n\(value.result?.userZipCode ?? "")"
    }
    
    private func getShippingAddress(of value: GeneralResponseObj<ProductHistoryItems>) -> String {
        if value.result?.companyName == nil {
            return ""
        }
        return "\(value.result?.companyName ?? "")\n\(value.result?.username ?? "")\n\(value.result?.street ?? "")\n\(value.result?.city ?? "")\n\(value.result?.state ?? "")\n\(value.result?.country ?? "")\n\(value.result?.zIPCode ?? "")"
    }
    
    private func setTitle(with type: String, and orderId: Int) -> String {
        return "\(OrderType.orderType(type).value) #\(orderId)"
    }
    
    private func getOrderStatus(with status: Int) ->String {
        return "Status: \(ProductStatus.status(status).value)"
    }
}
