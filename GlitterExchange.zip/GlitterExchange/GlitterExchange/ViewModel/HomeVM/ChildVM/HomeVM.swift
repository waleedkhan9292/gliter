//
//  HomeVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 12/10/2020.
//

import Foundation

final class HomeVM {
    
    //MARK:- Properties
    private var images: [String]!
    private var timer: Timer!
    private var index: Int!
    
    var image = Observer<String?>(nil)
    
    //MARK:- Constructor
    init(with index: Int = 1) {
        self.index = index
        loadImages()
        startTimer()
    }
    
}

extension HomeVM {
    
    //MARK:- Public Methods
    //MARK:- Private Methods
    func loadImages() {
        images = ["holiday-1","holiday-2","holiday-3","holiday-4","holiday-5","holiday-6","holiday-7","holiday-8","holiday-9","holiday-10"]
    }
    
    func startTimer() {
        timer =  Timer.scheduledTimer(timeInterval: 10.0, target: self, selector:#selector(loadNextAnimationImage), userInfo: nil, repeats: true)
    }
    
    @objc func loadNextAnimationImage() {
        if index >= images.count {
            index = 0
        }
        
        image.value = images[index]
        index += 1
    }
}
