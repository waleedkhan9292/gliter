//
//  ProductWidgetVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 24/10/2020.
//

import Foundation

final class ProductWidgetVM {
    
    //MARK:- Properties
    var productList: [ProductPage] = []
    
    var datasource: GenericDataSource<ProductPage>
    
    var pageTitle = Observer<String>("")
    
    //MARK:- Constructor
    init(datasource: GenericDataSource<ProductPage> = ProductWidgetListDatasource()) {
        self.datasource = datasource
    }
    
}

extension ProductWidgetVM {
    
    //MARK:- Public Methods
    func loadData(productList: [ProductPage]) {
        datasource.data.value = productList
    }
    
    func setPageTitle(with text: String) {
        pageTitle.value = text
    }
    
    //MARK:- Private Methods
    
}
