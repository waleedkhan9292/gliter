//
//  ContactUsVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 14/10/2020.
//

import Alamofire
import Foundation

final class ContactUsVM {
    
    //MARK:- Properties
    lazy var subject = ""
    lazy var message = ""

    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var onSuccess = Observer<String?>(nil)
    
    private var apiClient: ApiClientProtocol?
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
    }
    
}

extension ContactUsVM {
    
    //MARK:- Public Methods
    func contactUs() {
        if validateAllFields() {
            contactUsApi()
        }
    }

    //MARK:- Private Methods
    private func validateAllFields() -> Bool {
        
        var textFieldError: LocalError?
        
        if self.subject.isEmpty {
            textFieldError = .emptyTextField
        }
        if self.message.isEmpty {
            textFieldError = .emptyTextField
        }
        
        guard let txtError = textFieldError else { return true }
        
        error.value = txtError.rawValue
        return false
    }
    
    private func contactUsApi() {
        isLoading.value = true
        let input = ContactUsInput (
            subject: subject,
            message: message)
        
        let request: APIRouter = .contactUs(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<String>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.onSuccess.value = "Message Sent Successfuly."
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                print(error.localizedDescription)
                self.error.value = error.localizedDescription
            }
        }
    }
    
}
