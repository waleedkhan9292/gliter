//
//  SelectedItemsVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 26/10/2020.
//

import Alamofire
import Foundation

final class SelectedItemsVM {
    
    //MARK:- Properties
    var isLoading = Observer<Bool?>(nil)
    var error = Observer<String?>(nil)
    var openFile = Observer<URL?>(nil)
    var showReplaceOrderPopup = Observer<Bool?>(nil)
    
    var datasource: GenericDataSource<ProductItem>
    
    var itemCount = Observer<String>("0")
    
    private var apiClient: ApiClientProtocol?
    
    var fileURL: URL?
    var fileTempPath: URL?
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient(),
         datasource: GenericDataSource<ProductItem> = ProductSelectionListDatasource()) {
        self.datasource = datasource
        self.apiClient = apiClient
    }
    
}

extension SelectedItemsVM {
    
    //MARK:- Public Methods
    func loadData(items: [ProductItem]) {
        datasource.data.value = items
    }
    
    func updateData(item: ProductItem) {
        guard !datasource.data.value.contains(item) else {
            datasource.data.value.removeAll(where: {$0.id == item.id})
          return
        }
        
        datasource.data.value.append(item)
    }
    
    func updateDataForSingleSelection(item: ProductItem) {
        datasource.data.value = [item]
    }
    
    func downloadFile() {
        exportLookBookPDF()
    }
    
    func addProductToCart(productList: [ProductItem]) {
        
        guard let myProfile = getMyProfile() else { return }
        
        let productHistoryItems = ProductHistoryItems()
        var amount: Double = 0.0
        var itemList: [Item] = []
        productList.forEach {
            let json = JSONEncoder().encodeObject($0)
            let item = Item()
            item.quantity = 1
            item.productID = $0.id
            item.unitPrice = $0.price
            item.itemTotal = $0.price
            item.product = JSONDecoder().decodeObject(json)
            amount = amount + ($0.price ?? 0.0)

            if !(CartItem.shared.cartProduct.value?.items?.contains(item) ?? false) {
                itemList.append(item)
            }
        }
        if productHistoryItems.id == nil {
            productHistoryItems.date = Date().convertToString()
            productHistoryItems.creationTime = Date().convertToString()
        }
        
        productHistoryItems.customerName = myProfile.name
        productHistoryItems.amount = amount
        productHistoryItems.type = CustomerTypeModel.shared.type?.rawValue
        productHistoryItems.status = ProductStatus.pending.getStatusInt
        productHistoryItems.username = myProfile.userName
        productHistoryItems.userStreet = myProfile.street
        productHistoryItems.userAddress = myProfile.address
        productHistoryItems.userCity = myProfile.city
        productHistoryItems.userState = myProfile.state
        productHistoryItems.userZipCode = myProfile.zIPCode
        productHistoryItems.userCompanyName = myProfile.companyName
        productHistoryItems.userCountry = myProfile.country
        productHistoryItems.dropshipFee = myProfile.dropshipFee
        productHistoryItems.orderOnBehaf = 0
        productHistoryItems.emalOnSAveAndCheckout = false
        productHistoryItems.isDeleted = false
        productHistoryItems.lastModificationTime = Date().convertToString()
        productHistoryItems.lastModifierUserID = myProfile.id
        productHistoryItems.creatorUserID = myProfile.creatorUserID
        productHistoryItems.items = itemList
        productHistoryItems.items?.append(contentsOf: CartItem.shared.cartProduct.value?.items ?? [])
        switch CustomerTypeModel.shared.type {
        case .dropShip:
            
            productHistoryItems.address = ""//myProfile.address
            productHistoryItems.city = ""//myProfile.city
            productHistoryItems.state = ""//myProfile.state
            productHistoryItems.zIPCode = ""//myProfile.zIPCode
            productHistoryItems.companyName = ""//myProfile.companyName
            productHistoryItems.country = ""//myProfile.country
        case .wholeSale:
            productHistoryItems.address = myProfile.address
            productHistoryItems.city = myProfile.city
            productHistoryItems.state = myProfile.state
            productHistoryItems.zIPCode = myProfile.zIPCode
            productHistoryItems.companyName = myProfile.companyName
            productHistoryItems.country = myProfile.country
        default:
            print("default")
        }
        CartItem.shared.cartProduct.value = productHistoryItems
        
        
        
    }
    
    func replaceFile() {
        guard let url = fileURL else { return }
        
        try? FileManager.default.removeItem(at: url)
        saveFile()
    }
    
    func openSavedFile() {
        openFile.value = fileURL
    }
    
    func saveFile() {
        guard let destinationURL = fileURL,
              let tempPathUri = fileTempPath else { return }
        do {
            try FileManager.default.copyItem(at: tempPathUri, to: destinationURL)
            openFile.value = destinationURL
        }
        catch let error {
            self.error.value = error.localizedDescription
        }
    }
    
    //MARK:- Private Methods
    private func getProductId() -> [Int]? {
        return datasource.data.value.map { $0.id! }
    }
    
    private func exportLookBookPDF() {
        
        guard let products = getProductId() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        let input = PdfLookbookExportInput(productId: products,
                                           hidePrice: CustomerTypeModel.shared.hidePrices)
        let request: APIRouter = .pdfLookbookExport(param: input)
        
        isLoading.value = true
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<DownloadFileInput>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.downloadFileApi(input: value.result)
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func downloadFileApi(input: DownloadFileInput?) {
        guard let input = input else {
            isLoading.value = false
            return
        }
        isLoading.value = true
        
        let request: APIRouter = .downloadPdfFile(param: input)
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        var error: String? = nil
        apiClient?.performDownloadRequest(route: request) { [weak self]
            (response: URL?) in
            
            guard let self = self,
                  let path = response else {
                error = "Could not download file."
                return
            }
            defer {
                self.error.value = error
            }
            self.isLoading.value = false
            self.moveFile(at: path, with: input.fileName!)
        }
    }
    
    private func moveFile(at tempPathUri: URL, with filename: String) {
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        guard let destinationURL = documentsPath?.appendingPathComponent(filename) else {
            return
        }
        fileTempPath = tempPathUri
        fileURL = destinationURL
        
        if FileManager.default.fileExists(atPath: destinationURL.path) {
            showReplaceOrderPopup.value = true
            return
        }
        saveFile()
    }
    
}
