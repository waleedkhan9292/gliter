//
//  ProductImagesVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 24/10/2020.
//

import Foundation

final class ProductImagesVM {
    
    //MARK:- Properties
    var productList: [ProductItem] = []
    
    var datasource: GenericDataSource<ProductItem>
    var multipleSelectionItem = Observer<ProductItem?>(nil)
    var singleSelectionItem = Observer<ProductItem?>(nil)
    
    lazy var isMultipleSelection = false
    
    //MARK:- Constructor
    init(datasource: GenericDataSource<ProductItem> = ProductOrderListDatasource()) {
        self.datasource = datasource
    }
    
}

extension ProductImagesVM {
    
    //MARK:- Public Methods
    func loadData(productList: [ProductItem]) {
        datasource.data.value = productList
    }
    
    func setMultipleSelection(isOn: Bool) {
        isMultipleSelection = isOn
    }
    
    func selectItem(item: ProductItem) {
        if isMultipleSelection {
            multipleSelection(item: item)
        }
        else {
            singleSelection(item: item)
        }
    }
    
    func updateView(items: [ProductItem]) {
        if items.count < 1 {
            for i in 0..<datasource.data.value.count {
                datasource.data.value[i].updateSelectedState(state: false)
            }
        }
        else {
            for i in 0..<datasource.data.value.count {
                for j in 0..<items.count {
                    if datasource.data.value[i].id == items[j].id {
                        datasource.data.value[i].updateSelectedState(state: true)
                        break
                    }
                    else {
                        datasource.data.value[i].updateSelectedState(state: false)
                    }
                }
            }
        }
    }
    
    //MARK:- Private Methods
    
    private func singleSelection(item: ProductItem) {
        singleSelectionItem.value = item
    }
    
    private func multipleSelection(item: ProductItem) {
        multipleSelectionItem.value = item
        
    }
}
