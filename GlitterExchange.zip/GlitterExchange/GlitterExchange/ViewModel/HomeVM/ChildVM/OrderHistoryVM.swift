//
//  OrderHistoryVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 17/10/2020.
//

import Foundation
import Alamofire

final class OrderHistoryVM {
    
    //MARK:- Properties
    var error = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var onSuccess = Observer<String?>(nil)
    var addorderToCartVM = Observer<Bool?>(nil)
    var productDetail = Observer<ProductHistoryItems?>(nil)
    var orderDetailForCart = Observer<ProductHistoryItems?>(nil)
    
    var datasource: GenericDataSource<ProductHistoryItems>
    
    private var apiClient: ApiClientProtocol?
    
    private let maxCount = 10
    private lazy var skipCount = 0
    private lazy var shouldLoadData = true
    private lazy var shouldLoadNext = true
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient(),
         datasource: GenericDataSource<ProductHistoryItems> = OrderHistoryListDatasource()) {
        
        self.apiClient = apiClient
        self.datasource = datasource
    }
    
}

extension OrderHistoryVM {
    
    //MARK:- Public Methods
    func loadData() {
        if shouldLoadData && shouldLoadNext {
            shouldLoadData = false
            loadDataApi()
        }
    }
    
    func duplicateOrder(index: Int) {
        guard let orderId = datasource.data.value[index].id
        else { return }
        
        shouldLoadData = false
        duplicateOrderApi(of: orderId, with: datasource.data.value[index])
    }
    
    func continueOrder() {
        addorderToCartVM.value = true
    }
    
    func deleteOrder(index: Int) {
        guard let orderId = datasource.data.value[index].id
        else { return }
        shouldLoadData = false
        deleteOrderApi(of: orderId,at: index)
    }
    
    func loadOrderDetail(orderId: Int) {
        loadHistoryDetailApi(orderId: orderId)
    }
    
    func loadOrderDetailForCart(orderId: Int) {
        let request :APIRouter = .getOrderDetail(param: orderId)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductHistoryItems>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.orderDetailForCart.value = value.result
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    
    //MARK:- Private Methods
    
    
    private func loadDataApi() {
        isLoading.value = true
        let input = OrderHistoryInput(type: getType(),
                                      skipCount: skipCount,
                                      maxResultCount: maxCount)
        
        let request :APIRouter = .orderHistory(param: input)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductHistoryItemResult>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            self.shouldLoadData = true
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.skipCount = self.skipCount + self.maxCount
                    self.datasource.data.value.append(contentsOf: value.result?.Products ?? [])
                    if self.datasource.data.value.count >= value.result?.totalCount ?? 0 {
                        self.shouldLoadNext = false
                    }
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func duplicateOrderApi(of orderId: Int, with order: ProductHistoryItems) {
        isLoading.value = true
        
        let request :APIRouter = .duplicateOrder(param: orderId)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<Int>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    guard let id = value.result else {
                        return
                    }
                    let newElement = self.newElement(with: id,
                                                     and: order)
                    
                    self.datasource.data.value.insert(newElement,
                                                      at: 0)
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func deleteOrderApi(of orderId: Int, at index: Int) {
        isLoading.value = true
        
        let request :APIRouter = .deleteOrder(param: orderId)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<Int>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.datasource.data.value.remove(at: index)
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func newElement(with id: Int, and order: ProductHistoryItems) -> ProductHistoryItems {
        let newElement = order
        newElement.id = id
//        newElement.updateId(id: id)
        return newElement
    }
    
    private func loadHistoryDetailApi(orderId: Int ) {
        
        let request :APIRouter = .getOrderDetail(param: orderId)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductHistoryItems>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.productDetail.value = value.result   
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func getType() -> String {
        return getCustomerType().rawValue
    }
}
