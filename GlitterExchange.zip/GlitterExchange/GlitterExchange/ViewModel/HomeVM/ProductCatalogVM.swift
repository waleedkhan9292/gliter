//
//  ProductCatalogVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 10/10/2020.
//
import Alamofire
import Foundation
import BarcodeScanner

final class ProductCatalogVM {
    
    //MARK:- Properties
    var error = Observer<String?>(nil)
    var success = Observer<String?>(nil)
    var isLoading = Observer<Bool?>(nil)
    var childIdentifier = Observer<ControllerName?>(nil)
    var productSearchVM = Observer<ProductSearchVM?>(nil)
    var pageList = Observer<[ProductPage]?>(nil)
    var productList = Observer<[ProductItem]>([])
    var productWidget = Observer<Catalog?>(nil)
    var pageLabel = Observer<String>("")
    var setNumberOfPages = Observer<String>("")
    var setProductTitle = Observer<String>("")
    var updatePageLabelInWidget = Observer<String?>(nil)
    var newItemFromQR = Observer<ProductItem?>(nil)
    
    private var apiClient: ApiClientProtocol?
    private var productCount: Int?
    private lazy var pageNumber = 1
    private var categoryId: ProductCatalog
    
    //MARK:- Constructor
    init(productCatalogId: ProductCatalog,
         apiClient: ApiClientProtocol = ApiClient()) {
        self.categoryId = productCatalogId
        self.apiClient = apiClient
        setProductTitle.value = productCatalogId.value
    }
    
}

extension ProductCatalogVM {
    
    //MARK:- Public Methods
    func changeSideController() {
        switch categoryId {
        case .pet:
            childIdentifier.value = .petTypeChildVC
        case .collegiate:
            childIdentifier.value = .petTypeChildVC
        case .digitalMarketing:
            childIdentifier.value = .petTypeChildVC
        case .holiday:
            childIdentifier.value = .petTypeChildVC
        case .retailDisplay:
            childIdentifier.value = .petTypeChildVC
        }
    }
    
    func setCatalog(with id: ProductCatalog) {
        categoryId = id
        pageNumber = 1
        getProductList()
        setProductTitle.value = categoryId.value
    }
    
    func nextPage() {
        if productCount ?? 1 > pageNumber {
            pageNumber = pageNumber + 1
            if let pageObj = pageList.value?.first(where: { $0.pageNo == (self.pageNumber + 1) }) {
                productCount = pageObj.productCount
                getProductListApi()
            }
        }
    }
    
    func barCodeScanFail(message: String) { // this function shows barcode falure error
        error.value = message
    } 
    
    func barCodeScanSuccess(barCode: String) { // this function shows barcode success
        addProductFromQR(upc: barCode)
    }
    
    func enableQR() { // this function enable qr code
        success.value = "QR Enabled"
    }
    
    func openBarCodeScaner(delegateTo:ProductWidgetVC) { // this function to open barcode scanner
//        addProductFromQR(upc: "ZKP2759")
        let viewController = BarcodeScannerViewController()
        viewController.codeDelegate = delegateTo
        viewController.errorDelegate = delegateTo
        viewController.dismissalDelegate = delegateTo
        delegateTo.present(viewController, animated: true, completion: nil)
    }
    
    func addProductFromQR(upc: String)  {//call this function when to read data from the QR
        getProductDetail(of: upc)
    }
    
    func previousPage() {
        if pageNumber > 1 {
            pageNumber = pageNumber - 1
            if let pageObj = pageList.value?.first(where: { $0.pageNo == (self.pageNumber + 1) }) {
                productCount = pageObj.productCount
                getProductListApi()
            }
        }
    }
    
    func selectPage(with page: ProductPage)  {
        pageLabel.value = page.pageLabel ?? ""
        pageNumber = page.pageNo ?? 1
        getProductListApi()
    }
    
    func getProductList() {
        getCatalogIdApi()
        getPagesListApi()
    }
    
    func gotoSearchProduct() {
        productSearchVM.value = ProductSearchVM(apiClient: apiClient!)
    }
    
    //MARK:- Private Methods
    private func getCatalogIdApi() {
        let input = categoryId.rawValue
        
        let request: APIRouter = .catalog(param: input)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<Catalog>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.productWidget.value = value.result
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func updateQuantity(of item: Item, with quantity: Int) {
        
        guard let index = CartItem.shared.cartProduct.value?.items?.firstIndex(where: { $0 == item }),
              let cartQuantity = CartItem.shared.cartProduct.value?.items?[index].quantity
        else { return }
        
        let totalQuantity = cartQuantity + quantity
        guard totalQuantity > 0 else { return }
        
        CartItem.shared.cartProduct.value?.items?[index].quantity = totalQuantity
        CartItem.shared.cartProduct.value?.items?[index].itemTotal = {
            return Double(totalQuantity) * CartItem.shared.cartProduct.value!.items![index].unitPrice!
        }()
    }
    
    private func addProductToCart(product: ProductItem) {
        guard let myProfile = getMyProfile() else { return }
        
        
        let productHistoryItems = CartItem.shared.cartProduct.value ?? ProductHistoryItems()
        var amount: Double = 0.0
        var itemList: [Item] = CartItem.shared.cartProduct.value?.items ?? []
        
        let json = JSONEncoder().encodeObject(product)
        let convertedProduct: ProductHistory = JSONDecoder().decodeObject(json)
        
        if let item = itemList.first(where: { $0.product == convertedProduct }) {
            guard let cartQuantity = item.quantity else { return }
            
            
            let totalQuantity = cartQuantity + 1
            guard totalQuantity > 0 else { return }
            
            item.quantity = totalQuantity
            item.itemTotal = {
                return Double(totalQuantity) * item.unitPrice!
            }()
        }
        else {
            let item = Item()
            item.quantity = 1
            item.productID = convertedProduct.id
            item.unitPrice = convertedProduct.price
            item.itemTotal = convertedProduct.price
            item.product = convertedProduct
            amount = amount + (convertedProduct.price)
            itemList.append(item)
        }
        
        if productHistoryItems.date == nil {
            productHistoryItems.date = Date().convertToString()
        }
        if productHistoryItems.creationTime == nil {
            productHistoryItems.creationTime = Date().convertToString()
        }
        productHistoryItems.customerName = myProfile.name
        productHistoryItems.amount = amount
        productHistoryItems.type = CustomerTypeModel.shared.type?.rawValue
        productHistoryItems.status = ProductStatus.pending.getStatusInt
        productHistoryItems.username = myProfile.userName
        productHistoryItems.userStreet = myProfile.street
        productHistoryItems.userAddress = myProfile.address
        productHistoryItems.userCity = myProfile.city
        productHistoryItems.userState = myProfile.state
        productHistoryItems.userZipCode = myProfile.zIPCode
        productHistoryItems.userCompanyName = myProfile.companyName
        productHistoryItems.userCountry = myProfile.country
        productHistoryItems.address = myProfile.address
        productHistoryItems.city = myProfile.city
        productHistoryItems.state = myProfile.state
        productHistoryItems.zIPCode = myProfile.zIPCode
        productHistoryItems.companyName = myProfile.companyName
        productHistoryItems.dropshipFee = myProfile.dropshipFee
        productHistoryItems.country = myProfile.country
        productHistoryItems.orderOnBehaf = 0
        productHistoryItems.emalOnSAveAndCheckout = false
        productHistoryItems.isDeleted = false
        productHistoryItems.lastModificationTime = Date().convertToString()
        productHistoryItems.lastModifierUserID = myProfile.id
        productHistoryItems.creatorUserID = myProfile.id
        productHistoryItems.items = itemList
        CartItem.shared.cartProduct.value = productHistoryItems
        newItemFromQR.value = product
    }
    
    
    private func getPagesListApi() {
        isLoading.value = true
        
        let input = categoryId.rawValue
        
        let request: APIRouter = .pagesForCatalog(param: input)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseArray<ProductPage>>) in
            
            guard let self = self else { return }
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.productCount = value.result?.count
                    self.pageList.value = value.result ?? []
                    self.getProductListApi()
                }
                else {
                    self.isLoading.value = false
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.isLoading.value = false
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func getProductListApi() {
        isLoading.value = true
        
        let input = ProductCatalogInput(categoryId: categoryId.rawValue,
                                        skipCount: pageNumber - 1,
                                        maxResultCount: productCount)
        
        let request: APIRouter = .productCatalog(param: input)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductItemResult>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.setNumberOfPages.value = "Page \(value.result?.pageNo ?? 1) of \(value.result?.totalPages ?? 0)"
                    self.pageLabel.value = value.result?.pageLabel ?? ""
                    self.updatePageLabelInWidget.value = value.result?.pageLabel
                    self.productList.value = value.result?.items ?? []
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func getProductDetail(of sku: String) {
        
        isLoading.value = true
        //search data should be replaced with product id
        let input = SearchProduct(searchData: sku,
                                  skipCount: pageNumber,
                                  maxResultCount: productCount)
        
        let request: APIRouter = .searchProduct(param: input)
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductItemResult>>) in
            
            guard let self = self else { return }
            
            self.isLoading.value = false
            
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    guard  let product = value.result?.items.first else {
                        self.error.value = "No product found"
                        return
                    }
                    self.addProductToCart(product: product)
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
}
