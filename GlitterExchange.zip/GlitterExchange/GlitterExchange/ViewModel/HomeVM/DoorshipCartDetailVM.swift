//
//  DoorshipCartDetailVM.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 04/11/2020.
//

import Alamofire
import Foundation

final class DoorshipCartDetailVM {
    
    //MARK:- Properties
    var error = Observer<String?>("")
    var isLoading = Observer<Bool?>(false)
    var setTitle = Observer<String?>("")
    var doorshipFee = Observer<String?>("")
    var updateQuantityLabel = Observer<String>("")
    var downloadOrderPopupVM = Observer<DownloadOrderPopupVM?>(nil)
    var customerList = Observer<[String?]>([])
    var companyList = Observer<[String]>([])
    var cartData = Observer<ProductHistoryItems?>(nil)
    var onSuccess = Observer<String?>(nil)
    
    var isAdmin = Observer<Bool?>(nil)
    
    private var apiClient: ApiClientProtocol?
    var datasource: GenericDataSource<Item>
    var companyListDataSource: GenericDataSource<String>
    
    private lazy var userList: [Profile] = []
    private lazy var orderStatus: ProductStatus = .pending
    
    lazy var city = ""
    lazy var state = ""
    lazy var zipCode = ""
    lazy var country = ""
    lazy var poNumber = ""
    lazy var companyName = ""
    lazy var addressName1 = ""
    lazy var addressName2 = ""
    lazy var customerName = ""
    lazy var deliveryDate = ""
    lazy var notes = ""
    lazy var searchCompany = "" {
        didSet {
            searchCompanyFromList()
        }
    }
    
    lazy var selectedCompany = ""
    lazy var selectedCustomer = ""
    
    private lazy var userRole = ""
    
    //MARK:- Constructor
    init(apiClient: ApiClientProtocol = ApiClient(),
         datasource: GenericDataSource<Item> = DoorshipCartListDatasource(),
         companyListDataSource: GenericDataSource<String> = CompanyListDatasource()) {
        self.apiClient = apiClient
        self.datasource = datasource
        self.companyListDataSource = companyListDataSource
    }
    
}

extension DoorshipCartDetailVM {
    
    //MARK:- Public Methods
    func loadData() {
        loadDataFromCart()
        getUsers()
    }
    
    func setCartItem(orderStatus: ProductStatus) {
        self.orderStatus = orderStatus
        switch orderStatus {
        case .orderPlaced:
            proceedOrder(orderStatus: orderStatus)
        case .cancelled:
            cancelOrder(orderStatus: orderStatus)
        case .pending:
            pendingOrder(orderStatus: orderStatus)
        default:
            print("defualt")
        }
    }
    
    func setSelectedCompany(companyName: String) {
        selectedCompany = companyName
        showCustomerList(companyName: companyName)
    }
    
    func setSelectedCustomer(customerName: String) {
        selectedCustomer = customerName
    }
    
    private func proceedOrder(orderStatus: ProductStatus) {
        if validateForm() {
            setFields()
            CartItem.shared.cartProduct.value?.status = orderStatus.getStatusInt
            createOrEditApi()
        }
    }
    
    private func cancelOrder(orderStatus: ProductStatus) {
        CartItem.shared.cartProduct.value?.status = orderStatus.getStatusInt
        createOrEditApi()
    }
    
    func pendingOrder(orderStatus: ProductStatus) {
        if validateForm() {
            setFields()
            CartItem.shared.cartProduct.value?.status = orderStatus.getStatusInt
            createOrEditApi()
        }
    }
    
    func remove(at index: Int) {
        CartItem.shared.cartProduct.value?.items?.remove(at: index)
        loadDataFromCart()
    }
    
    func searchCompanyFromList() {
        filterCompanyList()
    }
    
    func updateQuantity(at index: Int, with quantity: Int) {
        
        guard let cartQuantity = CartItem.shared.cartProduct.value?.items?[index].quantity
        else { return }
        
        let totalQuantity = cartQuantity + quantity
        guard totalQuantity > 0 else { return }
        
        CartItem.shared.cartProduct.value?.items?[index].quantity = totalQuantity
        CartItem.shared.cartProduct.value?.items?[index].itemTotal = {
            return Double(totalQuantity) * CartItem.shared.cartProduct.value!.items![index].unitPrice!
        }()
        loadDataFromCart()
        cartItemCountUpdate()
    }
    
    func getCustomerList() {
        showCustomerList(companyName: selectedCompany)
    }
    
    //MARK:- Private Methods
    
    private func validateForm() -> Bool{
        if companyName.isEmpty {
            error.value = "Please enter company name."
            return false
        }
        else if customerName.isEmpty {
            error.value = "Please enter customer name."
            return false
        }
        else if addressName1.isEmpty {
            error.value = "Please enter address line."
            return false
        }
        else if city.isEmpty {
            error.value = "Please enter city."
            return false
        }
        else if state.isEmpty {
            error.value = "Please enter state."
            return false
        }
        else if customerName.isEmpty {
            error.value = "Please enter zip code."
            return false
        }
        else if country.isEmpty {
            error.value = "Please enter country."
            return false
        }
//        else if poNumber.isEmpty {
//            error.value = "Please enter po number."
//            return false
//        }
        else if deliveryDate.isEmpty {
            error.value = "Please select delivery date."
            return false
        }
        
        if  userRole == "ADMIN" {
            if selectedCompany.isEmpty {
                error.value = "Please select company name."
                return false
            }
            else if selectedCustomer.isEmpty {
                error.value = "Please select customer."
                return false
            }
        }
        
        return true
    }
    
    private func loadDataFromCart() {
        datasource.data.value = CartItem.shared.cartProduct.value?.items ?? []
        setTitle.value = "Review Dropship Order #\(CartItem.shared.cartProduct.value?.id ?? 0)"
        doorshipFee.value = "Doorship Fee $\(CartItem.shared.cartProduct.value?.dropshipFee ?? 0.0)"
        cartData.value = CartItem.shared.cartProduct.value
        cartItemCountUpdate()
    }
    
    private func setFields() {
        CartItem.shared.cartProduct.value?.address = addressName1
        CartItem.shared.cartProduct.value?.companyName = companyName
        CartItem.shared.cartProduct.value?.customerName = customerName
        CartItem.shared.cartProduct.value?.state = state
        CartItem.shared.cartProduct.value?.city = city
        CartItem.shared.cartProduct.value?.country = country
        CartItem.shared.cartProduct.value?.poNumber = poNumber
        CartItem.shared.cartProduct.value?.zIPCode = zipCode
        CartItem.shared.cartProduct.value?.notes = notes
        
        if userRole == "ADMIN" {
            let user = userList.filter {
                $0.companyName?.lowercased() == selectedCompany.lowercased() &&
                    $0.name?.lowercased() == selectedCustomer.lowercased()
            }
            CartItem.shared.cartProduct.value?.userAddress = user.first?.address
            CartItem.shared.cartProduct.value?.userCompanyName = user.first?.companyName
            CartItem.shared.cartProduct.value?.customerName = user.first?.name
            CartItem.shared.cartProduct.value?.userState = user.first?.state
            CartItem.shared.cartProduct.value?.userCity = user.first?.city
            CartItem.shared.cartProduct.value?.userCountry = user.first?.country
            CartItem.shared.cartProduct.value?.userZipCode = user.first?.zIPCode
            CartItem.shared.cartProduct.value?.shippingDate = deliveryDate
            
        }
        else {
            
            CartItem.shared.cartProduct.value?.userAddress = addressName1
            CartItem.shared.cartProduct.value?.userCompanyName = companyName
            CartItem.shared.cartProduct.value?.customerName = customerName
            CartItem.shared.cartProduct.value?.userState = state
            CartItem.shared.cartProduct.value?.userCity = city
            CartItem.shared.cartProduct.value?.userCountry = country
            CartItem.shared.cartProduct.value?.userZipCode = zipCode
            CartItem.shared.cartProduct.value?.shippingDate = deliveryDate
        }
    }
    
    private func cartItemCountUpdate() {
        var totalItems = 0
        var subTotal: Double = 0.0
        CartItem.shared.cartProduct.value?.items?.forEach {
            subTotal = subTotal + $0.itemTotal!
            totalItems = totalItems + $0.quantity!
        }
        updateQuantityLabel.value = "Qty. \(totalItems) - Total: $\(subTotal)"
    
    }
    
    private func createOrEditApi() {
        guard let input = getProductsList() else { return }
        
        guard apiClient != nil else {
            error.value = LocalError.objectNotIntialized.rawValue
            return
        }
        
        isLoading.value = true
        
        let request: APIRouter = .createOrEdit(param: input)
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<ProductHistoryItems>>) in
            
            guard let self = self else { return }
            self.isLoading.value = false
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    CartItem.shared.cartProduct.value?.id = value.result?.id
                    self.onSuccess.value = "Your \(self.orderStatus.value) succesfully"
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
    }
    
    private func getProductsList() -> [String: Any]? {
        let json = JSONEncoder().encodeObject(CartItem.shared.cartProduct.value)
        if let data = json?.data(using: .utf8) {
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:AnyObject]
                return json
            } catch let error {
                self.error.value = error.localizedDescription
            }
        }
        return nil
    }
    
    private func getUsers() {
        guard let myProfile = getMyProfileWithRole(),
              myProfile.roleNames?.first == "ADMIN" else { return }
        isAdmin.value = true
        userRole = "ADMIN" // comment this and uncomment the above one
        isLoading.value = true
        let input = GetUserInput(filter: "", roleId: 0,
                                 creatorUserId: 0,
                                 skipCount: 0,
                                 maxResultCount: 999)
        let request: APIRouter = .getUsersList(param: input)
        
        apiClient?.performRequest(route: request) { [weak self]
            (response: AFDataResponse<GeneralResponseObj<GetUserOutput>>) in
            
            guard let self = self else { return }
            self.isLoading.value = false
            switch response.result {
            case let .success(value):
                if value.success ?? false {
                    self.userList = value.result?.users ?? []
                    self.companyList.value = self.getCompanyList(from: value.result?.users ?? [])
                }
                else {
                    self.error.value = value.error?.message
                }
            case let .failure(error):
                self.error.value = error.errorDescription
            }
        }
        
    }
    
    private func getCompanyList(from users: [Profile]) -> [String] {
        let userList = Set(users.map { $0.companyName ?? "" })
        return Array(userList)
    }
    
    private func filterCompanyList() {
        if searchCompany.count == 0 {
            companyListDataSource.data.value = companyList.value
            return
        }
        companyListDataSource.data.value = companyList.value.filter { $0.lowercased().contains(searchCompany.lowercased()) }
    }
    
    private func showCustomerList(companyName: String) {
        self.customerList.value =  userList
            .filter { $0.companyName?.lowercased() == companyName.lowercased() }
            .map { $0.name }
    }
    
}
