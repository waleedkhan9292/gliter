//
//  TabProtocol.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 10/10/2020.
//

import Foundation

@objc protocol OrderHistoryDelegate {
    @objc optional func goToDetailScreen(with orderId:Int)
    func gotoOrderHistoryController()
}
extension OrderHistoryDelegate {
    func gotoOrderHistoryController() {}
}

@objc protocol OrderHistoryDetailDelegate {
    @objc optional func goToHistoryScreen()
}

@objc protocol TabDelegate {
    @objc optional func setOrderId(with orderId:Int)
}

protocol ProductWidgetDelegate {
    func setPageInProductCatalog(with page: ProductPage)
    func gotoSearchProductScreen()
    func enableQR()
    func openBarCodeScaner(delegateTo:ProductWidgetVC)
    func barCodeScanFail(message: String)
    func barCodeScanSuccess(barCode: String)
}

extension ProductWidgetDelegate {
    func gotoSearchProductScreen() { }
    func enableQR() { }
}

@objc protocol UpdateCartItemDelegate {
    @objc optional func updatedItems()
    @objc optional func showCartView()
    @objc optional func showSelectionView()
}

@objc protocol HomeControllerDelegate {
    @objc optional func goToPet()
    @objc optional func goToHoliday()
    @objc optional func goToCustom()
    @objc optional func goToDigitalMarketing()
    @objc optional func goToRetailDisplay()
    @objc optional func goToVideo()
    @objc optional func goToPhotograpy()
    @objc optional func goToWebsiteAssistance()
}


protocol ProductCatalogDelegate {
    func loadData<T>(productList: [T])
    func setWidget(with catalog: Catalog?)
    func setLabel(with text: String)
    func updateImagesMultipleSelection(isOn: Bool)
    func updateProductListSelection(items: [ProductItem])
}

extension ProductCatalogDelegate {
    func setWidget(with catalog: Catalog?){}
    func setLabel(with text: String){}
    func updateImagesMultipleSelection(isOn: Bool) { }
    func updateProductListSelection(items: [ProductItem]) {}
}


protocol SelectItemDelegate {
    func updateMultipleSelection(isOn: Bool)
    func hideView()
    func selectItem(item: ProductItem)
    func singleSelectItem(item: ProductItem)
    func updateAllList(item: [ProductItem])
    func addToCart(item: [ProductItem])
}
extension SelectItemDelegate {
    func updateMultipleSelection(isOn: Bool) { }
    func selectItem(item: ProductItem) { }
    func updateAllList(item: [ProductItem]) { }
    func hideView() { }
    func addToCart(item: [ProductItem]) { }
    func singleSelectItem(item: ProductItem) { }
}

protocol CartProtocol {
    func gotoCartDetailController()
    func gotoHomeControllerFromCart()
}

protocol ProductCatalogProtocol {
    func gotoHisotoryFromProductCatalog()
    func gotoHomeController()
    func gotoCustomController()
}
extension ProductCatalogProtocol {
    func gotoHomeController() {}
    func gotoCustomController() {}
    func gotoHisotoryFromProductCatalog() {}
}
protocol CartDetailProtocol {
    func showHistoryController()
}
