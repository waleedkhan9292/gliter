//
//  BaseVCProtocol.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/09/2020.
//
import UIKit
import SVProgressHUD

typealias BaseVCProtocol = Configurable

//MARK:- Configurable Protocol

protocol Configurable {
    func bindView()
    func configureView()
}

//MARK:- Base View Controller Protocol
