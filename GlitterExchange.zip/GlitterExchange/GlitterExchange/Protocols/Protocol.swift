//
//  Protocol.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 14/10/2020.
//

import Foundation

protocol DatabaseRepresentation {
  var representation: [String: Any] { get }
}

protocol ChangeShippingAddressDelegate {
    func updateViewForShiping()
}
