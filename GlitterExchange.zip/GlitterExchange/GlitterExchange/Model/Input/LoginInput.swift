//
//  LoginInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 13/10/2020.
//

import Foundation

struct LoginInput: Codable {
    let userNameOrEmail: String?
    let password: String?
    let remeberClient: Bool?
}

extension LoginInput: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let userNameOrEmail = userNameOrEmail {
            rep["userNameOrEmailAddress"] = userNameOrEmail
        }
        
        if let password = password {
            rep["password"] = password
        }
        
        if let rememberClient = remeberClient {
            rep["rememberClient"] = rememberClient
        }
        
        return rep
    }
    
}
