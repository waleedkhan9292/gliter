//
//  ForgotPasswordInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 14/10/2020.
//

import Foundation

struct ForgotPasswordInput: Codable {
    let email: String?
    let newPassword: String?
}

extension ForgotPasswordInput: DatabaseRepresentation {
  
  var representation: [String : Any] {
    var rep = [String: Any]()
    
    if let email = email {
        rep["email"] = email
    }
    
    if let newPassword = newPassword {
        rep["newpassword"] = newPassword
    }
    
    return rep
  }
  
}
