//
//  CartItems.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 31/10/2020.
//

import Foundation

final class CartItem {
    
    static let shared = CartItem()
    
//    var cartProduct: ProductHistoryItems?
    
    var cartProduct = Observer<ProductHistoryItems?>(nil)
    
    private init() {}
}
