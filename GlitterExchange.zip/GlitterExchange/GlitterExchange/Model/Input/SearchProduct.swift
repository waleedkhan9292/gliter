//
//  SearchProduct.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 25/10/2020.
//

import Foundation

struct SearchProduct: Codable {
    let searchData: String?
    let skipCount: Int?
    let maxResultCount: Int?
}

extension SearchProduct: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let searchData = searchData {
            rep["searchData"] = searchData
        }
        
        if let skipCount = skipCount {
            rep["SkipCount"] = skipCount
        }
        
        if let maxResultCount = maxResultCount {
            rep["MaxResultCount"] = maxResultCount
        }
        
        return rep
    }
    
}
