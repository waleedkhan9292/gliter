//
//  PdfLookbookExportInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 28/10/2020.
//

import Foundation

struct PdfLookbookExportInput: Codable {
    let productId: [Int]?
    let hidePrice: Bool?
}

extension PdfLookbookExportInput: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let productId = productId {
            rep["productId"] = productId
        }
        
        return rep
    }
    
}
