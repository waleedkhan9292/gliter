//
//  ContactUsInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 15/10/2020.
//

import Foundation

struct ContactUsInput: Codable {
    let subject: String?
    let message: String?
}

extension ContactUsInput: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let subject = subject {
            rep["subject"] = subject
        }
        
        if let message = message {
            rep["message"] = message
        }
        
        
        return rep
    }
    
}
