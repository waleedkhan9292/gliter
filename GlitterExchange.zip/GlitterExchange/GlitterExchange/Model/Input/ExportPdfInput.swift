//
//  ExportFileWithUserInfoInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 30/10/2020.
//

import Foundation

struct ExportPdfInput: Codable {
    let productId: [Int]?
    let hidePrice: Bool?
    let email: String?
}

extension ExportPdfInput: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let productId = productId {
            rep["productId"] = productId
        }
        
        return rep
    }
}
