//
//  OrderHistoryInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 17/10/2020.
//

import Foundation

struct OrderHistoryInput: Codable {
    let type: String?
    let skipCount: Int?
    let maxResultCount: Int?
}

extension OrderHistoryInput: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let type = type {
            rep["Type"] = type
        }
        
        if let skipCount = skipCount {
            rep["SkipCount"] = skipCount
        }
        
        if let maxResultCount = maxResultCount {
            rep["MaxResultCount"] = maxResultCount
        }
        
        return rep
    }
    
}
