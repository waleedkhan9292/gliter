//
//  CustomerTypeModel.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 18/10/2020.
//

import Foundation

//struct CustomerTypeModel: Codable {
//    var type: String?
//    var hidePrices: Bool?
//}
//
//extension CustomerTypeModel {
//
//    mutating func updateType(type: String) {
//        self.type = type
//    }
//
//    mutating func updateHidePrices(hidePrices: Bool) {
//        self.hidePrices = hidePrices
//    }
//}

final class CustomerTypeModel {
    static let shared = CustomerTypeModel()
    
    var type: CustomerType?
    var hidePrices = true
    
    private init() {}
}

