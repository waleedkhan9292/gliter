//
//  ChangePasswordInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 15/10/2020.
//

import Foundation

struct ChangePasswordInput: Codable {
    let currentPassword: String?
    let newPassword: String?
}

extension ChangePasswordInput: DatabaseRepresentation {
  
  var representation: [String : Any] {
    var rep = [String: Any]()
    
    if let currentPassword = currentPassword {
        rep["currentPassword"] = currentPassword
    }
    
    if let newPassword = newPassword {
        rep["newPassword"] = newPassword
    }
    
    return rep
  }
  
}
