//
//  GetUserInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 14/11/2020.
//

import Foundation

struct GetUserInput: Codable {
    let filter: String
    let roleId: Int
    let creatorUserId: Int
    let skipCount: Int
    let maxResultCount: Int
}
