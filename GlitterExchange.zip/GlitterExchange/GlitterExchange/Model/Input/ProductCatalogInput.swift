//
//  ProductCatalogInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 22/10/2020.
//

import Foundation

struct ProductCatalogInput: Codable {
    let categoryId: Int?
    let skipCount: Int?
    let maxResultCount: Int?
}

extension ProductCatalogInput: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let type = categoryId {
            rep["CategoryId"] = type
        }
        
        if let skipCount = skipCount {
            rep["SkipCount"] = skipCount
        }
        
        if let maxResultCount = maxResultCount {
            rep["MaxResultCount"] = maxResultCount
        }
        
        return rep
    }
    
}
