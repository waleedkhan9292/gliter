//
//  Catalog.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 22/10/2020.
//

import Foundation

struct Catalog: Codable {
    let name: String?
    let itemCount: Int?
    let pageNavigatorLabel: String?
    let showPageNavigator: Bool?
    let widgetHTML: String?
    let isDeleted: Bool?
    let deletionTime: String?
    let lastModificationTime: String?
    let lastModifierUserID: Int?
    let creationTime: String?
    let deleterUserID,creatorUserID: Int?
    let id: Int?
    
    enum CodingKeys: String, CodingKey {
        case name, itemCount, pageNavigatorLabel, showPageNavigator
        case widgetHTML = "widgetHtml"
        case isDeleted
        case deleterUserID = "deleterUserId"
        case deletionTime, lastModificationTime
        case lastModifierUserID = "lastModifierUserId"
        case creationTime
        case creatorUserID = "creatorUserId"
        case id
    }
}
