//
//  Item.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 19/10/2020.
//

import Foundation

class Item: Codable {
    var product: ProductHistory?
    var productID, orderID: Int?
    var quantity: Int?
    var unitPrice: Double?
    var itemTotal: Double?

    enum CodingKeys: String, CodingKey {
        case product
        case productID = "productId"
        case orderID = "orderId"
        case quantity, unitPrice, itemTotal
    }

    init() {
    }
}

extension Item: Equatable {
    static func == (lhs: Item, rhs: Item) -> Bool {
        return lhs.productID == rhs.productID
    }
}
