//
//  ProductHistoryItemResult.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 17/10/2020.
//

import Foundation

class ProductHistoryItemResult: Codable {
    let totalCount: Int?
    let Products: [ProductHistoryItems]?
    
    enum CodingKeys: String, CodingKey {
        case totalCount
        case Products = "items"
    }
}
