//
//  GetUserOutput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 14/11/2020.
//

import Foundation

struct GetUserOutput: Codable {
    let totalCount: Int
    let users: [Profile]
    
    enum CodingKeys: String, CodingKey {
        case totalCount
        case users = "items"
    }
}
