//
//  ProductHistoryItems.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 17/10/2020.
//

import Foundation

class ProductHistoryItems: Codable {
    var customerName: String?
    var date: String?
    var amount: Double?
    var type: String?
    var status: Int?
    var username, userStreet, userAddress, userCity: String?
    var userState, userZipCode: String?
    var userCompanyName: String?
    var userCountry, address, poNumber: String?
    var items: [Item]?
    var shippingDate: String?
    var terms, street, city, state: String?
    var zIPCode: String?
    var companyName: String?
    var notes, carrier, trackingID: String?
    var dropshipFee: Double?
    var comment, country: String?
    var orderOnBehaf: Int?
    var orderOnBehafUser: String?
    var emalOnSAveAndCheckout, isDeleted: Bool?
    var deleterUserID: Int?
    var deletionTime, lastModificationTime: String?
    var lastModifierUserID: Int?
    var creationTime: String?
    var creatorUserID: Int?
    var id: Int?

    enum CodingKeys: String, CodingKey {
        case customerName, date, amount, type, status, username, userStreet, userAddress, userCity, userState, userZipCode, userCompanyName, userCountry, items, address, poNumber, shippingDate, terms, street, city, state
        case zIPCode = "zIpCode"
        case companyName, notes, carrier
        case trackingID = "trackingId"
        case dropshipFee, comment, country, orderOnBehaf, orderOnBehafUser, emalOnSAveAndCheckout, isDeleted
        case deleterUserID = "deleterUserId"
        case deletionTime, lastModificationTime
        case lastModifierUserID = "lastModifierUserId"
        case creationTime
        case creatorUserID = "creatorUserId"
        case id
    }
    init() {  }
}

