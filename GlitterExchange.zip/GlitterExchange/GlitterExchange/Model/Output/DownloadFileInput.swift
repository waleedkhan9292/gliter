//
//  DownloadFileInput.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 28/10/2020.
//

import Foundation

struct DownloadFileInput: Codable {
    let fileName: String?
    let fileType: String?
    let fileToken: String?
    
    enum CodingKeys: String, CodingKey {
        case fileName, fileType, fileToken
    }
}

extension DownloadFileInput: DatabaseRepresentation {
    
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        if let fileName = fileName {
            rep["FileName"] = fileName
        }
        
        if let fileType = fileType {
            rep["FileType"] = fileType
        }
        
        if let fileToken = fileToken {
            rep["FileToken"] = fileToken
        }
        
        return rep
    }
    
}
