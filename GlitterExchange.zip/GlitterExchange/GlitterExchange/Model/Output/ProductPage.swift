//
//  ProductPage.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 22/10/2020.
//

import Foundation

struct ProductPage: Codable {
    let pageNo: Int?
    let pageLabel: String?
    let productCount: Int?
}
