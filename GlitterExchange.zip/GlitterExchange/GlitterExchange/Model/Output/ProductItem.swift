//
//  ProductItem.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/10/2020.
//

import Foundation

struct ProductItem: Codable {
    let sku, upc: String?
    let pageLabel: String?
    let pageNo: Int?
    let sortLetter, name: String?
    let order: String?
    let price: Double?
    let detail: String?
    let catalogID: Int?
    let offerLabel: String?
    let videoURLLink: String?
    let availabilityStatus, isActive: Bool?
    let searchKeywords: String?
    let isDeleted: Bool?
    let deleterUserID, deletionTime: String?
    let lastModificationTime: String?
    let lastModifierUserID: Int?
    let creationTime: String?
    let creatorUserID: Int?
    var id: Int?
    var isSelected:Bool = false

    enum CodingKeys: String, CodingKey {
        case sku, upc, pageLabel, pageNo, sortLetter, name, order, price, detail
        case catalogID = "catalogId"
        case offerLabel
        case videoURLLink = "videoUrlLink"
        case availabilityStatus, isActive, searchKeywords, isDeleted
        case deleterUserID = "deleterUserId"
        case deletionTime, lastModificationTime
        case lastModifierUserID = "lastModifierUserId"
        case creationTime
        case creatorUserID = "creatorUserId"
        case id
    }
}

extension ProductItem {
    mutating func updateSelectedState(state: Bool) {
        self.isSelected = state
    }
    
    mutating func updateId(id: Int) {
        self.id = id
    }
}


extension ProductItem: Equatable {
    static func == (lhs: ProductItem, rhs: ProductItem) -> Bool {
        return lhs.id == rhs.id && lhs.catalogID == rhs.catalogID
    }
}
