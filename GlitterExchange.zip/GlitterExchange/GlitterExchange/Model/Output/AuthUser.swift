//
//  AuthUser.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 16/10/2020.
//

import Foundation

struct AuthUser: Codable {
    let accessToken, encryptedAccessToken: String?
    let expireInSeconds, userID: Int?

    enum CodingKeys: String, CodingKey {
        case accessToken, encryptedAccessToken, expireInSeconds
        case userID = "userId"
    }
}
