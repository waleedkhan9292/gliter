//
//  Profile.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 16/10/2020.
//

import Foundation

struct Profile: Codable {
    var userName, name, surname, emailAddress: String?
    let isActive: Bool?
    var fullName, lastLoginTime, creationTime, companyName: String?
    let roleNames: [String]?
    var street, city, state, zIPCode: String?
    let terms, notes: String?
    var country, address: String?
    let dropshipFee: Double?
    let roleName, creatorUser: String?
    let roleID, creatorUserID, id : Int?
    
    enum CodingKeys: String, CodingKey {
        case userName, name, surname, emailAddress, isActive, fullName, lastLoginTime, creationTime, companyName, roleNames, street, city, state
        case zIPCode = "zIpCode"
        case terms, notes, country, address, dropshipFee, roleName
        case roleID = "roleId"
        case creatorUser
        case creatorUserID = "creatorUserId"
        case id
    }
}

extension Profile {
    
    mutating func updateName(name: String) {
        self.name = name
    }
    
    mutating func updatestreet(street: String) {
        self.street = street
    }
    mutating func updateCity(city: String) {
        self.city = city
    }
    mutating func updateaddressLane(addressLane: String) {
        self.address = addressLane
    }
    mutating func updateState(state: String) {
        self.state = state
    }
    mutating func updateZipCode(zipCode: String) {
        self.zIPCode = zipCode
    }
    mutating func updateCountry(country: String) {
        self.country = country
    }
    
    mutating func updateCompayName(companyName: String) {
        self.companyName = companyName
    }
}

extension Profile: DatabaseRepresentation {
    var representation: [String : Any] {
        var rep = [String: Any]()
        
        rep["userName"] = userName
        rep["name"] = name
        rep["surname"] = surname
        rep["emailAddress"] = emailAddress
        rep["isActive"] = isActive
        rep["fullName"] = fullName
        rep["lastLoginTime"] = lastLoginTime
        rep["creationTime"] = creationTime
        rep["companyName"] = companyName
        rep["roleNames"] = roleNames ?? ""
        rep["street"] = street
        rep["city"] = city
        rep["state"] = state
        rep["zIpCode"] = zIPCode
        rep["terms"] = terms ?? ""
        rep["notes"] = notes ?? ""
        rep["country"] = country
        rep["address"] = address
        rep["dropshipFee"] = dropshipFee
        rep["roleName"] = roleName ?? ""
        rep["roleId"] = roleID ?? ""
        rep["creatorUser"] = creatorUser ?? ""
        rep["creatorUserId"] = creatorUserID
        rep["id"] = id
        
        return rep
    }
}

enum CreatorUser: String, Codable {
    case lisaKelechava = "Lisa Kelechava"
    case zohaibAmjad = "Zohaib Amjad"
}

enum RoleName: String, Codable {
    case accountManager = "Account Manager"
    case admin = "Admin"
    case customer = "Customer"
}
