//
//  AuthUser.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 13/10/2020.
//

import Foundation

struct GeneralResponseObj<T: Codable>: Codable {
    let result: T?
    let targetURL: String?
    let success: Bool?
    let error: ApiErrorResponse?
    let unAuthorizedRequest, abp: Bool?

    enum CodingKeys: String, CodingKey {
        case result
        case targetURL = "targetUrl"
        case success, error, unAuthorizedRequest
        case abp = "__abp"
    }
}
