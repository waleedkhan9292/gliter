//
//  ProductItemResult.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 23/10/2020.
//

import Foundation

struct ProductItemResult: Codable {
    let totalPages, pageNo: Int?
    let pageLabel: String?
    let categoryID, totalCount: Int?
    let items: [ProductItem]

    enum CodingKeys: String, CodingKey {
        case totalPages, pageNo, pageLabel
        case categoryID = "categoryId"
        case totalCount, items
    }
}
