//
//  ApiErrorResponse.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 14/10/2020.
//

import Foundation

struct ApiErrorResponse: Codable {
    let code: Int?
    let message: String?
    let details: String?
    let validationErrors: String?
    
    enum CodingKeys: String, CodingKey {
        case code, message, details, validationErrors
    }
}
