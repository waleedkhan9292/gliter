//
//  GenericDatasource.swift
//  GlitterExchange
//
//  Created by Waleed Khan on 17/10/2020.
//

import Foundation

class GenericDataSource<T> : NSObject {
    var data = Observer<[T]>([])
}
